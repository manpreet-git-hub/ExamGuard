# ── backend/database/db.py — SQLAlchemy engine + session ──────────────────────

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./examguard.db")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {},
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def run_migrations(engine):
    """Apply lightweight schema migrations for SQLite (safe to run on each startup)."""
    from sqlalchemy import text, inspect
    inspector = inspect(engine)
    with engine.connect() as conn:
        # Add allow_retake column to tests if missing
        tests_cols = [c['name'] for c in inspector.get_columns('tests')]
        if 'allow_retake' not in tests_cols:
            conn.execute(text("ALTER TABLE tests ADD COLUMN allow_retake BOOLEAN DEFAULT 0"))
            conn.commit()
            print("[Migration] Added 'allow_retake' column to tests table")
