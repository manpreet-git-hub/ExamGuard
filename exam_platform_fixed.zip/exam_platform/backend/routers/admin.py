# ── backend/routers/admin.py — Admin Panel API ────────────────────────────────
import os
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from database.db import get_db
from models.models import User, Test, Question, Submission, Answer, ViolationLog, UserRole
from routers.auth import get_current_user, get_password_hash

router = APIRouter()

EVIDENCE_DIR = os.path.join(os.path.dirname(__file__), '..', 'storage', 'evidence')


def require_admin_or_teacher(current_user: User = Depends(get_current_user)):
    if current_user.role not in [UserRole.teacher, UserRole.admin]:
        raise HTTPException(status_code=403, detail="Admin/Teacher access required")
    return current_user


def _delete_evidence_files(evidence_paths):
    """Remove evidence image files from disk for the given /evidence/<file> paths.
    Safe to call with None entries or paths that don't exist on disk."""
    for path in evidence_paths:
        if not path:
            continue
        fname = os.path.basename(path)  # strip "/evidence/" prefix, guard against traversal
        fpath = os.path.join(EVIDENCE_DIR, fname)
        try:
            if os.path.isfile(fpath):
                os.remove(fpath)
        except OSError as e:
            print(f"[Admin] Failed to delete evidence file {fpath}: {e}")


# ── STATS ─────────────────────────────────────────────────────────────────────

@router.get("/stats")
def get_stats(db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    return {
        "total_users":       db.query(User).count(),
        "total_students":    db.query(User).filter(User.role == UserRole.student).count(),
        "total_teachers":    db.query(User).filter(User.role == UserRole.teacher).count(),
        "total_tests":       db.query(Test).count(),
        "total_questions":   db.query(Question).count(),
        "total_submissions": db.query(Submission).count(),
        "total_violations":  db.query(ViolationLog).count(),
        "active_tests":      db.query(Test).filter(Test.is_active == True).count(),
    }


# ── USERS ─────────────────────────────────────────────────────────────────────

@router.get("/users")
def list_users(db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    users = db.query(User).order_by(User.created_at.desc()).all()
    return [
        {
            "id":         u.id,
            "full_name":  u.full_name,
            "email":      u.email,
            "username":   u.username,
            "role":       u.role.value,
            "is_active":  u.is_active,
            "created_at": u.created_at,
            "submission_count": len(u.submissions),
        }
        for u in users
    ]


class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    email:     Optional[str] = None
    username:  Optional[str] = None
    role:      Optional[str] = None
    is_active: Optional[bool] = None
    new_password: Optional[str] = None


@router.put("/users/{user_id}")
def update_user(user_id: int, data: UserUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if data.full_name  is not None: user.full_name  = data.full_name
    if data.email      is not None: user.email      = data.email
    if data.username   is not None: user.username   = data.username
    if data.is_active  is not None: user.is_active  = data.is_active
    if data.role       is not None: user.role       = UserRole(data.role)
    if data.new_password:           user.hashed_password = get_password_hash(data.new_password)
    db.commit()
    db.refresh(user)
    return {"detail": "User updated", "id": user.id}


@router.delete("/users/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(user)
    db.commit()
    return {"detail": "User deleted"}


# ── TESTS ─────────────────────────────────────────────────────────────────────

@router.get("/tests")
def list_all_tests(db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    tests = db.query(Test).order_by(Test.created_at.desc()).all()
    return [
        {
            "id":               t.id,
            "title":            t.title,
            "access_code":      t.access_code,
            "duration_mins":    t.duration_mins,
            "total_marks":      t.total_marks,
            "passing_marks":    t.passing_marks,
            "is_active":        t.is_active,
            "allow_retake":     getattr(t, "allow_retake", False),
            "creator_name":     t.creator.full_name,
            "creator_email":    t.creator.email,
            "question_count":   len(t.questions),
            "submission_count": len(t.submissions),
            "created_at":       t.created_at,
            "start_time":       t.start_time,
            "end_time":         t.end_time,
        }
        for t in tests
    ]


class TestAdminUpdate(BaseModel):
    title:         Optional[str]  = None
    description:   Optional[str]  = None
    duration_mins: Optional[int]  = None
    total_marks:   Optional[int]  = None
    passing_marks: Optional[int]  = None
    is_active:     Optional[bool] = None
    allow_retake:  Optional[bool] = None


@router.put("/tests/{test_id}")
def update_test(test_id: int, data: TestAdminUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    test = db.query(Test).filter(Test.id == test_id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")
    for field, val in data.dict(exclude_none=True).items():
        setattr(test, field, val)
    db.commit()
    return {"detail": "Test updated"}


@router.delete("/tests/{test_id}")
def delete_test(test_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    test = db.query(Test).filter(Test.id == test_id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")
    db.delete(test)
    db.commit()
    return {"detail": "Test and all related data deleted"}


# ── QUESTIONS ─────────────────────────────────────────────────────────────────

@router.get("/questions/{test_id}")
def list_questions(test_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    questions = db.query(Question).filter(Question.test_id == test_id).order_by(Question.order_index).all()
    return [
        {
            "id":             q.id,
            "question_text":  q.question_text,
            "question_type":  q.question_type.value,
            "options":        q.options,
            "correct_answer": q.correct_answer,
            "marks":          q.marks,
            "order_index":    q.order_index,
            "explanation":    q.explanation,
        }
        for q in questions
    ]


class QuestionAdminUpdate(BaseModel):
    question_text:  Optional[str]  = None
    correct_answer: Optional[str]  = None
    marks:          Optional[int]  = None
    explanation:    Optional[str]  = None


@router.put("/questions/{question_id}")
def update_question(question_id: int, data: QuestionAdminUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    q = db.query(Question).filter(Question.id == question_id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")
    for field, val in data.dict(exclude_none=True).items():
        setattr(q, field, val)
    db.commit()
    return {"detail": "Question updated"}


@router.delete("/questions/{question_id}")
def delete_question(question_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    q = db.query(Question).filter(Question.id == question_id).first()
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")
    db.delete(q)
    db.commit()
    return {"detail": "Question deleted"}


# ── SUBMISSIONS ────────────────────────────────────────────────────────────────

@router.get("/submissions")
def list_submissions(test_id: Optional[int] = None, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    q = db.query(Submission)
    if test_id:
        q = q.filter(Submission.test_id == test_id)
    subs = q.order_by(Submission.started_at.desc()).all()
    return [
        {
            "id":              s.id,
            "test_id":         s.test_id,
            "test_title":      s.test.title,
            "student_id":      s.student_id,
            "student_name":    s.student.full_name,
            "student_email":   s.student.email,
            "score":           s.score,
            "max_score":       s.max_score,
            "percentage":      s.percentage,
            "passed":          s.passed,
            "is_submitted":    s.is_submitted,
            "integrity_score": s.integrity_score,
            "risk_level":      s.risk_level,
            "violations_count": len(s.violations),
            "started_at":      s.started_at,
            "submitted_at":    s.submitted_at,
        }
        for s in subs
    ]


@router.delete("/submissions/{submission_id}")
def delete_submission(submission_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    sub = db.query(Submission).filter(Submission.id == submission_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Submission not found")
    evidence_paths = [
        v.evidence_path for v in
        db.query(ViolationLog).filter(ViolationLog.submission_id == submission_id).all()
    ]
    db.delete(sub)
    db.commit()
    _delete_evidence_files(evidence_paths)
    return {"detail": "Submission and its answers/violations deleted"}


@router.delete("/submissions/{submission_id}/violations")
def clear_violations(submission_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    evidence_paths = [
        v.evidence_path for v in
        db.query(ViolationLog).filter(ViolationLog.submission_id == submission_id).all()
    ]
    deleted = db.query(ViolationLog).filter(ViolationLog.submission_id == submission_id).delete()
    sub = db.query(Submission).filter(Submission.id == submission_id).first()
    if sub:
        sub.integrity_score = 100
        sub.risk_level = "Low"
    db.commit()
    _delete_evidence_files(evidence_paths)
    return {"detail": f"Cleared {deleted} violation(s), integrity reset to 100"}


# ── VIOLATION LOGS ─────────────────────────────────────────────────────────────

@router.get("/violations")
def list_violations(submission_id: Optional[int] = None, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    q = db.query(ViolationLog)
    if submission_id:
        q = q.filter(ViolationLog.submission_id == submission_id)
    logs = q.order_by(ViolationLog.timestamp.desc()).limit(500).all()
    return [
        {
            "id":               v.id,
            "submission_id":    v.submission_id,
            "student_id":       v.student_id,
            "test_id":          v.test_id,
            "violation_type":   v.violation_type,
            "confidence_score": v.confidence_score,
            "description":      v.description,
            "evidence_path":    v.evidence_path,
            "timestamp":        v.timestamp,
            "penalty_applied":  v.penalty_applied,
        }
        for v in logs
    ]


@router.delete("/violations/{violation_id}")
def delete_violation(violation_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    v = db.query(ViolationLog).filter(ViolationLog.id == violation_id).first()
    if not v:
        raise HTTPException(status_code=404, detail="Violation not found")
    evidence_path = v.evidence_path
    db.delete(v)
    db.commit()
    _delete_evidence_files([evidence_path])
    return {"detail": "Violation log deleted"}
