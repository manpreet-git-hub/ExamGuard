# ── backend/routers/proctoring_frame.py — AI frame analysis endpoint ──────────
# This module adds the /api/proctoring/analyze-frame endpoint that receives
# base64-encoded frames from students and runs the full AI proctoring pipeline.
# main.py already puts the project root on sys.path before any router is
# imported, so `ai_proctoring` is importable as a package by the time this
# file loads. The sys.path insert below is kept as a second, harmless,
# idempotent safety net in case this module is ever imported directly
# without going through main.py first (e.g. in a standalone test).

import os, sys, base64, traceback, uuid
import numpy as np
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
AI_ROOT = os.path.join(PROJECT_ROOT, 'ai_proctoring')
for path in [PROJECT_ROOT, AI_ROOT]:
    if path not in sys.path:
        sys.path.insert(0, path)

from database.db import get_db
from models.models import Submission, ViolationLog
from routers.auth import get_current_user
from models.models import User

router_frame = APIRouter()

EVIDENCE_DIR = os.path.join(os.path.dirname(__file__), '..', 'storage', 'evidence')
os.makedirs(EVIDENCE_DIR, exist_ok=True)

# Lazy-load AI models (heavy — only on first request)
_models = None

def get_models():
    global _models
    if _models is not None:
        return _models
    try:
        from ai_proctoring.model_loader import load_models
        _models = load_models()
        if "face_mesh" in _models and "face_det" in _models:
            print("[Proctoring] AI models loaded successfully (MediaPipe active — full detection)")
        elif _models:
            # Something loaded (e.g. the OpenCV Haar-cascade fallback / YOLO) but
            # MediaPipe itself did not. This means head pose, eye gaze, and
            # talking detection will NOT run — only basic face-box + device
            # detection is available. This is printed loudly because it silently
            # degrades proctoring quality if missed in the logs.
            missing = [m for m in ("face_det", "face_mesh") if m not in _models]
            print(f"[Proctoring] WARNING: MediaPipe component(s) {missing} failed to load — "
                  f"running in REDUCED mode (Haar-cascade fallback). Talking/eye-gaze/head-pose "
                  f"detection will not work correctly until MediaPipe loads. Check that the "
                  f"'mediapipe' package installed correctly and that the container has network "
                  f"access to download its model assets on first run.")
        else:
            print("[Proctoring] WARNING: no AI models loaded at all — proctoring is fully disabled")
    except Exception as e:
        print(f"[Proctoring] AI model load failed: {e}")
        traceback.print_exc()
        _models = {}
    return _models


PENALTIES = {
    "phone_detected": 30,
    "multiple_faces": 50,
    "no_face":      15,
    "looking_away": 5,
    "eye_gaze_away": 5,
    "talking":      8,
    "laptop_detected": 25,
}


class FrameAnalysisRequest(BaseModel):
    submission_id: int
    frame_b64: str


def _save_evidence_screenshot(frame_b64: str, violation_type: str) -> Optional[str]:
    """Save base64 JPEG frame to evidence directory and return the URL path."""
    try:
        img_data = base64.b64decode(frame_b64)
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        fname = f"{violation_type}_{timestamp}_{uuid.uuid4().hex[:8]}.jpg"
        fpath = os.path.join(EVIDENCE_DIR, fname)
        with open(fpath, "wb") as f:
            f.write(img_data)
        return f"/evidence/{fname}"
    except Exception as e:
        print(f"[Evidence] Failed to save screenshot: {e}")
        return None


@router_frame.post("/analyze-frame")
async def analyze_frame(
    req: FrameAnalysisRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Receive a JPEG frame (base64), run full AI proctoring pipeline,
    log any violations, and save screenshot evidence for each violation.
    """
    # Validate submission
    sub = db.query(Submission).filter(
        Submission.id == req.submission_id,
        Submission.student_id == current_user.id,
        Submission.is_submitted == False
    ).first()
    if not sub:
        return {"ok": False, "reason": "no active submission"}

    try:
        import cv2
        # Decode frame
        img_data = base64.b64decode(req.frame_b64)
        arr      = np.frombuffer(img_data, dtype=np.uint8)
        frame    = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if frame is None:
            return {"ok": False, "reason": "invalid frame"}

        models = get_models()
        if not models:
            return {"ok": True, "violations": [], "note": "AI models unavailable"}

        # Run proctoring pipeline
        from ai_proctoring.engine.frame_processor import process_frame
        # session_id keyed by submission so each student's talking-detector
        # state stays isolated from every other student being proctored
        # at the same time.
        _, results = process_frame(frame, models, session_id=sub.id)

        violations_logged = []

        num_faces = results.get("num_faces", 0)
        has_single_face = num_faces == 1

        # Map results to violations. Head-pose / eye-gaze / talking only make
        # sense when exactly one face is visible — with zero faces there's
        # nothing to read a gaze or mouth off, and with 2+ faces "multiple_faces"
        # is already the meaningful violation. Gating these on has_single_face
        # stops the confusing case where "no face detected" and a bogus
        # "eye gaze away" / "talking" violation used to fire at the same time.
        checks = {
            "phone_detected": (results.get("phone"),                                "Phone detected on camera"),
            "laptop_detected": (results.get("laptop"),                              "Laptop detected on camera"),
            "multiple_faces": (num_faces > 1,                                        "Multiple faces detected"),
            "no_face":        (num_faces == 0,                                       "No face detected"),
            "looking_away":   (has_single_face and results.get("head_state") in ("warn", "alert"),
                                f"Head pose: {results.get('head', '')}"),
            "eye_gaze_away":  (has_single_face and results.get("eye_state") == "warn",
                                f"Eye status: {results.get('eye', '')}"),
            "talking":        (has_single_face and results.get("talking"),           "Talking detected"),
        }

        # High-severity violations always save a screenshot
        HIGH_SEVERITY = {"phone_detected", "multiple_faces", "laptop_detected"}

        # No cooldown / de-duplication window: every violating frame is logged
        # and shown immediately, even if the same violation type was just
        # logged a moment ago. (Previously there was an 8s window that
        # suppressed repeat detections of the same type.)
        for vtype, (triggered, desc) in checks.items():
            if triggered:
                # Save evidence screenshot for this violation
                evidence_path = None
                if vtype in HIGH_SEVERITY:
                    # Always save for high-severity
                    evidence_path = _save_evidence_screenshot(req.frame_b64, vtype)
                else:
                    # Save every 3rd occurrence for lower severity (reduce disk usage)
                    count = db.query(ViolationLog).filter(
                        ViolationLog.submission_id == sub.id,
                        ViolationLog.violation_type == vtype
                    ).count()
                    if count % 3 == 0:
                        evidence_path = _save_evidence_screenshot(req.frame_b64, vtype)

                penalty = PENALTIES.get(vtype, 0)
                log = ViolationLog(
                    submission_id=sub.id,
                    student_id=current_user.id,
                    test_id=sub.test_id,
                    violation_type=vtype,
                    confidence_score=results.get("suspicion", 50) / 100,
                    description=desc,
                    evidence_path=evidence_path,
                    penalty_applied=penalty,
                )
                db.add(log)
                sub.integrity_score = max(0, sub.integrity_score - penalty)
                db.flush()
                violations_logged.append({
                    "id": log.id,
                    "violation_type": vtype,
                    "description": desc,
                    "confidence_score": results.get("suspicion", 50) / 100,
                    "penalty_applied": penalty,
                    "evidence_path": evidence_path,
                    "timestamp": datetime.utcnow().isoformat(),
                    "student_id": current_user.id,
                    "test_id": sub.test_id,
                })

        if violations_logged:
            # Compute risk
            s = sub.integrity_score
            sub.risk_level = "Low" if s >= 80 else "Medium" if s >= 50 else "High"
            db.commit()

        mesh_active = "face_mesh" in models
        response = {
            "ok":         True,
            "events":     violations_logged,
            "violations": [item["violation_type"] for item in violations_logged],
            "num_faces":  results.get("num_faces", 0),
            "suspicion":  results.get("suspicion", 0),
            "integrity":  sub.integrity_score,
            "risk_level": sub.risk_level,
            "checks_available": {
                "face": "face_det" in models,
                "mesh": mesh_active,
                "yolo": "yolo" in models,
            },
        }
        if not mesh_active:
            # MediaPipe's face mesh didn't load — head pose, eye gaze, and
            # talking detection are unavailable and only basic face-box /
            # device detection is running. Surface this clearly instead of
            # silently reporting reduced monitoring as if it were complete.
            response["note"] = (
                "Limited AI monitoring active — head pose, eye gaze, and talking "
                "detection are unavailable right now."
            )
        return response

    except Exception as e:
        traceback.print_exc()
        return {"ok": False, "error": str(e)}
