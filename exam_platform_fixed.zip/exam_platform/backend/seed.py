#!/usr/bin/env python3
# ── backend/seed.py — Seed database with demo teacher + student ───────────────

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from database.db import engine, SessionLocal, Base
from models.models import User, Test, Question, UserRole, QuestionType
from routers.auth import get_password_hash
from datetime import datetime, timedelta
import random, string

Base.metadata.create_all(bind=engine)
db = SessionLocal()

def gen_code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

# Clean slate
print("Seeding database...")

# ── Users ──────────────────────────────────────────────────────────────────────
teacher = db.query(User).filter(User.email == "teacher@demo.com").first()
if not teacher:
    teacher = User(
        email="teacher@demo.com", username="teacher_demo",
        full_name="Dr. Sarah Johnson", role=UserRole.teacher,
        hashed_password=get_password_hash("demo1234")
    )
    db.add(teacher)

student = db.query(User).filter(User.email == "student@demo.com").first()
if not student:
    student = User(
        email="student@demo.com", username="student_demo",
        full_name="Alex Kumar", role=UserRole.student,
        hashed_password=get_password_hash("demo1234")
    )
    db.add(student)

db.commit()
db.refresh(teacher)

# ── Demo Test ──────────────────────────────────────────────────────────────────
existing_test = db.query(Test).filter(Test.creator_id == teacher.id).first()
if not existing_test:
    test = Test(
        title="Computer Science Fundamentals",
        description="A comprehensive test covering data structures, algorithms, and OS concepts.",
        access_code=gen_code(),
        duration_mins=60,
        total_marks=50,
        passing_marks=25,
        start_time=datetime.utcnow(),
        end_time=datetime.utcnow() + timedelta(days=7),
        creator_id=teacher.id,
    )
    db.add(test)
    db.commit()
    db.refresh(test)

    questions = [
        Question(
            test_id=test.id, order_index=0, marks=5,
            question_type=QuestionType.mcq,
            question_text="What is the time complexity of binary search?",
            options=["O(n)", "O(log n)", "O(n²)", "O(1)"],
            correct_answer="O(log n)",
            explanation="Binary search halves the search space each step → O(log n)."
        ),
        Question(
            test_id=test.id, order_index=1, marks=5,
            question_type=QuestionType.mcq,
            question_text="Which data structure uses LIFO ordering?",
            options=["Queue", "Stack", "Heap", "Linked List"],
            correct_answer="Stack",
        ),
        Question(
            test_id=test.id, order_index=2, marks=5,
            question_type=QuestionType.mcq,
            question_text="What does CPU stand for?",
            options=["Central Processing Unit", "Computer Processing Unit", "Central Program Utility", "Core Processing Unit"],
            correct_answer="Central Processing Unit",
        ),
        Question(
            test_id=test.id, order_index=3, marks=5,
            question_type=QuestionType.multiple_correct,
            question_text="Which of the following are sorting algorithms? (Select all that apply)",
            options=["Quicksort", "Binary Search", "Mergesort", "Bubble Sort"],
            correct_answer=["Quicksort", "Mergesort", "Bubble Sort"],
        ),
        Question(
            test_id=test.id, order_index=4, marks=10,
            question_type=QuestionType.short_answer,
            question_text="Explain the difference between a process and a thread in an operating system.",
            correct_answer="A process is an independent program in execution with its own memory space. A thread is a unit of execution within a process, sharing the same memory space as other threads in the same process.",
        ),
        Question(
            test_id=test.id, order_index=5, marks=5,
            question_type=QuestionType.mcq,
            question_text="Which of the following is NOT a NoSQL database?",
            options=["MongoDB", "Cassandra", "PostgreSQL", "Redis"],
            correct_answer="PostgreSQL",
        ),
        Question(
            test_id=test.id, order_index=6, marks=5,
            question_type=QuestionType.mcq,
            question_text="What is the worst-case time complexity of QuickSort?",
            options=["O(n log n)", "O(n²)", "O(n)", "O(log n)"],
            correct_answer="O(n²)",
        ),
        Question(
            test_id=test.id, order_index=7, marks=10,
            question_type=QuestionType.coding,
            question_text="Write a Python function that reverses a string without using built-in reverse functions.\n\nExample:\n  reverse_string('hello') → 'olleh'",
            correct_answer="def reverse_string(s):\n    result = ''\n    for char in s:\n        result = char + result\n    return result",
        ),
    ]
    for q in questions:
        db.add(q)
    db.commit()

    print(f"\n✅ Demo test created!")
    print(f"   Title:       {test.title}")
    print(f"   Access Code: {test.access_code}")
    print(f"   Link:        http://localhost:3000/test/{test.access_code}")
else:
    print(f"   Test already exists: {existing_test.access_code}")

db.close()
print("\n✅ Seed complete!")
print("   Teacher login: teacher@demo.com / demo1234")
print("   Student login: student@demo.com / demo1234")
