# ── backend/models/models.py — SQLAlchemy ORM Models ──────────────────────────

from sqlalchemy import (
    Column, Integer, String, Float, Boolean, DateTime, Text, JSON,
    ForeignKey, Enum as SAEnum
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from database.db import Base


class UserRole(str, enum.Enum):
    teacher = "teacher"
    student = "student"
    admin   = "admin"


class QuestionType(str, enum.Enum):
    mcq             = "mcq"
    multiple_correct = "multiple_correct"
    short_answer    = "short_answer"
    coding          = "coding"


class ViolationType(str, enum.Enum):
    phone_detected    = "phone_detected"
    tab_switched      = "tab_switched"
    looking_away      = "looking_away"
    multiple_faces    = "multiple_faces"
    no_face           = "no_face"
    talking           = "talking"
    eye_gaze_away     = "eye_gaze_away"
    fullscreen_exit   = "fullscreen_exit"
    copy_paste        = "copy_paste"
    network_disconnect = "network_disconnect"


class User(Base):
    __tablename__ = "users"

    id           = Column(Integer, primary_key=True, index=True)
    email        = Column(String(255), unique=True, index=True, nullable=False)
    username     = Column(String(100), unique=True, index=True, nullable=False)
    full_name    = Column(String(255), nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role         = Column(SAEnum(UserRole), default=UserRole.student, nullable=False)
    is_active    = Column(Boolean, default=True)
    created_at   = Column(DateTime(timezone=True), server_default=func.now())

    created_tests  = relationship("Test", back_populates="creator")
    submissions    = relationship("Submission", back_populates="student")


class Test(Base):
    __tablename__ = "tests"

    id            = Column(Integer, primary_key=True, index=True)
    title         = Column(String(255), nullable=False)
    description   = Column(Text)
    access_code   = Column(String(20), unique=True, index=True, nullable=False)
    duration_mins = Column(Integer, nullable=False)
    total_marks   = Column(Integer, nullable=False)
    passing_marks = Column(Integer, nullable=False)
    start_time    = Column(DateTime(timezone=True))
    end_time      = Column(DateTime(timezone=True))
    is_active     = Column(Boolean, default=True)
    allow_retake  = Column(Boolean, default=False)  # teacher can enable retakes
    creator_id    = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), onupdate=func.now())

    creator     = relationship("User", back_populates="created_tests")
    questions   = relationship("Question", back_populates="test", order_by="Question.order_index", cascade="all, delete-orphan")
    submissions = relationship("Submission", back_populates="test")


class Question(Base):
    __tablename__ = "questions"

    id            = Column(Integer, primary_key=True, index=True)
    test_id       = Column(Integer, ForeignKey("tests.id"), nullable=False)
    question_text = Column(Text, nullable=False)
    question_type = Column(SAEnum(QuestionType), nullable=False)
    options       = Column(JSON)           # list of option strings for MCQ
    correct_answer = Column(JSON)          # string or list of strings
    marks         = Column(Integer, default=1)
    order_index   = Column(Integer, default=0)
    explanation   = Column(Text)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())

    test    = relationship("Test", back_populates="questions")
    answers = relationship("Answer", back_populates="question")


class Submission(Base):
    __tablename__ = "submissions"

    id               = Column(Integer, primary_key=True, index=True)
    test_id          = Column(Integer, ForeignKey("tests.id"), nullable=False)
    student_id       = Column(Integer, ForeignKey("users.id"), nullable=False)
    started_at       = Column(DateTime(timezone=True), server_default=func.now())
    submitted_at     = Column(DateTime(timezone=True))
    time_taken_secs  = Column(Integer)
    score            = Column(Float, default=0)
    max_score        = Column(Integer, default=0)
    percentage       = Column(Float, default=0)
    passed           = Column(Boolean, default=False)
    integrity_score  = Column(Float, default=100)
    risk_level       = Column(String(20), default="Low")
    is_submitted     = Column(Boolean, default=False)
    auto_submitted   = Column(Boolean, default=False)

    test     = relationship("Test", back_populates="submissions")
    student  = relationship("User", back_populates="submissions")
    answers  = relationship("Answer", back_populates="submission", cascade="all, delete-orphan")
    violations = relationship("ViolationLog", back_populates="submission", cascade="all, delete-orphan")


class Answer(Base):
    __tablename__ = "answers"

    id              = Column(Integer, primary_key=True, index=True)
    submission_id   = Column(Integer, ForeignKey("submissions.id"), nullable=False)
    question_id     = Column(Integer, ForeignKey("questions.id"), nullable=False)
    answer_text     = Column(Text)
    selected_options = Column(JSON)        # list for multiple choice
    is_correct      = Column(Boolean)
    marks_awarded   = Column(Float, default=0)
    answered_at     = Column(DateTime(timezone=True), server_default=func.now())

    submission = relationship("Submission", back_populates="answers")
    question   = relationship("Question", back_populates="answers")


class ViolationLog(Base):
    __tablename__ = "violation_logs"

    id               = Column(Integer, primary_key=True, index=True)
    submission_id    = Column(Integer, ForeignKey("submissions.id"), nullable=False)
    student_id       = Column(Integer, ForeignKey("users.id"), nullable=False)
    test_id          = Column(Integer, ForeignKey("tests.id"), nullable=False)
    violation_type   = Column(String(50), nullable=False)
    confidence_score = Column(Float, default=1.0)
    description      = Column(Text)
    evidence_path    = Column(String(500))   # path to screenshot/video clip
    timestamp        = Column(DateTime(timezone=True), server_default=func.now())
    penalty_applied  = Column(Integer, default=0)

    submission = relationship("Submission", back_populates="violations")
