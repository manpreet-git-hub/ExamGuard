# ── backend/main.py ─────────────────────────────────────────────────────────────

import sys, os

# Put the project root (one level up from backend/) on sys.path so
# `ai_proctoring` is always importable as a package, no matter how uvicorn
# is invoked or what the caller's PYTHONPATH env var happens to be. This is
# the ONE place that needs to do this — every other module in the project
# (routers/proctoring_frame.py, ai_proctoring/*) uses package-relative
# imports with a flat-import fallback, so once this path is set correctly
# here, nothing downstream needs any special PYTHONPATH setup at all.
_PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import asyncio, json, logging

from database.db import engine, Base
from routers import auth, tests, questions, submissions, proctoring, results, student, admin

logging.basicConfig(level=logging.INFO)

Base.metadata.create_all(bind=engine)

# Run lightweight migrations (adds new columns to existing DBs)
from database.db import run_migrations
run_migrations(engine)

app = FastAPI(title="ExamGuard AI Proctoring Platform", version="2.0.0")

# Allow requests from localhost AND any LAN IP (e.g. college network)
# In production you can restrict this to your specific domain
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_origin_regex=r"http://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(:\d+)?",  # any LAN IP
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs("storage/evidence", exist_ok=True)
os.makedirs("storage/logs", exist_ok=True)
app.mount("/evidence", StaticFiles(directory="storage/evidence"), name="evidence")

app.include_router(auth.router,        prefix="/api/auth",        tags=["auth"])
app.include_router(tests.router,       prefix="/api/tests",       tags=["tests"])
app.include_router(questions.router,   prefix="/api/questions",   tags=["questions"])
app.include_router(submissions.router, prefix="/api/submissions", tags=["submissions"])
app.include_router(proctoring.router,  prefix="/api/proctoring",  tags=["proctoring"])
app.include_router(results.router,     prefix="/api/results",     tags=["results"])
app.include_router(student.router,     prefix="/api/student",     tags=["student"])
app.include_router(admin.router,        prefix="/api/admin",        tags=["admin"])

# AI frame analysis (optional — only loads if ai_proctoring available)
try:
    from routers.proctoring_frame import router_frame
    app.include_router(router_frame, prefix="/api/proctoring", tags=["proctoring-ai"])
    print("[ExamGuard] AI frame analysis enabled")
except Exception as e:
    print(f"[ExamGuard] AI frame analysis unavailable: {e}")


# ── WebSocket manager ──────────────────────────────────────────────────────────
class ConnectionManager:
    def __init__(self):
        self.rooms: dict[str, list[WebSocket]] = {}

    async def connect(self, ws: WebSocket, room: str):
        await ws.accept()
        self.rooms.setdefault(room, []).append(ws)

    def disconnect(self, ws: WebSocket, room: str):
        if room in self.rooms:
            self.rooms[room] = [w for w in self.rooms[room] if w != ws]

    async def broadcast(self, msg: dict, room: str):
        dead = []
        for ws in self.rooms.get(room, []):
            try:
                await ws.send_json(msg)
            except:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws, room)

manager = ConnectionManager()


@app.websocket("/ws/proctor/{test_id}/{student_id}")
async def proctor_ws(websocket: WebSocket, test_id: str, student_id: str):
    room = f"student_{test_id}_{student_id}"
    await manager.connect(websocket, room)
    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            msg["student_id"] = student_id
            await manager.broadcast(msg, f"teacher_{test_id}")
    except WebSocketDisconnect:
        manager.disconnect(websocket, room)


@app.websocket("/ws/teacher/{test_id}")
async def teacher_ws(websocket: WebSocket, test_id: str):
    room = f"teacher_{test_id}"
    await manager.connect(websocket, room)
    try:
        while True:
            await asyncio.sleep(20)
            await websocket.send_json({"type": "heartbeat"})
    except WebSocketDisconnect:
        manager.disconnect(websocket, room)


@app.get("/")
def root():
    return {"status": "ExamGuard running", "version": "2.0.0"}

@app.get("/health")
def health():
    return {"status": "ok"}
