from datetime import datetime

from fastapi import HTTPException

from models.models import UserRole


def _normalize_dt(value):
    if value is None:
        return None
    return value.replace(tzinfo=None) if getattr(value, "tzinfo", None) else value


def validate_test_settings(*, duration_mins, total_marks, passing_marks, start_time, end_time):
    if duration_mins is not None and duration_mins <= 0:
        raise HTTPException(status_code=400, detail="Duration must be greater than 0")
    if total_marks is not None and total_marks <= 0:
        raise HTTPException(status_code=400, detail="Total marks must be greater than 0")
    if passing_marks is not None and passing_marks < 0:
        raise HTTPException(status_code=400, detail="Passing marks cannot be negative")
    if (
        total_marks is not None
        and passing_marks is not None
        and passing_marks > total_marks
    ):
        raise HTTPException(
            status_code=400,
            detail="Passing marks cannot be greater than total marks",
        )

    start_time = _normalize_dt(start_time)
    end_time = _normalize_dt(end_time)
    if start_time and end_time and end_time <= start_time:
        raise HTTPException(
            status_code=400,
            detail="End time must be later than start time",
        )


def ensure_student_user(current_user):
    if current_user.role != UserRole.student:
        raise HTTPException(
            status_code=403,
            detail="Only student accounts can take exams",
        )


def ensure_test_available_for_student(test):
    if not test or not test.is_active:
        raise HTTPException(status_code=404, detail="Test not found or inactive")

    now = datetime.utcnow()
    start_time = _normalize_dt(test.start_time)
    end_time = _normalize_dt(test.end_time)

    if start_time and now < start_time:
        raise HTTPException(status_code=403, detail="This test has not started yet")
    if end_time and now > end_time:
        raise HTTPException(status_code=403, detail="This test has already ended")

    return test
