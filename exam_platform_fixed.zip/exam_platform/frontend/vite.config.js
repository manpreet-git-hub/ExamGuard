import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({mode}) => {
  // In production build, VITE_API_URL is set to point to the backend
  // In dev, we proxy through Vite so any device on the LAN can reach the backend
  const backendHost = process.env.VITE_BACKEND_HOST || 'localhost'
  const backendPort = process.env.VITE_BACKEND_PORT || '8000'
  const backendHttp = `http://${backendHost}:${backendPort}`
  const backendWs   = `ws://${backendHost}:${backendPort}`

  return {
    plugins: [react()],
    server: {
      port: 3000,
      host: true,          // ← listen on 0.0.0.0, so LAN devices can connect
      proxy: {
        '/api':      { target: backendHttp, changeOrigin: true },
        '/ws':       { target: backendWs,   ws: true },
        '/evidence': { target: backendHttp, changeOrigin: true },
      }
    }
  }
})
