// src/pages/AdminPage.jsx — ExamGuard Admin Panel
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, BookOpen, FileText, AlertTriangle, Trash2,
  Edit2, Check, X, ChevronDown, ChevronUp, RefreshCw,
  Shield, ToggleLeft, ToggleRight, Lock, Eye, EyeOff,
  Loader2, Search, Filter, Database
} from 'lucide-react';
import toast from 'react-hot-toast';
import Layout from '../components/shared/Layout';
import api, { getEvidenceUrl } from '../utils/api';

// ── Confirm Modal ──────────────────────────────────────────────────────────────
function ConfirmModal({ message, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 max-w-sm w-full shadow-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0">
            <AlertTriangle size={18} className="text-red-400" />
          </div>
          <p className="text-sm text-gray-200">{message}</p>
        </div>
        <div className="flex gap-2 justify-end">
          <button onClick={onCancel} className="btn-secondary text-sm px-4 py-2">Cancel</button>
          <button onClick={onConfirm} className="btn-danger text-sm px-4 py-2">Delete</button>
        </div>
      </div>
    </div>
  );
}

// ── Inline Edit Input ──────────────────────────────────────────────────────────
function InlineEdit({ value, onSave, type = 'text', className = '' }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(value);
  const save = () => { onSave(val); setEditing(false); };
  const cancel = () => { setVal(value); setEditing(false); };
  if (!editing) return (
    <span className={`group flex items-center gap-1 cursor-pointer ${className}`} onClick={() => setEditing(true)}>
      {val || <span className="text-gray-600 italic">—</span>}
      <Edit2 size={11} className="opacity-0 group-hover:opacity-60 text-gray-400 flex-shrink-0" />
    </span>
  );
  return (
    <span className="flex items-center gap-1">
      <input autoFocus type={type} value={val} onChange={e => setVal(e.target.value)}
        onKeyDown={e => { if (e.key === 'Enter') save(); if (e.key === 'Escape') cancel(); }}
        className="bg-gray-800 border border-indigo-500 rounded px-2 py-0.5 text-sm text-white focus:outline-none w-36" />
      <button onClick={save} className="text-emerald-400 hover:text-emerald-300"><Check size={13} /></button>
      <button onClick={cancel} className="text-red-400 hover:text-red-300"><X size={13} /></button>
    </span>
  );
}

// ── Stat Card ──────────────────────────────────────────────────────────────────
function StatCard({ icon: Icon, label, value, color }) {
  return (
    <div className="card p-4 flex items-center gap-4">
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${color}`}>
        <Icon size={20} className="text-white" />
      </div>
      <div>
        <p className="text-2xl font-bold text-white">{value ?? '—'}</p>
        <p className="text-xs text-gray-500 mt-0.5">{label}</p>
      </div>
    </div>
  );
}

// ── Section wrapper ────────────────────────────────────────────────────────────
// `open`/`onToggle` are controlled by the parent so the expanded/collapsed state
// survives data refreshes (the parent no longer unmounts this tree on refetch,
// but keeping the state lifted also makes this robust to any future remounts).
function Section({ title, icon: Icon, count, children, open, onToggle }) {
  return (
    <div className="card overflow-hidden">
      <button onClick={onToggle}
        className="w-full flex items-center justify-between p-4 hover:bg-gray-800/50 transition-colors">
        <div className="flex items-center gap-3">
          <Icon size={18} className="text-indigo-400" />
          <span className="font-semibold text-white">{title}</span>
          {count != null && (
            <span className="text-xs bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full font-mono">{count}</span>
          )}
        </div>
        {open ? <ChevronUp size={16} className="text-gray-500" /> : <ChevronDown size={16} className="text-gray-500" />}
      </button>
      {open && <div className="border-t border-gray-800">{children}</div>}
    </div>
  );
}

// ── Search bar ─────────────────────────────────────────────────────────────────
function SearchBar({ value, onChange, placeholder }) {
  return (
    <div className="relative mb-3 mx-4 mt-3">
      <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
      <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="w-full bg-gray-800 border border-gray-700 text-sm text-gray-200 rounded-lg pl-8 pr-3 py-2 placeholder-gray-600 focus:outline-none focus:border-indigo-500" />
    </div>
  );
}

// ── MAIN PAGE ─────────────────────────────────────────────────────────────────
export default function AdminPage() {
  const navigate = useNavigate();
  const [stats, setStats]             = useState(null);
  const [users, setUsers]             = useState([]);
  const [tests, setTests]             = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [violations, setViolations]   = useState([]);
  const [loading, setLoading]         = useState(true);      // first load only — shows full-page spinner
  const [refreshing, setRefreshing]   = useState(false);     // subsequent reloads — keeps content mounted
  const [confirm, setConfirm]         = useState(null); // {msg, onConfirm}

  // Section open/closed state, lifted up so it survives data reloads
  const [openSections, setOpenSections] = useState({
    users: true, tests: false, submissions: false, violations: false,
  });
  const toggleSection = (key) => setOpenSections(prev => ({ ...prev, [key]: !prev[key] }));

  // Filters
  const [userSearch, setUserSearch]   = useState('');
  const [testSearch, setTestSearch]   = useState('');
  const [subSearch, setSubSearch]     = useState('');

  const loadAll = useCallback(async (isFirstLoad = false) => {
    if (isFirstLoad) setLoading(true);
    else setRefreshing(true);
    try {
      const [s, u, t, sub, vio] = await Promise.all([
        api.get('/api/admin/stats'),
        api.get('/api/admin/users'),
        api.get('/api/admin/tests'),
        api.get('/api/admin/submissions'),
        api.get('/api/admin/violations'),
      ]);
      setStats(s.data);
      setUsers(u.data);
      setTests(t.data);
      setSubmissions(sub.data);
      setViolations(vio.data);
    } catch (e) {
      toast.error('Failed to load admin data: ' + (e.response?.data?.detail || e.message));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { loadAll(true); }, [loadAll]);

  const ask = (msg, fn) => setConfirm({ msg, onConfirm: async () => { setConfirm(null); await fn(); await loadAll(); } });

  // ── USER ACTIONS ─────────────────────────────────────────────────────────────
  const updateUser = async (id, patch) => {
    try {
      await api.put(`/api/admin/users/${id}`, patch);
      toast.success('User updated');
      await loadAll();
    } catch (e) { toast.error(e.response?.data?.detail || 'Failed'); }
  };
  const deleteUser = (id, name) => ask(`Delete account "${name}"? This also deletes all their submissions.`,
    () => api.delete(`/api/admin/users/${id}`));

  // ── TEST ACTIONS ─────────────────────────────────────────────────────────────
  const updateTest = async (id, patch) => {
    try { await api.put(`/api/admin/tests/${id}`, patch); toast.success('Test updated'); await loadAll(); }
    catch (e) { toast.error(e.response?.data?.detail || 'Failed'); }
  };
  const deleteTest = (id, title) => ask(`Delete test "${title}" and ALL its questions, submissions, and violations?`,
    () => api.delete(`/api/admin/tests/${id}`));

  // ── SUBMISSION ACTIONS ────────────────────────────────────────────────────────
  const deleteSubmission = (id, name) => ask(`Delete submission by "${name}"? Answers and violations will also be deleted.`,
    () => api.delete(`/api/admin/submissions/${id}`));
  const clearViolations = (id, name) => ask(`Clear ALL violations for "${name}"'s submission and reset integrity to 100?`,
    async () => { await api.delete(`/api/admin/submissions/${id}/violations`); });

  // ── VIOLATION ACTIONS ─────────────────────────────────────────────────────────
  const deleteViolation = (id) => ask('Delete this violation log entry?',
    () => api.delete(`/api/admin/violations/${id}`));

  // ── FILTERED DATA ─────────────────────────────────────────────────────────────
  const filteredUsers = users.filter(u =>
    u.full_name.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.username.toLowerCase().includes(userSearch.toLowerCase())
  );
  const filteredTests = tests.filter(t =>
    t.title.toLowerCase().includes(testSearch.toLowerCase()) ||
    t.access_code.toLowerCase().includes(testSearch.toLowerCase()) ||
    t.creator_name.toLowerCase().includes(testSearch.toLowerCase())
  );
  const filteredSubs = submissions.filter(s =>
    s.student_name.toLowerCase().includes(subSearch.toLowerCase()) ||
    s.test_title.toLowerCase().includes(subSearch.toLowerCase()) ||
    s.student_email.toLowerCase().includes(subSearch.toLowerCase())
  );

  if (loading) return (
    <Layout title="Admin Panel">
      <div className="flex items-center justify-center h-64">
        <Loader2 size={32} className="animate-spin text-indigo-500" />
      </div>
    </Layout>
  );

  return (
    <Layout title="Admin Panel">
      {confirm && <ConfirmModal message={confirm.msg} onConfirm={confirm.onConfirm} onCancel={() => setConfirm(null)} />}

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center">
            <Database size={18} className="text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white">Admin Panel</h1>
            <p className="text-xs text-gray-500">Manage all database records</p>
          </div>
        </div>
        <button onClick={() => loadAll()} className="btn-secondary text-xs px-3 py-2">
          <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} /> Refresh
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <StatCard icon={Users}      label="Total Users"       value={stats.total_users}        color="bg-indigo-600" />
          <StatCard icon={BookOpen}   label="Tests"             value={stats.total_tests}         color="bg-emerald-600" />
          <StatCard icon={FileText}   label="Submissions"       value={stats.total_submissions}   color="bg-amber-600" />
          <StatCard icon={AlertTriangle} label="Violations"     value={stats.total_violations}    color="bg-red-600" />
        </div>
      )}

      <div className="space-y-4">

        {/* ── USERS ── */}
        <Section icon={Users} title="User Accounts" count={users.length} open={openSections.users} onToggle={() => toggleSection('users')}>
          <SearchBar value={userSearch} onChange={setUserSearch} placeholder="Search by name, email or username…" />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-gray-500 border-b border-gray-800">
                  <th className="text-left px-4 py-2 font-medium">ID</th>
                  <th className="text-left px-4 py-2 font-medium">Name</th>
                  <th className="text-left px-4 py-2 font-medium">Email</th>
                  <th className="text-left px-4 py-2 font-medium">Username</th>
                  <th className="text-left px-4 py-2 font-medium">Role</th>
                  <th className="text-left px-4 py-2 font-medium">Status</th>
                  <th className="text-left px-4 py-2 font-medium">Submissions</th>
                  <th className="text-left px-4 py-2 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map(u => (
                  <tr key={u.id} className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors">
                    <td className="px-4 py-3 text-gray-500 font-mono text-xs">{u.id}</td>
                    <td className="px-4 py-3 text-white font-medium">
                      <InlineEdit value={u.full_name} onSave={v => updateUser(u.id, { full_name: v })} />
                    </td>
                    <td className="px-4 py-3 text-gray-400">
                      <InlineEdit value={u.email} onSave={v => updateUser(u.id, { email: v })} />
                    </td>
                    <td className="px-4 py-3 text-gray-400">
                      <InlineEdit value={u.username} onSave={v => updateUser(u.id, { username: v })} />
                    </td>
                    <td className="px-4 py-3">
                      <select value={u.role}
                        onChange={e => updateUser(u.id, { role: e.target.value })}
                        className="bg-gray-800 border border-gray-700 text-xs rounded px-2 py-1 text-gray-200 focus:outline-none focus:border-indigo-500">
                        <option value="student">Student</option>
                        <option value="teacher">Teacher</option>
                        <option value="admin">Admin</option>
                      </select>
                    </td>
                    <td className="px-4 py-3">
                      <button onClick={() => updateUser(u.id, { is_active: !u.is_active })}
                        className={`flex items-center gap-1 text-xs font-medium transition-colors ${u.is_active ? 'text-emerald-400 hover:text-emerald-300' : 'text-red-400 hover:text-red-300'}`}>
                        {u.is_active ? <ToggleRight size={16} /> : <ToggleLeft size={16} />}
                        {u.is_active ? 'Active' : 'Inactive'}
                      </button>
                    </td>
                    <td className="px-4 py-3 text-gray-500 font-mono text-xs">{u.submission_count}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <button title="Reset password to 'resetpass123'"
                          onClick={() => { if(window.confirm(`Reset password for ${u.email} to "resetpass123"?`)) updateUser(u.id, { new_password: 'resetpass123' }); }}
                          className="text-amber-500 hover:text-amber-400 transition-colors" >
                          <Lock size={14} />
                        </button>
                        <button onClick={() => deleteUser(u.id, u.full_name)}
                          className="text-red-500 hover:text-red-400 transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredUsers.length === 0 && (
              <p className="text-center text-gray-600 text-sm py-8">No users found</p>
            )}
          </div>
        </Section>

        {/* ── TESTS ── */}
        <Section icon={BookOpen} title="Tests" count={tests.length} open={openSections.tests} onToggle={() => toggleSection('tests')}>
          <SearchBar value={testSearch} onChange={setTestSearch} placeholder="Search by title, code or teacher…" />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-gray-500 border-b border-gray-800">
                  <th className="text-left px-4 py-2 font-medium">ID</th>
                  <th className="text-left px-4 py-2 font-medium">Title</th>
                  <th className="text-left px-4 py-2 font-medium">Code</th>
                  <th className="text-left px-4 py-2 font-medium">Teacher</th>
                  <th className="text-left px-4 py-2 font-medium">Start / End Time</th>
                  <th className="text-left px-4 py-2 font-medium">Marks</th>
                  <th className="text-left px-4 py-2 font-medium">Qs</th>
                  <th className="text-left px-4 py-2 font-medium">Submissions</th>
                  <th className="text-left px-4 py-2 font-medium">Active</th>
                  <th className="text-left px-4 py-2 font-medium">Retake</th>
                  <th className="text-left px-4 py-2 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredTests.map(t => (
                  <tr key={t.id} className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors">
                    <td className="px-4 py-3 text-gray-500 font-mono text-xs">{t.id}</td>
                    <td className="px-4 py-3 text-white font-medium max-w-[180px]">
                      <InlineEdit value={t.title} onSave={v => updateTest(t.id, { title: v })} />
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-indigo-300 bg-indigo-500/10 rounded">{t.access_code}</td>
                    <td className="px-4 py-3 text-gray-400 text-xs">{t.creator_name}</td>
                    <td className="px-4 py-3">
                      <div className="flex flex-col gap-1">
                        <input type="datetime-local"
                          defaultValue={t.start_time ? new Date(t.start_time).toISOString().slice(0,16) : ''}
                          onChange={e => updateTest(t.id, { start_time: e.target.value ? new Date(e.target.value).toISOString() : null })}
                          className="bg-gray-800 border border-gray-700 text-xs text-gray-300 rounded px-1.5 py-1 focus:outline-none focus:border-indigo-500 w-36"
                          title="Start time"
                        />
                        <input type="datetime-local"
                          defaultValue={t.end_time ? new Date(t.end_time).toISOString().slice(0,16) : ''}
                          onChange={e => updateTest(t.id, { end_time: e.target.value ? new Date(e.target.value).toISOString() : null })}
                          className="bg-gray-800 border border-gray-700 text-xs text-gray-300 rounded px-1.5 py-1 focus:outline-none focus:border-indigo-500 w-36"
                          title="End time"
                        />
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-400 font-mono text-xs">{t.passing_marks}/{t.total_marks}</td>
                    <td className="px-4 py-3 text-gray-400 font-mono text-xs">{t.question_count}</td>
                    <td className="px-4 py-3 text-gray-400 font-mono text-xs">{t.submission_count}</td>
                    <td className="px-4 py-3">
                      <button onClick={() => updateTest(t.id, { is_active: !t.is_active })}
                        className={`text-xs font-medium transition-colors ${t.is_active ? 'text-emerald-400 hover:text-emerald-300' : 'text-red-400 hover:text-red-300'}`}>
                        {t.is_active ? <ToggleRight size={16} /> : <ToggleLeft size={16} />}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <button onClick={() => updateTest(t.id, { allow_retake: !t.allow_retake })}
                        className={`text-xs font-medium transition-colors ${t.allow_retake ? 'text-amber-400 hover:text-amber-300' : 'text-gray-600 hover:text-gray-400'}`}>
                        {t.allow_retake ? <ToggleRight size={16} /> : <ToggleLeft size={16} />}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <button title="View Questions" onClick={() => navigate(`/tests/${t.id}/manage`)}
                          className="text-indigo-400 hover:text-indigo-300 transition-colors">
                          <Eye size={14} />
                        </button>
                        <button onClick={() => deleteTest(t.id, t.title)}
                          className="text-red-500 hover:text-red-400 transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredTests.length === 0 && (
              <p className="text-center text-gray-600 text-sm py-8">No tests found</p>
            )}
          </div>
        </Section>

        {/* ── SUBMISSIONS ── */}
        <Section icon={FileText} title="Submissions" count={submissions.length} open={openSections.submissions} onToggle={() => toggleSection('submissions')}>
          <SearchBar value={subSearch} onChange={setSubSearch} placeholder="Search by student name, email or test…" />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-gray-500 border-b border-gray-800">
                  <th className="text-left px-4 py-2 font-medium">ID</th>
                  <th className="text-left px-4 py-2 font-medium">Student</th>
                  <th className="text-left px-4 py-2 font-medium">Test</th>
                  <th className="text-left px-4 py-2 font-medium">Score</th>
                  <th className="text-left px-4 py-2 font-medium">Status</th>
                  <th className="text-left px-4 py-2 font-medium">Integrity</th>
                  <th className="text-left px-4 py-2 font-medium">Violations</th>
                  <th className="text-left px-4 py-2 font-medium">Submitted</th>
                  <th className="text-left px-4 py-2 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredSubs.map(s => (
                  <tr key={s.id} className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors">
                    <td className="px-4 py-3 text-gray-500 font-mono text-xs">{s.id}</td>
                    <td className="px-4 py-3">
                      <p className="text-white text-xs font-medium">{s.student_name}</p>
                      <p className="text-gray-500 text-xs">{s.student_email}</p>
                    </td>
                    <td className="px-4 py-3 text-gray-400 text-xs max-w-[140px] truncate">{s.test_title}</td>
                    <td className="px-4 py-3 font-mono text-xs">
                      <span className={s.passed ? 'text-emerald-400' : 'text-red-400'}>
                        {s.score}/{s.max_score}
                      </span>
                      <span className="text-gray-600 ml-1">({(s.percentage||0).toFixed(0)}%)</span>
                    </td>
                    <td className="px-4 py-3">
                      {s.is_submitted
                        ? <span className="badge-green text-xs">Submitted</span>
                        : <span className="badge-yellow text-xs">In Progress</span>}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`font-mono text-xs ${s.integrity_score >= 80 ? 'text-emerald-400' : s.integrity_score >= 50 ? 'text-amber-400' : 'text-red-400'}`}>
                        {Math.round(s.integrity_score)}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {s.violations_count > 0
                        ? <span className="text-red-400 text-xs font-mono">{s.violations_count}</span>
                        : <span className="text-gray-600 text-xs">—</span>}
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-xs font-mono">
                      {s.submitted_at ? new Date(s.submitted_at).toLocaleDateString('en-IN') : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {s.violations_count > 0 && (
                          <button title="Clear all violations & reset integrity"
                            onClick={() => clearViolations(s.id, s.student_name)}
                            className="text-amber-500 hover:text-amber-400 transition-colors">
                            <Shield size={14} />
                          </button>
                        )}
                        <button title="View submission detail"
                          onClick={() => navigate(`/tests/${s.test_id}/results/${s.id}`)}
                          className="text-indigo-400 hover:text-indigo-300 transition-colors">
                          <Eye size={14} />
                        </button>
                        <button onClick={() => deleteSubmission(s.id, s.student_name)}
                          className="text-red-500 hover:text-red-400 transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredSubs.length === 0 && (
              <p className="text-center text-gray-600 text-sm py-8">No submissions found</p>
            )}
          </div>
        </Section>

        {/* ── VIOLATIONS ── */}
        <Section icon={AlertTriangle} title="Violation Logs" count={violations.length} open={openSections.violations} onToggle={() => toggleSection('violations')}>
          <div className="p-4">
            <p className="text-xs text-gray-500 mb-3">Showing latest 500 violations. Use <span className="text-indigo-300">"Clear violations"</span> on a submission to bulk-remove.</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-gray-500 border-b border-gray-800">
                  <th className="text-left px-4 py-2 font-medium">ID</th>
                  <th className="text-left px-4 py-2 font-medium">Type</th>
                  <th className="text-left px-4 py-2 font-medium">Sub ID</th>
                  <th className="text-left px-4 py-2 font-medium">Description</th>
                  <th className="text-left px-4 py-2 font-medium">Penalty</th>
                  <th className="text-left px-4 py-2 font-medium">Evidence</th>
                  <th className="text-left px-4 py-2 font-medium">Time</th>
                  <th className="text-left px-4 py-2 font-medium">Delete</th>
                </tr>
              </thead>
              <tbody>
                {violations.map(v => (
                  <tr key={v.id} className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors">
                    <td className="px-4 py-3 text-gray-500 font-mono text-xs">{v.id}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                        ['phone_detected','multiple_faces','laptop_detected'].includes(v.violation_type)
                          ? 'bg-red-500/20 text-red-400'
                          : 'bg-amber-500/20 text-amber-400'
                      }`}>
                        {v.violation_type.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-400 font-mono text-xs">{v.submission_id}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs max-w-[180px] truncate">{v.description || '—'}</td>
                    <td className="px-4 py-3 text-red-400 font-mono text-xs">−{v.penalty_applied}</td>
                    <td className="px-4 py-3">
                      {v.evidence_path
                        ? <a href={getEvidenceUrl(v.evidence_path)} target="_blank" rel="noopener noreferrer"
                            className="text-indigo-400 hover:text-indigo-300 text-xs underline">View</a>
                        : <span className="text-gray-600 text-xs">—</span>}
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-xs font-mono">
                      {v.timestamp ? new Date(v.timestamp).toLocaleTimeString('en-IN') : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <button onClick={() => deleteViolation(v.id)}
                        className="text-red-500 hover:text-red-400 transition-colors">
                        <Trash2 size={13} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {violations.length === 0 && (
              <p className="text-center text-gray-600 text-sm py-8">No violations logged</p>
            )}
          </div>
        </Section>

      </div>
    </Layout>
  );
}
