# -- runtime_state.py -- Per-session state store --------------------------------
# In the standalone Streamlit app, st.session_state already gives each browser
# tab its own isolated state. But when this module is imported from the FastAPI
# backend (backend/routers/proctoring_frame.py), there is no Streamlit context,
# so we fall back to a plain dict -- and every request into the backend process
# shares that same process, no matter which student it came from.
#
# Without a session key, all students taking an exam at the same time were
# reading and writing the SAME "prev_mouth_dist" / "talking_counter" values,
# so one student's mouth movement affected another student's talking-detection
# result. The fallback store below is now keyed per session (the exam
# submission id), so each student's detector state is completely isolated.

_FALLBACK_STATE = {}          # { session_key: { key: value } }
_DEFAULT_BUCKET = "__default__"


def _streamlit_state():
    """Return st.session_state ONLY when actually running inside a live
    `streamlit run` script -- never merely because streamlit happens to be
    importable. Checking get_script_run_ctx() is what makes this safe to
    call from the FastAPI backend even when streamlit IS installed in the
    same environment: without this check, touching st.session_state outside
    a real Streamlit script thread fires a 'missing ScriptRunContext!'
    warning (and re-imports streamlit internals) on every single call --
    which is exactly the noise/overhead this was producing once per
    analyzed video frame when get_state() is called from process_frame()."""
    try:
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        if get_script_run_ctx() is None:
            return None
        import streamlit as st
        return st.session_state
    except Exception:
        return None


def get_state(key, default=None, session_id=None):
    state = _streamlit_state()
    if state is not None:
        if key not in state:
            state[key] = default
        return state[key]

    bucket = _FALLBACK_STATE.setdefault(session_id or _DEFAULT_BUCKET, {})
    if key not in bucket:
        bucket[key] = default
    return bucket[key]


def set_state(key, value, session_id=None):
    state = _streamlit_state()
    if state is not None:
        state[key] = value
        return value

    bucket = _FALLBACK_STATE.setdefault(session_id or _DEFAULT_BUCKET, {})
    bucket[key] = value
    return value


def clear_session(session_id):
    """Drop all stored detector state for a session (e.g. once a submission ends)."""
    _FALLBACK_STATE.pop(session_id or _DEFAULT_BUCKET, None)
