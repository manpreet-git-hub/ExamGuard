# -- utils/logger.py -- CSV violation logging system ----------------------------
# This is Streamlit-demo-only (log_event reads/writes st.session_state, which
# only meaningfully exists inside a live `streamlit run` script). It is kept
# importable with no streamlit installed at all so that FastAPI backend code
# which transitively imports this module (via video_recorder.py) never fails
# to import -- log_event() itself is simply a no-op outside a real Streamlit
# session, which matches the fact the backend never calls it.

import csv
from datetime import datetime

try:
    from streamlit.runtime.scriptrunner import get_script_run_ctx
    import streamlit as st
except ImportError:
    get_script_run_ctx = None
    st = None


def _in_streamlit() -> bool:
    return st is not None and get_script_run_ctx is not None and get_script_run_ctx() is not None


def log_event(event: str, penalty: int = 0):
    """
    Append a violation to the rolling in-memory log and write a CSV row.
    No-op if not running inside a live Streamlit script (e.g. called from
    the FastAPI backend, which has its own independent DB-backed logging).

    Args:
        event:   Human-readable description of the violation.
        penalty: Points deducted (0 if informational only).
    """
    if not _in_streamlit():
        return

    ts  = datetime.now().strftime("%H:%M:%S")
    lvl = (
        "red"
        if any(w in event for w in ["Phone", "Multiple", "ALERT", "No Face"])
        else "yellow"
    )
    entry = {
        "text":        event,
        "time":        ts,
        "level":       lvl,
        "penalty":     penalty,
        "score_after": st.session_state.integrity_score,
    }
    st.session_state.violations.appendleft(entry)
    st.session_state.total_viol += 1

    try:
        with open("proctor_log.csv", "a", newline="") as f:
            csv.writer(f).writerow([
                datetime.now().isoformat(),
                event,
                f"-{penalty}" if penalty else "0",
                st.session_state.integrity_score,
            ])
    except Exception:
        pass


def log_evidence_row(record: dict):
    """
    Write an evidence-capture event to the CSV log. Safe to call regardless
    of whether Streamlit is running -- this one only touches the filesystem,
    not session state.

    Args:
        record: Evidence record dict containing ts_iso, label, score, filename.
    """
    try:
        with open("proctor_log.csv", "a", newline="") as f:
            csv.writer(f).writerow([
                record["ts_iso"],
                f"EVIDENCE_CAPTURE - {record['label']}",
                "0",
                record["score"],
                record["filename"],
            ])
    except Exception:
        pass
