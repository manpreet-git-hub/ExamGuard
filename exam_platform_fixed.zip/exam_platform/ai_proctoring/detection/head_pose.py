# ── detection/head_pose.py — Head pose estimation ─────────────────────────────

# These thresholds were previously tight enough that ordinary, small head
# movements (e.g. glancing slightly down-and-right to click something on
# screen) were being flagged as "looking away". They've been widened so a
# violation only fires on a genuine, deliberate turn of the head.
HORIZONTAL_THRESH_RATIO = 0.40   # was 0.25 — nose must shift further off-center
DOWN_THRESH_RATIO       = 0.60   # was 0.45 — looking down at keyboard/desk allowed
UP_THRESH_RATIO         = 0.30   # was 0.15 (as a magnitude) — small upward tilt allowed


def get_head_pose(face):
    """
    Estimate head orientation from key facial landmarks.

    Args:
        face: list of [x, y] pixel coordinates for all FaceMesh landmarks.

    Returns:
        tuple: (direction_str, state_str)
            direction_str: "Looking Center" | "Looking Right" | "Looking Left" |
                           "Looking Down"  | "Looking Up"
            state_str:     "ok" | "warn" | "alert"
    """
    nose      = face[4]
    left_eye  = face[33]
    right_eye = face[263]
    chin      = face[152]

    eye_cx = (left_eye[0] + right_eye[0]) // 2
    eye_cy = (left_eye[1] + right_eye[1]) // 2
    face_w = abs(right_eye[0] - left_eye[0])
    face_h = abs(chin[1] - eye_cy)
    thresh = face_w * HORIZONTAL_THRESH_RATIO

    if nose[0] > eye_cx + thresh:
        return "Looking Right", "warn"
    if nose[0] < eye_cx - thresh:
        return "Looking Left", "warn"
    if face_h > 0 and nose[1] - eye_cy > face_h * DOWN_THRESH_RATIO:
        return "Looking Down", "alert"
    if face_h > 0 and nose[1] - eye_cy < -face_h * UP_THRESH_RATIO:
        return "Looking Up", "alert"
    return "Looking Center", "ok"
