# ── detection/talking_detection.py — Mouth-movement / talking detection ────────

try:
    from ai_proctoring.runtime_state import get_state, set_state
except ImportError:
    from runtime_state import get_state, set_state

# Movement is measured as the change in mouth-opening gap, NORMALIZED by the
# mouth width. Using a normalized ratio (instead of a raw pixel distance)
# makes the detector work the same regardless of how close the student is
# sitting to the camera or their camera's resolution — a raw pixel threshold
# is too strict for someone far from the camera and too lax for someone close.
#
# The decision is made on a SINGLE frame-to-frame comparison (previous
# captured frame vs current one) — no multi-frame build-up — so a talking
# violation fires the moment it's detected, with no added delay beyond the
# capture interval itself.
MOVEMENT_RATIO_THRESHOLD = 0.045   # frame-to-frame lip-gap change that counts as movement
OPEN_RATIO_THRESHOLD     = 0.14    # mouth held open this wide also counts, even with
                                    # little frame-to-frame delta (catches sustained talking
                                    # between two sparse captures where the mouth stayed open)


def detect_talking(face, session_id=None):
    """
    Detect whether the subject is talking by measuring lip-gap movement,
    normalized against mouth width so it works at any camera distance.

    Args:
        face: list of [x, y] pixel coordinates for all FaceMesh landmarks.
        session_id: unique key (e.g. submission id) isolating this student's
            rolling state from every other student's, so concurrent exam
            takers never see each other's mouth-movement history.

    Returns:
        bool: True if talking is detected.
    """
    upper       = face[13]    # inner upper lip
    lower       = face[14]    # inner lower lip
    left_mouth  = face[61]    # left mouth corner
    right_mouth = face[291]   # right mouth corner

    mouth_width = abs(right_mouth[0] - left_mouth[0])
    if mouth_width == 0:
        return False

    gap_ratio = abs(upper[1] - lower[1]) / mouth_width

    prev_ratio = get_state("prev_mouth_ratio", gap_ratio, session_id=session_id)
    movement = abs(gap_ratio - prev_ratio)
    set_state("prev_mouth_ratio", gap_ratio, session_id=session_id)

    return movement > MOVEMENT_RATIO_THRESHOLD or gap_ratio > OPEN_RATIO_THRESHOLD
