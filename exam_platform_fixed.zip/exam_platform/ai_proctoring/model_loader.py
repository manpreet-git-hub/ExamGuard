# -- ai_proctoring/model_loader.py -- Load MediaPipe + YOLO models -------------
#
# Import style: every internal import here is wrapped in try/except so this
# module works identically whether it's imported as a package
# (from ai_proctoring.model_loader import load_models, used by the FastAPI
# backend) or run flat with ai_proctoring/ itself on sys.path (used by the
# standalone ai_proctoring/app.py Streamlit demo). This dual-style pattern is
# used consistently across every file in this package now -- previously only
# some files had the fallback and others didn't, which is what caused
# "ModuleNotFoundError: No module named 'config'" when this file was
# imported as ai_proctoring.model_loader from the backend.

from functools import lru_cache
import logging

logger = logging.getLogger(__name__)

# -- Graceful imports of optional heavy ML libraries ----------------------------
try:
    import mediapipe as mp
    MEDIAPIPE_OK = True
except ImportError:
    MEDIAPIPE_OK = False

try:
    from ultralytics import YOLO
    YOLO_OK = True
except ImportError:
    YOLO_OK = False

# -- Package-relative imports, with flat fallback --------------------------------
try:
    from ai_proctoring.config import (
        FACE_DETECTION_CONFIDENCE,
        FACE_MESH_MAX_FACES,
        FACE_MESH_DETECTION_CONF,
        FACE_MESH_TRACKING_CONF,
    )
    from ai_proctoring.detection.opencv_fallback import load_cascades
except ImportError:
    from config import (
        FACE_DETECTION_CONFIDENCE,
        FACE_MESH_MAX_FACES,
        FACE_MESH_DETECTION_CONF,
        FACE_MESH_TRACKING_CONF,
    )
    from detection.opencv_fallback import load_cascades


@lru_cache(maxsize=1)
def load_models():
    """Load and cache all ML models. Returns a dict of model handles.

    Never raises -- any model that fails to load is simply omitted from the
    returned dict, and a warning is logged. Callers should check for the
    presence of a key (e.g. "face_mesh" in models) rather than assuming
    everything loaded.
    """
    models = {}
    models.update(load_cascades())

    if MEDIAPIPE_OK:
        try:
            mp_face = mp.solutions.face_detection
            models["face_det"] = mp_face.FaceDetection(
                min_detection_confidence=FACE_DETECTION_CONFIDENCE
            )
        except Exception as exc:
            logger.warning("MediaPipe face detection unavailable: %s", exc)
        try:
            mp_mesh = mp.solutions.face_mesh
            models["face_mesh"] = mp_mesh.FaceMesh(
                max_num_faces=FACE_MESH_MAX_FACES,
                refine_landmarks=True,
                min_detection_confidence=FACE_MESH_DETECTION_CONF,
                min_tracking_confidence=FACE_MESH_TRACKING_CONF,
            )
        except Exception as exc:
            logger.warning("MediaPipe face mesh unavailable: %s", exc)
    else:
        logger.warning(
            "MediaPipe is not installed/importable -- face mesh, head pose, "
            "eye gaze, and talking detection will all be unavailable. Only "
            "OpenCV Haar-cascade face boxes and YOLO device detection will run."
        )

    if YOLO_OK:
        # Prefer the small/medium model first: it's fast enough for real-time
        # per-frame webcam inference and its weights are much less likely to
        # be a corrupted/partial download than the huge x/l variants. Larger
        # models are only tried if you've deliberately placed their .pt files
        # next to this one and want the extra accuracy.
        for model_name in ("yolov8n.pt", "yolov8s.pt", "yolov8m.pt", "yolov8l.pt", "yolov8x.pt"):
            try:
                models["yolo"] = YOLO(model_name)
                models["yolo_model_name"] = model_name
                break
            except Exception as exc:
                logger.warning("YOLO model %s unavailable: %s", model_name, exc)
                continue
    else:
        logger.warning("Ultralytics/YOLO is not installed/importable -- phone/laptop detection will be unavailable.")

    return models
