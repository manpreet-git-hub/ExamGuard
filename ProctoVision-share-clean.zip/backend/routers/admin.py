# ── backend/routers/admin.py — Admin Panel API ────────────────────────────────
import io
import csv
import re
import zipfile
import xml.etree.ElementTree as ET

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone

from database.db import get_db
from models.models import User, Test, Question, Submission, ViolationLog, UserRole
from routers.auth import get_current_user, get_password_hash
from utils.csv_headers import (
    norm_header as _norm_header,
    ID_HEADERS, NAME_HEADERS, EMAIL_HEADERS, COURSE_HEADERS, PASSWORD_HEADERS,
)
from utils.evidence import delete_evidence_files
from utils.generators import generate_password

router = APIRouter()


def require_admin_or_teacher(current_user: User = Depends(get_current_user)):
    if current_user.role not in [UserRole.teacher, UserRole.admin]:
        raise HTTPException(status_code=403, detail="Admin/Teacher access required")
    return current_user


def require_admin_only(current_user: User = Depends(get_current_user)):
    if current_user.role != UserRole.admin:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user


def _is_admin(user: User) -> bool:
    return user.role == UserRole.admin


def _teacher_test_ids(db, current_user):
    """IDs of the tests this user created (admins get every test id)."""
    rows = db.query(Test.id)
    if not _is_admin(current_user):
        rows = rows.filter(Test.creator_id == current_user.id)
    return [r[0] for r in rows.all()]


def _ensure_test_owned(test, current_user):
    """Teachers may only touch tests they created; admins may touch any."""
    if test is None or (not _is_admin(current_user) and test.creator_id != current_user.id):
        raise HTTPException(status_code=404, detail="Test not found")
    return test


# ── STATS ─────────────────────────────────────────────────────────────────────

def _period_starts():
    """Naive-UTC start instants for 'this month' and 'this year' in the
    server's local timezone. Rows are stored as naive UTC, so a local
    midnight/mid-year is converted to the matching UTC instant before comparing."""
    now = datetime.now()
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    year_start = datetime(now.year, 1, 1)

    def to_utc_naive(dt):
        return dt.astimezone(timezone.utc).replace(tzinfo=None)

    return to_utc_naive(month_start), to_utc_naive(year_start)


@router.get("/stats")
def get_stats(db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    if _is_admin(current_user):
        month_start, year_start = _period_starts()
        return {
            "total_users":       db.query(User).count(),
            "total_students":    db.query(User).filter(User.role == UserRole.student).count(),
            "total_teachers":    db.query(User).filter(User.role == UserRole.teacher).count(),
            "total_tests":       db.query(Test).count(),
            "total_questions":   db.query(Question).count(),
            "total_submissions": db.query(Submission).count(),
            "total_violations":  db.query(ViolationLog).count(),
            "active_tests":      db.query(Test).filter(Test.is_active == True).count(),
            # History buckets across EVERY teacher's activity
            "tests_this_year":       db.query(Test).filter(Test.created_at >= year_start).count(),
            "tests_this_month":      db.query(Test).filter(Test.created_at >= month_start).count(),
            "submissions_this_year": db.query(Submission).filter(Submission.started_at >= year_start).count(),
            "submissions_this_month": db.query(Submission).filter(Submission.started_at >= month_start).count(),
        }

    # Teachers only ever see numbers for the tests they created.
    test_ids = _teacher_test_ids(db, current_user)
    if test_ids:
        total_questions = db.query(Question).filter(Question.test_id.in_(test_ids)).count()
        total_submissions = db.query(Submission).filter(Submission.test_id.in_(test_ids)).count()
        total_violations = db.query(ViolationLog).filter(ViolationLog.test_id.in_(test_ids)).count()
        active_tests = db.query(Test).filter(
            Test.id.in_(test_ids), Test.is_active == True
        ).count()
    else:
        total_questions = total_submissions = total_violations = active_tests = 0

    return {
        "total_tests":       len(test_ids),
        "total_questions":   total_questions,
        "total_submissions": total_submissions,
        "total_violations":  total_violations,
        "active_tests":      active_tests,
    }


# ── USERS ─────────────────────────────────────────────────────────────────────

@router.get("/users")
def list_users(db: Session = Depends(get_db), current_user: User = Depends(require_admin_only)):
    users = db.query(User).order_by(User.created_at.desc()).all()
    return [
        {
            "id":         u.id,
            "full_name":  u.full_name,
            "email":      u.email,
            "course":     u.course,
            "student_id": u.student_id,
            "teacher_id": u.teacher_id,
            "role":       u.role.value,
            "is_active":  u.is_active,
            "must_change_password": bool(u.must_change_password),
            "created_at": u.created_at,
            "submission_count": len(u.submissions),
        }
        for u in users
    ]


class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    email:     Optional[str] = None
    course:    Optional[str] = None
    role:      Optional[str] = None
    is_active: Optional[bool] = None
    new_password: Optional[str] = None
    # Force the account back onto the "must pick a new password" prompt.
    must_change_password: Optional[bool] = None


@router.put("/users/{user_id}")
def update_user(user_id: int, data: UserUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin_only)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if data.full_name  is not None: user.full_name  = data.full_name
    if data.email      is not None: user.email      = data.email
    if data.course     is not None: user.course     = data.course
    if data.is_active  is not None: user.is_active  = data.is_active
    if data.role       is not None: user.role       = UserRole(data.role)
    if data.new_password:
        # A password handed out by the admin is a default one — make the
        # user choose their own at next login unless told otherwise.
        user.hashed_password = get_password_hash(data.new_password)
        if data.must_change_password is None:
            user.must_change_password = True
    if data.must_change_password is not None:
        user.must_change_password = data.must_change_password
    db.commit()
    db.refresh(user)
    return {"detail": "User updated", "id": user.id}


@router.delete("/users/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin_only)):
    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(user)
    db.commit()
    return {"detail": "User deleted"}


# ── BULK ACCOUNT CREATION (students + teachers) ───────────────────────────────

MAX_IMPORT_ROWS = 1000


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")

# Letters/digits plus the separators institutions use inside roll numbers.
ENROLLMENT_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\-]{1,29}$")


def _parse_xlsx(data: bytes) -> List[List[str]]:
    """Every cell of the first worksheet, grouped by row (stdlib, no openpyxl)."""
    def col_index(ref):
        letters = "".join(ch for ch in (ref or "") if ch.isalpha())
        if not letters:
            return None
        n = 0
        for ch in letters.upper():
            n = n * 26 + (ord(ch) - 64)
        return n - 1

    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        shared: List[str] = []
        if "xl/sharedStrings.xml" in zf.namelist():
            root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in root:
                shared.append("".join(t.text or "" for t in si.iter() if t.tag.endswith("}t")))

        sheet = next(
            (n for n in sorted(zf.namelist()) if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", n)),
            None,
        )
        if not sheet:
            raise ValueError("No worksheet found in the Excel file")
        root = ET.fromstring(zf.read(sheet))

        table: List[List[str]] = []
        for row in root.iter():
            if not row.tag.endswith("}row"):
                continue
            cells: dict = {}
            for cell in row:
                if not cell.tag.endswith("}c"):
                    continue
                ctype = cell.get("t")
                if ctype == "inlineStr":
                    node = next((e for e in cell if e.tag.endswith("}is")), None)
                    text = "".join(t.text or "" for t in node.iter() if t.tag.endswith("}t")) if node is not None else ""
                else:
                    node = next((e for e in cell if e.tag.endswith("}v")), None)
                    text = node.text or "" if node is not None else ""
                    if ctype == "s" and text.isdigit() and int(text) < len(shared):
                        text = shared[int(text)]
                idx = col_index(cell.get("r"))
                if idx is None:
                    idx = len(cells)
                cells[idx] = (text or "").strip()
            width = (max(cells) + 1) if cells else 0
            table.append([cells.get(i, "") for i in range(width)])
        return table


def _parse_table(filename: str, data: bytes) -> List[List[str]]:
    """Turn an uploaded .txt/.csv/.xlsx into rows of (trimmed) cells."""
    lower = (filename or "").lower()
    if lower.endswith(".xlsx") or data[:2] == b"PK":
        return _parse_xlsx(data)
    text = data.decode("utf-8-sig", errors="replace")
    return [[(cell or "").strip() for cell in row] for row in csv.reader(io.StringIO(text))]


def _cell(row: List[str], idx) -> str:
    if idx is None or idx >= len(row):
        return ""
    return (row[idx] or "").strip()


@router.post("/users/import", status_code=201)
async def import_users(
    file: UploadFile = File(...),
    role: str = Form("student"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin_only),
):
    """Create accounts from an uploaded .txt / .csv / .xlsx.

    Accepted formats:
      * Column CSV with a header row — roll_no, name, email, course
        (password column optional; missing email/password are generated)
      * Plain list of IDs, one per row — email + password are generated

    `role` is 'student' or 'teacher': students get a student_id, teachers get a
    teacher_id, each with their own default email domain.
    """
    if role not in ("student", "teacher"):
        raise HTTPException(status_code=400, detail="role must be 'student' or 'teacher'")

    is_teacher = role == "teacher"
    id_column  = User.teacher_id if is_teacher else User.student_id
    id_field   = "teacher_id" if is_teacher else "student_id"
    domain     = "teacher.exam.local" if is_teacher else "student.exam.local"
    full_prefix = "Teacher" if is_teacher else "Student"

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="The uploaded file is empty")

    try:
        table = _parse_table(file.filename or "", data)
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=400, detail="Could not read this file. Use .txt, .csv or .xlsx")

    # Drop rows that are completely empty
    table = [row for row in table if any((c or "").strip() for c in row)]
    if not table:
        raise HTTPException(status_code=400, detail="The uploaded file is empty")
    if len(table) > MAX_IMPORT_ROWS + 1:
        raise HTTPException(
            status_code=400,
            detail=f"Too many rows ({len(table) - 1}). The limit is {MAX_IMPORT_ROWS} per upload.",
        )

    # ── Header row? map columns (roll no, name, email, course, password) ─────
    header_norm = [_norm_header(c) for c in table[0]]
    colmap: dict = {}
    for field, tokens in (
        ("id", ID_HEADERS), ("name", NAME_HEADERS), ("email", EMAIL_HEADERS),
        ("course", COURSE_HEADERS), ("password", PASSWORD_HEADERS),
    ):
        for i, h in enumerate(header_norm):
            if h in tokens:
                colmap[field] = i
                break

    if colmap:
        if "id" not in colmap:
            raise HTTPException(
                status_code=400,
                detail="Header row found but no roll number column. "
                       "Expected headers like: roll_no,name,email,course",
            )
        body = table[1:]
    else:
        body = table   # legacy format: one ID per row, no header

    if not body:
        raise HTTPException(status_code=400, detail="No rows found after the header row")
    if len(body) > MAX_IMPORT_ROWS:
        raise HTTPException(
            status_code=400,
            detail=f"Too many rows ({len(body)}). The limit is {MAX_IMPORT_ROWS} per upload.",
        )

    created, skipped = [], []
    seen_ids, seen_emails = set(), set()

    for row in body:
        if colmap:
            roll    = _cell(row, colmap.get("id"))
            name    = _cell(row, colmap.get("name"))
            given_email = _cell(row, colmap.get("email"))
            course  = _cell(row, colmap.get("course"))[:120]
            given_pw = _cell(row, colmap.get("password"))
        else:
            roll = next((c.strip() for c in row if c and c.strip()), "")
            name = given_email = course = given_pw = ""

        if not roll:
            skipped.append({"value": "(blank)", "reason": "Missing roll number / ID"})
            continue

        key = roll.lower()
        if key in seen_ids:
            skipped.append({"value": roll, "reason": "Repeated in this file"})
            continue
        seen_ids.add(key)

        if not ENROLLMENT_RE.match(roll):
            skipped.append({"value": roll, "reason": "Invalid format (use 2-30 letters, digits, . _ -)"})
            continue

        if given_email:
            email = given_email.strip().lower()
            if not EMAIL_RE.match(email):
                skipped.append({"value": roll, "reason": f"Invalid email '{given_email}'"})
                continue
        else:
            email = f"{key}@{domain}"

        if email in seen_emails:
            skipped.append({"value": roll, "reason": f"Email '{email}' repeated in this file"})
            continue
        seen_emails.add(email)

        if given_pw:
            password = given_pw
            if len(password) < 8:
                skipped.append({"value": roll, "reason": "Password must be at least 8 characters"})
                continue
            generated_pw = False
        else:
            password = generate_password()
            generated_pw = True

        taken = (
            db.query(User)
            .filter(
                (func.lower(User.email) == email)
                | (func.lower(func.coalesce(id_column, "")) == key)
            )
            .first()
        )
        if taken:
            skipped.append({"value": roll, "reason": "This ID or email already exists"})
            continue

        full_name = (name or f"{full_prefix} {roll}").strip()[:255]
        user = User(
            email=email,
            full_name=full_name,
            course=course or None,
            role=UserRole.teacher if is_teacher else UserRole.student,
            is_active=True,
            hashed_password=get_password_hash(password),
            # A generated password is a default one — block the app until the
            # student replaces it after their first login.
            must_change_password=generated_pw,
        )
        setattr(user, id_field, roll)
        db.add(user)
        db.flush()
        created.append({
            id_field:    roll,
            "full_name": full_name,
            "email":     email,
            "course":    course,
            "password":  password,
        })

    db.commit()
    return {
        "role":           role,
        "created_count": len(created),
        "skipped_count": len(skipped),
        "total_rows":    len(body),
        "format":        "columns" if colmap else "id-list",
        "created":       created,
        "skipped":       skipped,
    }


# ── TESTS ─────────────────────────────────────────────────────────────────────

@router.get("/tests")
def list_all_tests(db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    q = db.query(Test)
    if not _is_admin(current_user):
        q = q.filter(Test.creator_id == current_user.id)
    tests = q.order_by(Test.created_at.desc()).all()
    return [
        {
            "id":               t.id,
            "title":            t.title,
            "access_code":      t.access_code,
            "duration_mins":    t.duration_mins,
            "total_marks":      t.total_marks,
            "passing_marks":    t.passing_marks,
            "is_active":        t.is_active,
            "allow_retake":     getattr(t, "allow_retake", False),
            "creator_name":     t.creator.full_name,
            "creator_email":    t.creator.email,
            "question_count":   len(t.questions),
            "submission_count": len(t.submissions),
            "created_at":       t.created_at,
            "start_time":       t.start_time,
            "end_time":         t.end_time,
        }
        for t in tests
    ]


class TestAdminUpdate(BaseModel):
    title:         Optional[str]  = None
    description:   Optional[str]  = None
    duration_mins: Optional[int]  = None
    total_marks:   Optional[int]  = None
    passing_marks: Optional[int]  = None
    is_active:     Optional[bool] = None
    allow_retake:  Optional[bool] = None
    start_time:    Optional[datetime] = None
    end_time:      Optional[datetime] = None


@router.put("/tests/{test_id}")
def update_test(test_id: int, data: TestAdminUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    test = db.query(Test).filter(Test.id == test_id).first()
    _ensure_test_owned(test, current_user)
    # exclude_unset so an explicit null (e.g. {"end_time": null}) clears the value
    # while fields the client did not send are left untouched
    for field, val in data.dict(exclude_unset=True).items():
        setattr(test, field, val)
    db.commit()
    return {"detail": "Test updated"}


@router.delete("/tests/{test_id}")
def delete_test(test_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    test = db.query(Test).filter(Test.id == test_id).first()
    _ensure_test_owned(test, current_user)
    # Collect evidence files first — the cascade removes the violation rows.
    evidence_paths = [
        v.evidence_path
        for v in db.query(ViolationLog).filter(ViolationLog.test_id == test_id).all()
    ]
    db.delete(test)
    db.commit()
    delete_evidence_files(evidence_paths)
    return {"detail": "Test and all related data deleted"}


# ── SUBMISSIONS ────────────────────────────────────────────────────────────────

@router.get("/submissions")
def list_submissions(test_id: Optional[int] = None, db: Session = Depends(get_db), current_user: User = Depends(require_admin_or_teacher)):
    q = db.query(Submission)
    if not _is_admin(current_user):
        q = q.join(Test).filter(Test.creator_id == current_user.id)
    if test_id:
        q = q.filter(Submission.test_id == test_id)
    subs = q.order_by(Submission.started_at.desc()).all()
    return [
        {
            "id":              s.id,
            "test_id":         s.test_id,
            "test_title":      s.test.title,
            "student_id":      s.student_id,
            "student_name":    s.student.full_name,
            "student_email":   s.student.email,
            "score":           s.score,
            "max_score":       s.max_score,
            "percentage":      s.percentage,
            "passed":          s.passed,
            "is_submitted":    s.is_submitted,
            "integrity_score": s.integrity_score,
            "risk_level":      s.risk_level,
            "violations_count": len(s.violations),
            "started_at":      s.started_at,
            "submitted_at":    s.submitted_at,
        }
        for s in subs
    ]
