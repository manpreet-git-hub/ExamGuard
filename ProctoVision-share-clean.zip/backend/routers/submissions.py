# ── backend/routers/submissions.py — Exam submissions + auto-grading ──────────

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
import random

from database.db import get_db
from models.models import Submission, Answer, Question, Test, User, QuestionType
from routers.auth import get_current_user
from utils.scoring import compute_risk_level
from utils.test_access import (
    ensure_student_user,
    ensure_test_available_for_student,
    ensure_submission_access,
    ensure_student_can_start,
    get_password_row,
    test_has_roster,
)

router = APIRouter()


class AnswerSubmit(BaseModel):
    question_id: int
    answer_text: Optional[str] = None
    selected_options: Optional[List[str]] = None

class SubmissionCreate(BaseModel):
    test_id: int
    test_password: Optional[str] = None   # unique password emailed to this student

class SubmitAnswers(BaseModel):
    answers: List[AnswerSubmit]
    time_taken_secs: Optional[int] = None

class SubmissionOut(BaseModel):
    id: int
    test_id: int
    student_id: int
    started_at: datetime
    submitted_at: Optional[datetime]
    score: float
    max_score: int
    percentage: float
    passed: bool
    integrity_score: float
    risk_level: str
    is_submitted: bool
    selected_question_ids: Optional[List[int]] = None
    shuffled_options_map: Optional[dict] = None

    class Config:
        from_attributes = True


def grade_answer(question, answer_text, selected_options):
    if question.question_type == QuestionType.mcq:
        correct = question.correct_answer
        selected = selected_options[0] if selected_options else None
        is_correct = selected == correct
        return is_correct, question.marks if is_correct else 0
    elif question.question_type == QuestionType.multiple_correct:
        correct = set(question.correct_answer or [])
        selected = set(selected_options or [])
        is_correct = correct == selected
        return is_correct, question.marks if is_correct else 0
    elif question.question_type in [QuestionType.short_answer, QuestionType.coding]:
        return None, 0
    return False, 0


def auto_submit_exam(sub: Submission, db: Session):
    """Auto-submit a submission due to integrity score reaching zero.
    Grades any existing answers and marks the exam as submitted."""
    if sub.is_submitted:
        return sub

    test = sub.test
    allowed_ids = set(sub.selected_question_ids) if sub.selected_question_ids else {q.id for q in test.questions}

    # Grade any answers the student has already saved
    existing_answers = db.query(Answer).filter(Answer.submission_id == sub.id).all()
    total_scored = 0.0
    answered_ids = set()
    for ans in existing_answers:
        if ans.question_id not in allowed_ids:
            continue
        q = db.query(Question).filter(Question.id == ans.question_id).first()
        if not q or q.test_id != test.id:
            continue
        is_correct, marks = grade_answer(q, ans.answer_text, ans.selected_options or [])
        ans.is_correct = is_correct
        ans.marks_awarded = marks
        total_scored += marks
        answered_ids.add(ans.question_id)

    percentage = (total_scored / test.total_marks * 100) if test.total_marks > 0 else 0
    sub.score = total_scored
    sub.percentage = round(percentage, 2)
    sub.passed = total_scored >= test.passing_marks
    sub.submitted_at = datetime.utcnow()
    sub.is_submitted = True
    sub.auto_submitted = True
    sub.risk_level = "High"
    db.commit()
    db.refresh(sub)
    return sub


@router.post("/start", response_model=SubmissionOut, status_code=201)
def start_submission(data: SubmissionCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    ensure_student_user(current_user)
    test = db.query(Test).filter(Test.id == data.test_id).first()
    # Look up an in-progress attempt first so a reload mid-exam (even after
    # end_time passes) resumes instead of being rejected by the window check.
    in_progress = db.query(Submission).filter(
        Submission.test_id == data.test_id,
        Submission.student_id == current_user.id,
        Submission.is_submitted == False
    ).first()
    test = ensure_test_available_for_student(test, submission=in_progress)
    if len(test.questions) == 0:
        raise HTTPException(status_code=400, detail="This test has no questions yet")

    # Check for an in-progress submission first (always resumable)
    if in_progress:
        # If the submission has expired (started_at + duration + grace < now), discard it
        elapsed = (datetime.utcnow() - in_progress.started_at).total_seconds() / 60
        if elapsed > test.duration_mins + 5:  # 5-minute grace period
            db.delete(in_progress)
            db.commit()
            # Stale attempt gone — a *fresh* attempt must still respect the window
            ensure_test_available_for_student(test)
            # Fall through to create a fresh submission
        else:
            db.refresh(in_progress)
            return in_progress

    # Check if student already completed this test
    completed = db.query(Submission).filter(
        Submission.test_id == data.test_id,
        Submission.student_id == current_user.id,
        Submission.is_submitted == True
    ).first()
    if completed:
        if not getattr(test, "allow_retake", False):
            raise HTTPException(
                status_code=403,
                detail="You have already submitted this test. Retakes are not allowed unless the teacher enables them."
            )

    # ── Secure gate: teacher's roster + this student's unique emailed password.
    # Runs only when a fresh attempt is being created (resumes skip it above).
    ensure_student_can_start(db, test, current_user, data.test_password)

    # Random question selection
    selected_ids = None
    shuffled_options_map = None
    all_questions = list(test.questions)

    if test.shuffle_questions and test.questions_per_student and test.questions_per_student > 0:
        count = min(test.questions_per_student, len(all_questions))
        selected_qs = random.sample(all_questions, count)
        selected_ids = [q.id for q in selected_qs]

        # Shuffle options for MCQ questions if enabled
        if test.shuffle_options:
            shuffled_options_map = {}
            for q in selected_qs:
                if q.question_type in [QuestionType.mcq, QuestionType.multiple_correct] and q.options:
                    shuffled = list(q.options)
                    random.shuffle(shuffled)
                    shuffled_options_map[str(q.id)] = shuffled

    submission = Submission(
        test_id=data.test_id,
        student_id=current_user.id,
        max_score=test.total_marks,
        selected_question_ids=selected_ids,
        shuffled_options_map=shuffled_options_map,
    )
    db.add(submission)
    db.commit()
    db.refresh(submission)

    # Burn the one-time password now that a submission actually exists
    if test_has_roster(db, test):
        pwd_row = get_password_row(db, test, current_user)
        if pwd_row and not pwd_row.is_used:
            from datetime import timezone as _tz
            pwd_row.is_used = True
            pwd_row.used_at = datetime.now(_tz.utc)
            db.commit()

    return submission


@router.post("/{submission_id}/save-answer")
def save_answer(submission_id: int, answer: AnswerSubmit, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    sub = db.query(Submission).filter(
        Submission.id == submission_id,
        Submission.student_id == current_user.id,
        Submission.is_submitted == False
    ).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Submission not found")
    # The window was enforced at start — never lock an in-progress attempt out
    # of saving its own answers when end_time passes mid-exam.
    ensure_test_available_for_student(sub.test, submission=sub)
    existing = db.query(Answer).filter(Answer.submission_id == submission_id, Answer.question_id == answer.question_id).first()
    if existing:
        existing.answer_text = answer.answer_text
        existing.selected_options = answer.selected_options
        existing.answered_at = datetime.utcnow()
    else:
        db.add(Answer(submission_id=submission_id, question_id=answer.question_id, answer_text=answer.answer_text, selected_options=answer.selected_options))
    db.commit()
    return {"status": "saved"}


@router.post("/{submission_id}/submit", response_model=SubmissionOut)
def submit_exam(submission_id: int, data: SubmitAnswers, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    sub = db.query(Submission).filter(
        Submission.id == submission_id,
        Submission.student_id == current_user.id,
        Submission.is_submitted == False
    ).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Submission not found or already submitted")
    test = sub.test
    # The window was enforced at start — a mid-exam attempt may still submit.
    ensure_test_available_for_student(test, submission=sub)

    # Determine which question IDs are valid for this submission
    allowed_ids = set(sub.selected_question_ids) if sub.selected_question_ids else {q.id for q in test.questions}

    total_scored = 0.0
    for ans_data in data.answers:
        if ans_data.question_id not in allowed_ids:
            continue
        q = db.query(Question).filter(Question.id == ans_data.question_id).first()
        if not q or q.test_id != test.id:
            continue
        is_correct, marks = grade_answer(q, ans_data.answer_text, ans_data.selected_options or [])
        existing = db.query(Answer).filter(Answer.submission_id == submission_id, Answer.question_id == ans_data.question_id).first()
        if existing:
            existing.answer_text = ans_data.answer_text
            existing.selected_options = ans_data.selected_options
            existing.is_correct = is_correct
            existing.marks_awarded = marks
        else:
            db.add(Answer(submission_id=submission_id, question_id=ans_data.question_id, answer_text=ans_data.answer_text, selected_options=ans_data.selected_options, is_correct=is_correct, marks_awarded=marks))
        total_scored += marks
    percentage = (total_scored / test.total_marks * 100) if test.total_marks > 0 else 0
    sub.score = total_scored
    sub.percentage = round(percentage, 2)
    sub.passed = total_scored >= test.passing_marks
    sub.submitted_at = datetime.utcnow()
    sub.time_taken_secs = data.time_taken_secs
    sub.is_submitted = True
    # Recompute risk level from final integrity score
    sub.risk_level = compute_risk_level(sub.integrity_score)
    db.commit()
    db.refresh(sub)
    return sub


@router.get("/{submission_id}/answers")
def get_submission_answers(submission_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    sub = db.query(Submission).filter(Submission.id == submission_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Not found")
    ensure_submission_access(sub, current_user)
    return [{"question_id": a.question_id, "answer_text": a.answer_text, "selected_options": a.selected_options, "is_correct": a.is_correct, "marks_awarded": a.marks_awarded} for a in sub.answers]


# ── Manual grading for short_answer / coding questions ──────────────────────

class ManualGradeInput(BaseModel):
    marks_awarded: float
    feedback: Optional[str] = None


@router.post("/{submission_id}/grade/{answer_id}")
def grade_manual_answer(
    submission_id: int,
    answer_id: int,
    data: ManualGradeInput,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Teacher manually awards marks for short_answer / coding questions."""
    from models.models import UserRole
    if current_user.role not in [UserRole.teacher, UserRole.admin]:
        raise HTTPException(status_code=403, detail="Teacher access required")

    sub = db.query(Submission).filter(Submission.id == submission_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Submission not found")
    if sub.test.creator_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized for this test")

    answer = db.query(Answer).filter(
        Answer.id == answer_id,
        Answer.submission_id == submission_id,
    ).first()
    if not answer:
        raise HTTPException(status_code=404, detail="Answer not found")

    q = answer.question
    if q.question_type.value not in ["short_answer", "coding"]:
        raise HTTPException(status_code=400, detail="Only short_answer/coding can be manually graded")

    awarded = min(float(data.marks_awarded), float(q.marks))
    awarded = max(0.0, awarded)
    answer.marks_awarded = awarded
    answer.is_correct = awarded > 0

    # Recompute total score for this submission
    all_answers = db.query(Answer).filter(Answer.submission_id == submission_id).all()
    total = sum((a.marks_awarded or 0) for a in all_answers)
    sub.score = total
    sub.percentage = round((total / sub.max_score * 100), 2) if sub.max_score else 0
    sub.passed = total >= sub.test.passing_marks

    db.commit()
    db.refresh(answer)
    return {
        "answer_id": answer.id,
        "marks_awarded": answer.marks_awarded,
        "is_correct": answer.is_correct,
        "updated_score": sub.score,
        "updated_percentage": sub.percentage,
        "passed": sub.passed,
    }
