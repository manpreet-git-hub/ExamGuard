# ── backend/routers/questions.py ───────────────────────────────────────────────

import csv
import io
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List, Any

from database.db import get_db
from models.models import Question, Test, QuestionType, User, Submission, UserRole
from routers.auth import get_current_user, require_teacher
from utils.test_access import ensure_test_available_for_student, ensure_student_on_roster

router = APIRouter()


def prepare_question_payload(*, question_type, options, correct_answer, marks, order_index):
    if marks is not None and marks <= 0:
        raise HTTPException(status_code=400, detail="Marks must be greater than 0")
    if order_index is not None and order_index < 0:
        raise HTTPException(status_code=400, detail="Order index cannot be negative")

    if question_type in [QuestionType.mcq, QuestionType.multiple_correct]:
        clean_options = [opt.strip() for opt in (options or []) if opt and opt.strip()]
        if len(clean_options) < 2:
            raise HTTPException(
                status_code=400,
                detail="Choice questions must include at least two options",
            )

        if question_type == QuestionType.mcq:
            if not isinstance(correct_answer, str) or not correct_answer.strip():
                raise HTTPException(
                    status_code=400,
                    detail="MCQ questions require one correct answer",
                )
            correct_answer = correct_answer.strip()
            if correct_answer not in clean_options:
                raise HTTPException(
                    status_code=400,
                    detail="Correct answer must match one of the options",
                )
        else:
            if not isinstance(correct_answer, list) or len(correct_answer) == 0:
                raise HTTPException(
                    status_code=400,
                    detail="Multiple-correct questions require at least one correct option",
                )
            clean_correct = []
            for item in correct_answer:
                if isinstance(item, str):
                    value = item.strip()
                    if value and value in clean_options and value not in clean_correct:
                        clean_correct.append(value)
            if not clean_correct:
                raise HTTPException(
                    status_code=400,
                    detail="Correct answers must match the provided options",
                )
            correct_answer = clean_correct

        return {
            "options": clean_options,
            "correct_answer": correct_answer,
        }

    return {
        "options": None,
        "correct_answer": correct_answer.strip() if isinstance(correct_answer, str) else correct_answer,
    }


class QuestionCreate(BaseModel):
    test_id: int
    question_text: str
    question_type: QuestionType
    options: Optional[List[str]] = None
    correct_answer: Optional[Any] = None
    marks: int = 1
    order_index: int = 0
    explanation: Optional[str] = None

class QuestionUpdate(BaseModel):
    question_text: Optional[str] = None
    question_type: Optional[QuestionType] = None
    options: Optional[List[str]] = None
    correct_answer: Optional[Any] = None
    marks: Optional[int] = None
    order_index: Optional[int] = None
    explanation: Optional[str] = None

class QuestionOut(BaseModel):
    id: int
    test_id: int
    question_text: str
    question_type: QuestionType
    options: Optional[List[str]]
    correct_answer: Optional[Any]
    marks: int
    order_index: int
    explanation: Optional[str]

    class Config:
        from_attributes = True

class QuestionStudent(BaseModel):
    id: int
    test_id: int
    question_text: str
    question_type: QuestionType
    options: Optional[List[str]]
    marks: int
    order_index: int

    class Config:
        from_attributes = True


@router.post("/", response_model=QuestionOut, status_code=201)
def create_question(q: QuestionCreate, db: Session = Depends(get_db), current_user: User = Depends(require_teacher)):
    test = db.query(Test).filter(Test.id == q.test_id, Test.creator_id == current_user.id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")
    # Auto-set order_index to end of list
    count = len(test.questions)
    payload = prepare_question_payload(
        question_type=q.question_type,
        options=q.options,
        correct_answer=q.correct_answer,
        marks=q.marks,
        order_index=q.order_index,
    )
    question = Question(
        **q.dict(exclude={"options", "correct_answer"}),
        options=payload["options"],
        correct_answer=payload["correct_answer"],
    )
    if q.order_index == 0:
        question.order_index = count
    db.add(question)
    db.commit()
    db.refresh(question)
    return question


@router.get("/test/{test_id}", response_model=List[QuestionOut])
def get_test_questions(test_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_teacher)):
    query = db.query(Test).filter(Test.id == test_id)
    if current_user.role != UserRole.admin:
        query = query.filter(Test.creator_id == current_user.id)
    test = query.first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")
    return sorted(test.questions, key=lambda q: q.order_index)


@router.get("/student/test/{test_id}", response_model=List[QuestionStudent])
def get_questions_for_student(test_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Return questions without correct answers — for students taking the exam.
    If the test uses random selection, returns only the student's assigned questions
    with shuffled options (if enabled)."""
    test = db.query(Test).filter(Test.id == test_id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")

    # Check if student has an active submission with selected questions
    submission = db.query(Submission).filter(
        Submission.test_id == test_id,
        Submission.student_id == current_user.id,
        Submission.is_submitted == False,
    ).first()

    # Enforce the availability window, but never lock out a student who is
    # already mid-exam (they may reload while resuming an active submission).
    if not submission:
        ensure_test_available_for_student(test)
        # Questions are only handed out once a submission exists — the roster +
        # unique-password gate has already run at /api/submissions/start, so a
        # student who never passed it can never read them.
        ensure_student_on_roster(db, test, current_user)
        raise HTTPException(
            status_code=403,
            detail="Start the exam first",
        )

    all_questions = sorted(test.questions, key=lambda q: q.order_index)

    if submission and submission.selected_question_ids:
        # Return only the selected questions, preserving the random order
        id_to_q = {q.id: q for q in all_questions}
        selected = [id_to_q[qid] for qid in submission.selected_question_ids if qid in id_to_q]

        # Apply shuffled options if available
        if submission.shuffled_options_map:
            result = []
            for q in selected:
                q_data = QuestionStudent.from_orm(q)
                shuffled = submission.shuffled_options_map.get(str(q.id))
                if shuffled:
                    q_data.options = shuffled
                result.append(q_data)
            return result

        return [QuestionStudent.from_orm(q) for q in selected]

    return [QuestionStudent.from_orm(q) for q in all_questions]


@router.put("/{question_id}", response_model=QuestionOut)
def update_question(question_id: int, q: QuestionUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_teacher)):
    question = db.query(Question).filter(Question.id == question_id).first()
    if not question:
        raise HTTPException(status_code=404, detail="Question not found")
    if question.test.creator_id != current_user.id and current_user.role != UserRole.admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    updates = q.dict(exclude_none=True)
    question_type = updates.get("question_type", question.question_type)
    prepared = prepare_question_payload(
        question_type=question_type,
        options=updates.get("options", question.options),
        correct_answer=updates.get("correct_answer", question.correct_answer),
        marks=updates.get("marks", question.marks),
        order_index=updates.get("order_index", question.order_index),
    )
    updates["options"] = prepared["options"]
    updates["correct_answer"] = prepared["correct_answer"]
    for k, v in updates.items():
        setattr(question, k, v)
    db.commit()
    db.refresh(question)
    return question


@router.delete("/{question_id}")
def delete_question(question_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_teacher)):
    question = db.query(Question).filter(Question.id == question_id).first()
    if not question:
        raise HTTPException(status_code=404, detail="Question not found")
    if question.test.creator_id != current_user.id and current_user.role != UserRole.admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    db.delete(question)
    db.commit()
    return {"detail": "Deleted"}


@router.post("/bulk-import/{test_id}")
async def bulk_import_questions(
    test_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    """Bulk import questions from CSV directly into a specific test.
    Expected columns: question_text, question_type, correct_answer
    Optional columns: options, marks, explanation
    - options: pipe-separated (e.g. "A|B|C|D")
    - correct_answer: for MCQ, a single value; for multiple_correct, pipe-separated
    """
    query = db.query(Test).filter(Test.id == test_id)
    if current_user.role != UserRole.admin:
        query = query.filter(Test.creator_id == current_user.id)
    test = query.first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")

    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")

    content = await file.read()
    try:
        text = content.decode('utf-8-sig')
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="File must be UTF-8 encoded")

    reader = csv.DictReader(io.StringIO(text))
    required_cols = {'question_text', 'question_type', 'correct_answer'}
    if not required_cols.issubset(set(reader.fieldnames or [])):
        raise HTTPException(status_code=400, detail=f"CSV must contain columns: {', '.join(sorted(required_cols))}")

    current_max_order = max((q.order_index for q in test.questions), default=-1)
    created = []
    errors = []
    for i, row in enumerate(reader, start=2):
        try:
            q_type = row['question_type'].strip().lower()
            if q_type not in ['mcq', 'multiple_correct', 'short_answer', 'coding']:
                errors.append(f"Row {i}: Invalid question_type '{q_type}'")
                continue

            question_text = row['question_text'].strip()
            if not question_text:
                errors.append(f"Row {i}: question_text is empty")
                continue

            options = None
            correct_answer = row.get('correct_answer', '').strip()

            if q_type in ['mcq', 'multiple_correct']:
                raw_opts = row.get('options', '')
                options = [o.strip() for o in raw_opts.split('|') if o.strip()]
                if len(options) < 2:
                    errors.append(f"Row {i}: Need at least 2 options")
                    continue
                if q_type == 'mcq':
                    if correct_answer not in options:
                        errors.append(f"Row {i}: Correct answer '{correct_answer}' not in options")
                        continue
                else:
                    correct_list = [c.strip() for c in correct_answer.split('|') if c.strip()]
                    if not correct_list or not any(c in options for c in correct_list):
                        errors.append(f"Row {i}: No correct answers match options")
                        continue
                    correct_answer = correct_list
            else:
                options = None
                if not correct_answer:
                    correct_answer = None

            marks_raw = row.get('marks', '1').strip()
            marks = int(marks_raw) if marks_raw.isdigit() and int(marks_raw) > 0 else 1

            q = Question(
                test_id=test.id,
                question_text=question_text,
                question_type=q_type,
                options=options,
                correct_answer=correct_answer,
                marks=marks,
                explanation=row.get('explanation', '').strip() or None,
                order_index=current_max_order + 1 + len(created),
            )
            db.add(q)
            db.flush()
            created.append(q.id)
        except Exception as e:
            errors.append(f"Row {i}: {str(e)}")

    if created:
        db.commit()

    return {
        "imported": len(created),
        "errors": errors,
        "total_errors": len(errors),
    }
