# ── backend/routers/proctoring.py — Violation logging + evidence ──────────────

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

from database.db import get_db
from models.models import ViolationLog, Submission, User
from routers.auth import get_current_user
from routers.submissions import auto_submit_exam
from utils.evidence import save_evidence_image
from utils.scoring import PENALTIES, compute_risk_level

router = APIRouter()


class ViolationCreate(BaseModel):
    submission_id: int
    violation_type: str
    confidence_score: float = 1.0
    description: Optional[str] = None
    evidence_b64: Optional[str] = None   # base64 encoded image


class ViolationOut(BaseModel):
    id: int
    submission_id: int
    student_id: int
    test_id: int
    violation_type: str
    confidence_score: float
    description: Optional[str]
    evidence_path: Optional[str]
    timestamp: datetime
    penalty_applied: int
    auto_submitted: bool = False

    class Config:
        from_attributes = True


@router.post("/violation", response_model=ViolationOut, status_code=201)
def log_violation(
    data: ViolationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    sub = db.query(Submission).filter(
        Submission.id == data.submission_id,
        Submission.student_id == current_user.id,
        Submission.is_submitted == False
    ).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Active submission not found")

    # Save evidence image
    evidence_path = None
    if data.evidence_b64:
        evidence_path = save_evidence_image(data.evidence_b64, data.violation_type)

    penalty = PENALTIES.get(data.violation_type, 0)

    log = ViolationLog(
        submission_id=data.submission_id,
        student_id=current_user.id,
        test_id=sub.test_id,
        violation_type=data.violation_type,
        confidence_score=data.confidence_score,
        description=data.description,
        evidence_path=evidence_path,
        penalty_applied=penalty,
    )
    db.add(log)

    # Update integrity score
    new_score = max(0, sub.integrity_score - penalty)
    sub.integrity_score = new_score
    sub.risk_level = compute_risk_level(new_score)

    # Auto-submit if integrity score reaches zero
    auto_submitted = False
    if new_score <= 0 and not sub.is_submitted:
        auto_submit_exam(sub, db)
        auto_submitted = True

    db.commit()
    db.refresh(log)
    result = ViolationOut.from_orm(log).dict()
    result["auto_submitted"] = auto_submitted
    return result
