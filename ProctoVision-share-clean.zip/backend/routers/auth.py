"""
backend/routers/auth.py - Authentication (JWT + password hashing)

Uses PyJWT (import jwt) - NOT python-jose. The two packages both expose a
top-level jose/jwt name on PyPI and are easy to confuse; PyJWT is the
actively maintained, dependency-light one and is what backend/requirements.txt
installs.

Password hashing uses passlib's bcrypt backend, with the password safely
truncated to bcrypt's 72-byte limit before hashing/verifying so long
passwords never raise ValueError instead of just being accepted.
"""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime, timedelta, timezone
from typing import Optional
import jwt
from passlib.context import CryptContext
from pydantic import BaseModel

from database.db import get_db
from models.models import User, UserRole
from utils.env import required_in_production

router = APIRouter()
SECRET_KEY = required_in_production("SECRET_KEY") or "proctovision-secret-key-2024-change-in-production"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str


def _truncate_for_bcrypt(password: str) -> str:
    """bcrypt only uses the first 72 BYTES of a password - encode + slice so
    hashing/verifying never raises 'password cannot be longer than 72 bytes'
    on long passwords or multi-byte (emoji/unicode) input."""
    return password.encode("utf-8")[:72].decode("utf-8", errors="ignore")


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(_truncate_for_bcrypt(plain), hashed)


def get_password_hash(password: str) -> str:
    return pwd_context.hash(_truncate_for_bcrypt(password))


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def get_user_by_id(db: Session, user_id: int):
    return db.query(User).filter(User.id == user_id).first()


async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    credentials_exception = HTTPException(status_code=401, detail="Invalid or expired token",
                                           headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if not user_id:
            raise credentials_exception
    except jwt.PyJWTError:
        raise credentials_exception
    user = get_user_by_id(db, int(user_id))
    if not user or not user.is_active:
        raise credentials_exception
    return user


async def require_teacher(current_user: User = Depends(get_current_user)) -> User:
    if current_user.role not in [UserRole.teacher, UserRole.admin]:
        raise HTTPException(status_code=403, detail="Teacher access required")
    return current_user


@router.post("/register", status_code=403)
def register():
    """Self-registration is turned off — accounts are created by the admin
    (panel or CSV import). Kept as a route so old clients get a clear reason
    instead of a bare 404."""
    raise HTTPException(
        status_code=403,
        detail="Registration is disabled. Ask your administrator to create your account.",
    )


@router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == form_data.username.strip().lower()).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account disabled")
    token = create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer",
            "user": {"id": user.id, "email": user.email,
                     "full_name": user.full_name, "role": user.role.value,
                     "is_active": user.is_active,
                     "must_change_password": bool(user.must_change_password)}}


@router.get("/me")
def get_me(current_user: User = Depends(get_current_user)):
    return {"id": current_user.id, "email": current_user.email,
            "full_name": current_user.full_name, "role": current_user.role.value,
            "is_active": current_user.is_active,
            "must_change_password": bool(current_user.must_change_password)}


MIN_NEW_PASSWORD_LEN = 8


@router.post("/change-password")
def change_password(data: ChangePasswordIn,
                    current_user: User = Depends(get_current_user),
                    db: Session = Depends(get_db)):
    """Set a new password. Used right after logging in with a default /
    system-generated password (users.must_change_password) and any time a
    user wants to update it themselves."""
    if len(data.new_password) < MIN_NEW_PASSWORD_LEN:
        raise HTTPException(status_code=400,
                            detail=f"New password must be at least {MIN_NEW_PASSWORD_LEN} characters")
    if data.new_password == data.current_password:
        raise HTTPException(status_code=400, detail="New password must be different")
    if not verify_password(data.current_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="Current password is incorrect")

    user = db.query(User).filter(User.id == current_user.id).first()
    user.hashed_password = get_password_hash(data.new_password)
    user.must_change_password = False
    db.commit()
    return {"detail": "Password updated", "must_change_password": False}
