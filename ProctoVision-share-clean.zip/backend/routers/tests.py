# ── backend/routers/tests.py — Test CRUD ──────────────────────────────────────

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
import csv
import io

from database.db import get_db, SessionLocal
from models.models import Test, TestPassword, TestParticipant, User, UserRole, ViolationLog
from routers.auth import get_current_user, get_password_hash, require_teacher
from utils.test_access import (
    ensure_test_available_for_student,
    get_participant,
    get_password_row,
    test_has_roster,
    validate_test_settings,
)
import utils.email_service as email_service
from utils.csv_headers import ID_HEADERS, norm_header
from utils.evidence import delete_evidence_files
from utils.generators import gen_access_code, gen_student_password

router = APIRouter()


class TestCreate(BaseModel):
    title: str
    description: Optional[str] = ""
    duration_mins: int
    total_marks: int
    passing_marks: int
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    allow_retake: Optional[bool] = False
    shuffle_questions: Optional[bool] = False
    questions_per_student: Optional[int] = 0
    shuffle_options: Optional[bool] = False

class TestUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    duration_mins: Optional[int] = None
    total_marks: Optional[int] = None
    passing_marks: Optional[int] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    is_active: Optional[bool] = None
    allow_retake: Optional[bool] = None
    shuffle_questions: Optional[bool] = None
    questions_per_student: Optional[int] = None
    shuffle_options: Optional[bool] = None

class TestOut(BaseModel):
    id: int
    title: str
    description: Optional[str]
    access_code: str
    duration_mins: int
    total_marks: int
    passing_marks: int
    start_time: Optional[datetime]
    end_time: Optional[datetime]
    is_active: bool
    creator_id: int
    created_at: datetime
    allow_retake: Optional[bool] = False
    shuffle_questions: Optional[bool] = False
    questions_per_student: Optional[int] = 0
    shuffle_options: Optional[bool] = False
    question_count: Optional[int] = 0
    submission_count: Optional[int] = 0

    class Config:
        from_attributes = True


class ParticipantOut(BaseModel):
    id: int
    user_id: int
    roll_no: Optional[str] = None
    full_name: str
    email: str
    password_status: str          # none | pending | sent | failed
    password_attempts: int = 0
    password_used: bool = False

class RosterUploadResult(BaseModel):
    added: int
    duplicates: int
    errors: List[str] = []
    participants: List[ParticipantOut] = []

class RollNosIn(BaseModel):
    roll_nos: List[str]

class SendPasswordsIn(BaseModel):
    resend: Optional[bool] = False
    # If given, ONLY these students get a (re)generated password + email.
    user_ids: Optional[List[int]] = None

class RemoveParticipantsIn(BaseModel):
    user_ids: List[int]

class PasswordIn(BaseModel):
    password: str

class AccessStatus(BaseModel):
    restricted: bool
    on_list: bool
    password_required: bool
    password_sent: Optional[str] = None   # pending | sent | failed | None
    already_started: bool = False
    # Finished submission exists — show "already submitted" instead of the
    # instructions page (and never re-demand the password, which was burned).
    already_submitted: bool = False
    # Teacher clicked "allow retake" for this test → the student may start a
    # fresh attempt (which does require the emailed password again).
    retake_allowed: bool = False


@router.post("/", response_model=TestOut, status_code=201)
def create_test(test_data: TestCreate, db: Session = Depends(get_db), current_user: User = Depends(require_teacher)):
    validate_test_settings(
        duration_mins=test_data.duration_mins,
        total_marks=test_data.total_marks,
        passing_marks=test_data.passing_marks,
        start_time=test_data.start_time,
        end_time=test_data.end_time,
    )
    code = gen_access_code()
    while db.query(Test).filter(Test.access_code == code).first():
        code = gen_access_code()
    test = Test(**test_data.dict(), access_code=code, creator_id=current_user.id)
    db.add(test)
    db.commit()
    db.refresh(test)
    out = TestOut.from_orm(test)
    out.question_count = 0
    out.submission_count = 0
    return out


@router.get("/", response_model=List[TestOut])
def list_tests(db: Session = Depends(get_db), current_user: User = Depends(require_teacher)):
    tests = db.query(Test).filter(Test.creator_id == current_user.id).order_by(Test.created_at.desc()).all()
    result = []
    for t in tests:
        out = TestOut.from_orm(t)
        out.question_count = len(t.questions)
        out.submission_count = len(t.submissions)
        result.append(out)
    return result


# IMPORTANT: /code/{access_code} must come BEFORE /{test_id}
# otherwise FastAPI tries to cast "code" as an integer and fails
@router.get("/code/{access_code}")
def get_test_by_code(access_code: str, db: Session = Depends(get_db)):
    test = db.query(Test).filter(Test.access_code == access_code.upper()).first()
    try:
        test = ensure_test_available_for_student(test)
    except HTTPException as exc:
        if exc.status_code == 404:
            # Tell the student *which* code failed — they're typing it by hand.
            raise HTTPException(
                status_code=404,
                detail=(
                    f'No test found with access code "{access_code.upper()}". '
                    "Check the code on the teacher's dashboard or your invite link."
                ),
            )
        raise
    return {
        "id":             test.id,
        "title":          test.title,
        "description":    test.description,
        "duration_mins":  test.duration_mins,
        "total_marks":    test.total_marks,
        "passing_marks":  test.passing_marks,
        "start_time":     test.start_time,
        "end_time":       test.end_time,
        "question_count": len(test.questions),
        "access_code":    test.access_code,
        "allow_retake":   bool(getattr(test, "allow_retake", False)),
    }


@router.get("/{test_id}", response_model=TestOut)
def get_test(test_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    query = db.query(Test).filter(Test.id == test_id)
    if current_user.role == UserRole.teacher:
        query = query.filter(Test.creator_id == current_user.id)
    test = query.first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")
    if current_user.role == UserRole.student:
        ensure_test_available_for_student(test)
    out = TestOut.from_orm(test)
    out.question_count = len(test.questions)
    out.submission_count = len(test.submissions)
    return out


@router.put("/{test_id}", response_model=TestOut)
def update_test(test_id: int, test_data: TestUpdate, db: Session = Depends(get_db), current_user: User = Depends(require_teacher)):
    test = db.query(Test).filter(Test.id == test_id, Test.creator_id == current_user.id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")
    updates = test_data.dict(exclude_none=True)
    validate_test_settings(
        duration_mins=updates.get("duration_mins", test.duration_mins),
        total_marks=updates.get("total_marks", test.total_marks),
        passing_marks=updates.get("passing_marks", test.passing_marks),
        start_time=updates.get("start_time", test.start_time),
        end_time=updates.get("end_time", test.end_time),
    )
    for k, v in updates.items():
        setattr(test, k, v)
    db.commit()
    db.refresh(test)
    out = TestOut.from_orm(test)
    out.question_count = len(test.questions)
    out.submission_count = len(test.submissions)
    return out


@router.delete("/{test_id}")
def delete_test(test_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_teacher)):
    test = db.query(Test).filter(Test.id == test_id, Test.creator_id == current_user.id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")
    # Collect evidence files first — the cascade removes the violation rows,
    # so the paths are gone once the test is deleted.
    evidence_paths = [
        v.evidence_path
        for v in db.query(ViolationLog).filter(ViolationLog.test_id == test_id).all()
    ]
    db.delete(test)
    db.commit()
    delete_evidence_files(evidence_paths)
    return {"detail": "Test deleted"}


# ── Roster: which students may attempt the test ────────────────────────────────

def _owned_test(test_id: int, db: Session, current_user) -> Test:
    test = db.query(Test).filter(Test.id == test_id, Test.creator_id == current_user.id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")
    return test


def _participant_out(db: Session, p: TestParticipant) -> ParticipantOut:
    pwd = (
        db.query(TestPassword)
        .filter(TestPassword.test_id == p.test_id, TestPassword.user_id == p.user_id)
        .first()
    )
    return ParticipantOut(
        id=p.id,
        user_id=p.user_id,
        roll_no=p.roll_no,
        full_name=p.user.full_name if p.user else "",
        email=p.user.email if p.user else "",
        password_status=(pwd.email_status if pwd else "none"),
        password_attempts=(pwd.attempts or 0) if pwd else 0,
        password_used=bool(pwd.is_used) if pwd else False,
    )


def _resolve_roll_numbers(db: Session, roll_nos: List[str]):
    """Map roll numbers to real student accounts. Returns (users, errors, dups)."""
    from sqlalchemy import func

    users, errors = [], []
    seen, matched_ids = set(), set()
    duplicates = 0
    for raw in roll_nos:
        roll = (raw or "").strip().strip('"').strip("'")
        if not roll:
            continue
        key = roll.lower()
        if key in seen:
            duplicates += 1
            continue
        seen.add(key)
        user = (
            db.query(User)
            .filter(func.lower(User.student_id) == key, User.role == UserRole.student)
            .first()
        )
        if user is None:
            errors.append(f"'{roll}' — no student account has this roll number")
            continue
        if user.id in matched_ids:
            duplicates += 1
            continue
        matched_ids.add(user.id)
        users.append((roll, user))
    return users, errors, duplicates


def _parse_csv_roll_numbers(raw: bytes) -> List[str]:
    text = None
    for enc in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        text = raw.decode("utf-8", errors="replace")

    rows = [
        [c.strip() for c in row]
        for row in csv.reader(io.StringIO(text))
        if any(c.strip() for c in row)
    ]
    if rows and rows[0] and norm_header(rows[0][0]) in ID_HEADERS:
        rows = rows[1:]
    return [row[0] for row in rows if row]


@router.get("/{test_id}/participants", response_model=List[ParticipantOut])
def list_participants(test_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_teacher)):
    test = _owned_test(test_id, db, current_user)
    parts = db.query(TestParticipant).filter(TestParticipant.test_id == test.id).all()
    return [_participant_out(db, p) for p in parts]


@router.post("/{test_id}/participants/upload", response_model=RosterUploadResult)
async def upload_participants(
    test_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    """Upload a CSV of roll numbers (one per line, optional 'roll_no' header)."""
    test = _owned_test(test_id, db, current_user)
    roll_nos = _parse_csv_roll_numbers(await file.read())
    if not roll_nos:
        raise HTTPException(status_code=400, detail="CSV contains no roll numbers")

    users, errors, dups = _resolve_roll_numbers(db, roll_nos)
    existing = {
        p.user_id
        for p in db.query(TestParticipant).filter(TestParticipant.test_id == test.id).all()
    }
    added = 0
    for roll, user in users:
        if user.id in existing:
            dups += 1
            continue
        db.add(TestParticipant(test_id=test.id, user_id=user.id, roll_no=roll))
        added += 1
    db.commit()

    parts = db.query(TestParticipant).filter(TestParticipant.test_id == test.id).all()
    return RosterUploadResult(
        added=added, duplicates=dups, errors=errors,
        participants=[_participant_out(db, p) for p in parts],
    )


@router.post("/{test_id}/participants", response_model=RosterUploadResult)
def add_participants(
    test_id: int,
    data: RollNosIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    """Add students by typing/pasting roll numbers (comma or newline separated)."""
    test = _owned_test(test_id, db, current_user)
    raw = []
    for chunk in data.roll_nos:
        raw.extend(chunk.replace(";", ",").split(","))
    users, errors, dups = _resolve_roll_numbers(db, raw)
    if not users and errors:
        raise HTTPException(status_code=400, detail="; ".join(errors))

    existing = {
        p.user_id
        for p in db.query(TestParticipant).filter(TestParticipant.test_id == test.id).all()
    }
    added = 0
    for roll, user in users:
        if user.id in existing:
            dups += 1
            continue
        db.add(TestParticipant(test_id=test.id, user_id=user.id, roll_no=roll))
        added += 1
    db.commit()

    parts = db.query(TestParticipant).filter(TestParticipant.test_id == test.id).all()
    return RosterUploadResult(
        added=added, duplicates=dups, errors=errors,
        participants=[_participant_out(db, p) for p in parts],
    )


@router.delete("/{test_id}/participants")
def clear_participants(test_id: int, db: Session = Depends(get_db), current_user: User = Depends(require_teacher)):
    """Remove the whole roster (opens the test to every student again)."""
    test = _owned_test(test_id, db, current_user)
    db.query(TestPassword).filter(TestPassword.test_id == test.id).delete(synchronize_session=False)
    db.query(TestParticipant).filter(TestParticipant.test_id == test.id).delete(synchronize_session=False)
    db.commit()
    return {"detail": "Student list cleared"}


def _deliver_passwords(jobs: List[dict]):
    """Background task: send the emails, then record per-student status."""
    results = email_service.send_password_emails(jobs)
    db = SessionLocal()
    try:
        for job, error in results:
            row = db.query(TestPassword).filter(TestPassword.id == job.get("row_id")).first()
            if not row:
                continue
            if error:
                row.email_status = "failed"
                row.email_error = error
            else:
                from datetime import timezone
                row.email_status = "sent"
                row.email_error = None
                row.sent_at = datetime.now(timezone.utc)
            db.commit()
    finally:
        db.close()


@router.post("/{test_id}/participants/send-passwords")
def send_test_passwords(
    test_id: int,
    data: SendPasswordsIn,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    """Generate a UNIQUE password per student and email it to their registered
    mailbox. Only a bcrypt hash is stored on the server."""
    test = _owned_test(test_id, db, current_user)
    participants = db.query(TestParticipant).filter(TestParticipant.test_id == test.id).all()
    if not participants:
        raise HTTPException(status_code=400, detail="Upload the student list first")
    wanted = set(data.user_ids) if data.user_ids is not None else None
    if wanted is not None:
        participants = [p for p in participants if p.user_id in wanted]
        if not participants:
            raise HTTPException(status_code=400, detail="No selected students are on this list")
    if not email_service.smtp_configured():
        raise HTTPException(
            status_code=400,
            detail=(
                f"Email is not configured ({email_service.smtp_problem()}). "
                "Set SMTP_HOST / SMTP_USER / SMTP_PASSWORD in backend/.env and restart the server."
            ),
        )

    jobs, generated, skipped = [], 0, 0
    for p in participants:
        if p.user is None or not p.user.is_active:
            skipped += 1
            continue
        pwd_row = (
            db.query(TestPassword)
            .filter(TestPassword.test_id == test.id, TestPassword.user_id == p.user_id)
            .first()
        )
        if pwd_row and not data.resend:
            skipped += 1
            continue

        plain = gen_student_password()
        if pwd_row is None:
            pwd_row = TestPassword(test_id=test.id, user_id=p.user_id)
            db.add(pwd_row)
        pwd_row.password_hash = get_password_hash(plain)
        pwd_row.attempts = 0
        pwd_row.is_used = False
        pwd_row.used_at = None
        pwd_row.expires_at = test.end_time
        pwd_row.email_status = "pending"
        pwd_row.email_error = None
        pwd_row.sent_at = None
        db.flush()
        jobs.append({
            "row_id": pwd_row.id,
            "to_email": p.user.email,
            "student_name": p.user.full_name,
            "test_title": test.title,
            "password": plain,
            "access_code": test.access_code,
            "duration_mins": test.duration_mins,
            "end_time": test.end_time,
            "teacher_name": current_user.full_name,
        })
        generated += 1
    db.commit()

    if jobs:
        background_tasks.add_task(_deliver_passwords, jobs)

    return {
        "generated": generated,
        "skipped": skipped,
        "total_participants": len(participants),
        "email": "queued" if jobs else "none",
        "detail": (
            f"{generated} unique password(s) queued for email delivery."
            if jobs else "No new passwords generated."
        ),
    }


@router.post("/{test_id}/participants/remove")
def remove_participants(
    test_id: int,
    data: RemoveParticipantsIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_teacher),
):
    """Drop the ticked students from the roster (also deletes their exam
    passwords). Removing everyone reopens the test to all students."""
    test = _owned_test(test_id, db, current_user)
    if not data.user_ids:
        raise HTTPException(status_code=400, detail="Select at least one student")

    removed = (
        db.query(TestParticipant)
        .filter(TestParticipant.test_id == test.id,
                TestParticipant.user_id.in_(data.user_ids))
        .delete(synchronize_session=False)
    )
    db.query(TestPassword).filter(
        TestPassword.test_id == test.id,
        TestPassword.user_id.in_(data.user_ids),
    ).delete(synchronize_session=False)
    db.commit()

    left = db.query(TestParticipant).filter(TestParticipant.test_id == test.id).count()
    return {
        "removed": removed,
        "remaining": left,
        "detail": (
            f"{removed} student(s) removed from the list."
            if left else
            "List is now empty — the test is open to every student."
        ),
    }


@router.get("/{test_id}/access-status")
def student_access_status(
    test_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """What the logged-in student needs to pass before the test will open."""
    from models.models import Submission

    test = db.query(Test).filter(Test.id == test_id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")
    if current_user.role != UserRole.student:
        return AccessStatus(restricted=test_has_roster(db, test), on_list=True,
                             password_required=False)

    restricted = test_has_roster(db, test)
    on_list = (not restricted) or get_participant(db, test, current_user) is not None

    sub = (
        db.query(Submission)
        .filter(Submission.test_id == test.id, Submission.student_id == current_user.id)
        .first()
    )
    in_progress = sub is not None and not sub.is_submitted
    already_submitted = sub is not None and bool(sub.is_submitted)

    # Ask for the emailed password for every fresh attempt. Skipped when
    # resuming an attempt already in progress (the gate already ran) and when
    # the test is finished with no retake allowed (that password was burned —
    # demanding it again would lock the student out).
    retake_allowed = bool(getattr(test, "allow_retake", False))
    fresh_attempt = not in_progress and (not already_submitted or retake_allowed)
    password_required = restricted and on_list and fresh_attempt

    pwd = get_password_row(db, test, current_user) if restricted else None
    return AccessStatus(
        restricted=restricted,
        on_list=on_list,
        password_required=password_required,
        password_sent=pwd.email_status if pwd else None,
        already_started=sub is not None,
        already_submitted=already_submitted,
        retake_allowed=retake_allowed,
    )


@router.post("/{test_id}/verify-password")
def verify_student_password(
    test_id: int,
    data: PasswordIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Check the emailed password without starting the exam (instant feedback,
    counts a wrong try against the 5-attempt lock)."""
    from utils.test_access import (
        ensure_student_on_roster as _on_roster,
        ensure_student_user as _ensure_student,
        verify_test_password as _verify,
    )

    test = db.query(Test).filter(Test.id == test_id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")
    _ensure_student(current_user)
    ensure_test_available_for_student(test)
    _on_roster(db, test, current_user)
    _verify(db, test, current_user, data.password)
    return {"ok": True}

