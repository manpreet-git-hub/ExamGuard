# ── backend/database/db.py — SQLAlchemy engine + session ──────────────────────

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./examguard.db")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {},
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def run_migrations(engine):
    """Apply lightweight schema migrations for SQLite (safe to run on each startup)."""
    from sqlalchemy import text, inspect
    inspector = inspect(engine)
    with engine.connect() as conn:
        # Add allow_retake column to tests if missing
        tests_cols = [c['name'] for c in inspector.get_columns('tests')]
        if 'allow_retake' not in tests_cols:
            conn.execute(text("ALTER TABLE tests ADD COLUMN allow_retake BOOLEAN DEFAULT 0"))
            conn.commit()
            print("[Migration] Added 'allow_retake' column to tests table")

        # Add randomization columns to tests
        if 'shuffle_questions' not in tests_cols:
            conn.execute(text("ALTER TABLE tests ADD COLUMN shuffle_questions BOOLEAN DEFAULT 0"))
            conn.commit()
            print("[Migration] Added 'shuffle_questions' column to tests table")
        if 'questions_per_student' not in tests_cols:
            conn.execute(text("ALTER TABLE tests ADD COLUMN questions_per_student INTEGER DEFAULT 0"))
            conn.commit()
            print("[Migration] Added 'questions_per_student' column to tests table")
        if 'shuffle_options' not in tests_cols:
            conn.execute(text("ALTER TABLE tests ADD COLUMN shuffle_options BOOLEAN DEFAULT 0"))
            conn.commit()
            print("[Migration] Added 'shuffle_options' column to tests table")

        # Add randomization columns to submissions
        subs_cols = [c['name'] for c in inspector.get_columns('submissions')]
        if 'selected_question_ids' not in subs_cols:
            conn.execute(text("ALTER TABLE submissions ADD COLUMN selected_question_ids TEXT"))
            conn.commit()
            print("[Migration] Added 'selected_question_ids' column to submissions table")
        if 'shuffled_options_map' not in subs_cols:
            conn.execute(text("ALTER TABLE submissions ADD COLUMN shuffled_options_map TEXT"))
            conn.commit()
            print("[Migration] Added 'shuffled_options_map' column to submissions table")

        # Add student_id (enrollment number) to users. SQLite refuses a UNIQUE
        # constraint inside ALTER TABLE, so the column is added nullable and the
        # uniqueness is enforced with a separate index (multiple NULLs allowed).
        users_cols = [c['name'] for c in inspector.get_columns('users')]
        if 'student_id' not in users_cols:
            conn.execute(text("ALTER TABLE users ADD COLUMN student_id VARCHAR(100)"))
            conn.commit()
            print("[Migration] Added 'student_id' column to users table")
        if 'teacher_id' not in users_cols:
            conn.execute(text("ALTER TABLE users ADD COLUMN teacher_id VARCHAR(100)"))
            conn.commit()
            print("[Migration] Added 'teacher_id' column to users table")
        conn.execute(text(
            "CREATE UNIQUE INDEX IF NOT EXISTS ix_users_student_id ON users (student_id)"
        ))
        conn.commit()
        conn.execute(text(
            "CREATE UNIQUE INDEX IF NOT EXISTS ix_users_teacher_id ON users (teacher_id)"
        ))
        conn.commit()

        if 'course' not in users_cols:
            conn.execute(text("ALTER TABLE users ADD COLUMN course VARCHAR(120)"))
            conn.commit()
            print("[Migration] Added 'course' column to users table")

        # Email is the only login identifier now — drop the legacy username
        # column (its unique index must go first or SQLite refuses the DROP).
        users_cols = [c['name'] for c in inspector.get_columns('users')]
        if 'username' in users_cols:
            try:
                conn.execute(text("DROP INDEX IF EXISTS ix_users_username"))
                conn.execute(text("ALTER TABLE users DROP COLUMN username"))
                conn.commit()
                print("[Migration] Dropped 'username' column from users table")
            except Exception as exc:
                conn.rollback()
                print(f"[Migration] WARNING: could not drop users.username: {exc}")

        # Accounts created from the admin CSV import keep a generated password
        # until the student picks their own — this flag drives that prompt.
        try:
            conn.execute(text(
                "ALTER TABLE users ADD COLUMN must_change_password BOOLEAN DEFAULT 0"
            ))
            conn.commit()
            print("[Migration] Added 'must_change_password' column to users table")
        except Exception:
            conn.rollback()   # column already there
