"""Shared random code/password generators (used by routers, seed, admin import)."""

import random
import secrets
import string

# Unambiguous alphabet: no 0/O or 1/I so a password read from an email can't be mistyped
PWD_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

_ACCESS_ALPHABET = string.ascii_uppercase + string.digits


def gen_access_code(length=8):
    return ''.join(random.choices(_ACCESS_ALPHABET, k=length))


def gen_student_password(length=8):
    return ''.join(secrets.choice(PWD_ALPHABET) for _ in range(length))


def generate_password(length=10):
    alphabet = string.ascii_letters + string.digits
    while True:
        password = "".join(secrets.choice(alphabet) for _ in range(length))
        if any(c.isalpha() for c in password) and any(c.isdigit() for c in password):
            return password
