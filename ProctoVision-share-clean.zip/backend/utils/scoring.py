# ── backend/utils/scoring.py — Shared integrity-scoring rules ─────────────────
# Single source of truth for violation penalties and risk-level thresholds.
# Both violation paths — POST /api/proctoring/violation (client-reported) and
# the AI frame pipeline in routers/proctoring_frame.py — must score identically;
# keeping separate copies of these tables let the two drift apart.

PENALTIES = {
    "phone_detected":    30,
    "multiple_faces":    50,
    "no_face":           15,
    "tab_switched":      15,
    "looking_away":       5,
    "eye_gaze_away":      5,
    "talking":            8,
    "fullscreen_exit":   10,
    "copy_paste":         5,
    "network_disconnect": 5,
    "laptop_detected":   25,
}


def compute_risk_level(integrity_score: float) -> str:
    if integrity_score >= 80:
        return "Low"
    elif integrity_score >= 50:
        return "Medium"
    return "High"
