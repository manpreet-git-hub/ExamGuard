"""Shared environment loading (backend/.env) and production-mode guards."""

import os

try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
except Exception:  # dotenv is optional — plain env vars still work
    pass

ENV = (os.getenv("ENV") or "development").strip().lower()
IS_PRODUCTION = ENV == "production"


def required_in_production(name: str) -> str:
    """Return the env var's value; raise at startup when ENV=production and it is unset."""
    value = os.getenv(name, "").strip()
    if not value and IS_PRODUCTION:
        raise RuntimeError(
            f"{name} must be set (environment variable or backend/.env) when ENV=production"
        )
    return value
