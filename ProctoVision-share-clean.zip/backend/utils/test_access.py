from datetime import datetime

from fastapi import HTTPException

from models.models import UserRole


def _normalize_dt(value):
    if value is None:
        return None
    return value.replace(tzinfo=None) if getattr(value, "tzinfo", None) else value


def validate_test_settings(*, duration_mins, total_marks, passing_marks, start_time, end_time):
    if duration_mins is not None and duration_mins <= 0:
        raise HTTPException(status_code=400, detail="Duration must be greater than 0")
    if total_marks is not None and total_marks <= 0:
        raise HTTPException(status_code=400, detail="Total marks must be greater than 0")
    if passing_marks is not None and passing_marks < 0:
        raise HTTPException(status_code=400, detail="Passing marks cannot be negative")
    if (
        total_marks is not None
        and passing_marks is not None
        and passing_marks > total_marks
    ):
        raise HTTPException(
            status_code=400,
            detail="Passing marks cannot be greater than total marks",
        )

    start_time = _normalize_dt(start_time)
    end_time = _normalize_dt(end_time)
    if start_time and end_time and end_time <= start_time:
        raise HTTPException(
            status_code=400,
            detail="End time must be later than start time",
        )


def ensure_student_user(current_user):
    if current_user.role != UserRole.student:
        raise HTTPException(
            status_code=403,
            detail="Only student accounts can take exams",
        )


def ensure_test_available_for_student(test, *, submission=None):
    """Gate access to a test's window.

    `submission` is passed by endpoints that act on an attempt the student
    already started (save-answer, submit, resume via /start): once the window
    was open when the attempt began, the student keeps access to their own
    attempt even if end_time passes mid-exam — otherwise their work is
    stranded. Fresh access (no submission) stays strictly window-gated.
    """
    if not test or not test.is_active:
        raise HTTPException(status_code=404, detail="Test not found or inactive")

    now = datetime.utcnow()
    start_time = _normalize_dt(test.start_time)
    end_time = _normalize_dt(test.end_time)

    if start_time and now < start_time:
        raise HTTPException(status_code=403, detail="This test has not started yet")
    if end_time and now > end_time:
        if submission is None or submission.is_submitted:
            raise HTTPException(status_code=403, detail="This test has already ended")

    return test


def ensure_submission_access(submission, current_user):
    """Owner (student), the test's creator (teacher) or an admin may read a
    submission's data; anyone else gets 403."""
    if not submission:
        raise HTTPException(status_code=404, detail="Not found")
    if current_user.role == UserRole.admin:
        return submission
    if submission.student_id == current_user.id:
        return submission
    test = submission.test
    if (
        current_user.role == UserRole.teacher
        and test is not None
        and test.creator_id == current_user.id
    ):
        return submission
    raise HTTPException(status_code=403, detail="Not authorized to access this submission")


# ── Roll-number roster + unique per-student password gate ─────────────────────

# Wrong-password tries allowed before the password locks for that student.
MAX_PASSWORD_ATTEMPTS = 5


def test_has_roster(db, test) -> bool:
    """True when the teacher uploaded a student list for this test.
    Tests without a roster stay open to every logged-in student."""
    from models.models import TestParticipant
    return (
        db.query(TestParticipant.id).filter(TestParticipant.test_id == test.id).first()
        is not None
    )


def get_participant(db, test, user):
    from models.models import TestParticipant
    return db.query(TestParticipant).filter(
        TestParticipant.test_id == test.id,
        TestParticipant.user_id == user.id,
    ).first()


def get_password_row(db, test, user):
    from models.models import TestPassword
    return db.query(TestPassword).filter(
        TestPassword.test_id == test.id,
        TestPassword.user_id == user.id,
    ).first()


def ensure_student_on_roster(db, test, user):
    """403 unless the student is on the teacher's uploaded list (or the test
    has no list at all)."""
    if not test_has_roster(db, test):
        return
    if get_participant(db, test, user) is None:
        raise HTTPException(
            status_code=403,
            detail="You are not on the list for this test. Contact your teacher.",
        )


def verify_test_password(db, test, user, entered_password):
    """Validate the unique, emailed password for this student.

    Raises HTTPException on any failure; returns the password row on success.
    Increments the attempt counter for wrong guesses and locks the password
    after MAX_PASSWORD_ATTEMPTS wrong tries.
    """
    from routers.auth import verify_password as bcrypt_verify

    row = get_password_row(db, test, user)
    if row is None:
        raise HTTPException(
            status_code=403,
            detail="Your exam password has not been generated yet. Contact your teacher.",
        )

    expires_at = _normalize_dt(row.expires_at)
    if expires_at and datetime.utcnow() > expires_at:
        raise HTTPException(status_code=403, detail="Your exam password has expired.")

    attempts = row.attempts or 0
    if attempts >= MAX_PASSWORD_ATTEMPTS:
        raise HTTPException(
            status_code=403,
            detail="Too many wrong password attempts. Your password is locked — contact your teacher.",
        )

    if row.is_used and not getattr(test, "allow_retake", False):
        raise HTTPException(
            status_code=403,
            detail="This exam password has already been used. Contact your teacher for a new one.",
        )

    if not entered_password or not str(entered_password).strip():
        raise HTTPException(status_code=403, detail="Exam password required")

    if not bcrypt_verify(str(entered_password).strip(), row.password_hash):
        row.attempts = attempts + 1
        db.commit()
        left = MAX_PASSWORD_ATTEMPTS - row.attempts
        if left <= 0:
            raise HTTPException(
                status_code=403,
                detail="Too many wrong password attempts. Your password is locked — contact your teacher.",
            )
        raise HTTPException(
            status_code=403,
            detail=f"Incorrect exam password. {left} attempt(s) left.",
        )

    return row


def ensure_student_can_start(db, test, user, entered_password=None):
    """Full gate: roster + password. No-op for tests without a roster."""
    if not test_has_roster(db, test):
        return None
    ensure_student_on_roster(db, test, user)
    return verify_test_password(db, test, user, entered_password)

