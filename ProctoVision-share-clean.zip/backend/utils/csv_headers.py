# ── backend/utils/csv_headers.py — Shared CSV header recognition ──────────────
# Normalisation + accepted header tokens for uploaded spreadsheets. Used by the
# admin user-import (routers/admin.py) and the test roster import
# (routers/tests.py) so both accept the same column spellings.

import re


def norm_header(value) -> str:
    """Lower-case a header cell and normalise _ - . to single spaces."""
    text = (value or "").strip().lower().replace("_", " ").replace("-", " ").replace(".", " ")
    return re.sub(r"\s+", " ", text).strip()


# Header cells that identify the roll-number / staff-ID column
ID_HEADERS = {norm_header(v) for v in (
    "enrollment", "enrollment number", "enrollment no", "enrollment no.",
    "enroll no", "roll", "roll no", "rollno", "rollnumber", "roll number",
    "enrolment", "student id", "studentid", "register no", "register number",
    "reg no", "regno", "s.no", "s no", "sr no",
    "teacher id", "teacherid", "staff id", "faculty id",
    "employee id", "emp id", "id",
)}
NAME_HEADERS = {norm_header(v) for v in (
    "name", "full name", "student name", "candidate name", "candidate", "student",
)}
EMAIL_HEADERS = {norm_header(v) for v in (
    "email", "e-mail", "e mail", "mail", "email address", "e-mail address",
)}
COURSE_HEADERS = {norm_header(v) for v in (
    "course", "branch", "programme", "program", "degree", "class",
    "specialization", "specialisation", "department", "dept", "batch",
)}
PASSWORD_HEADERS = {norm_header(v) for v in ("password", "pwd", "passwd", "pass")}
