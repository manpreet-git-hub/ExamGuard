"""Shared location for proctoring evidence files.

Resolved relative to the backend package (not the process cwd) so the writers
(proctoring routers), the static mount in main.py and the cleanup on
test/user delete all target the same directory no matter where uvicorn was
started from.
"""
import base64
import os
import uuid
from datetime import datetime

EVIDENCE_DIR = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "storage", "evidence")
)
os.makedirs(EVIDENCE_DIR, exist_ok=True)


def save_evidence_image(b64_data: str, violation_type: str) -> str:
    """Write a base64-encoded JPEG into the evidence directory and return its
    /evidence/<file> URL path. Returns None on any failure (evidence is
    best-effort — never worth failing the violation log over)."""
    try:
        img_data = base64.b64decode(b64_data)
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        fname = f"{violation_type}_{timestamp}_{uuid.uuid4().hex[:8]}.jpg"
        fpath = os.path.join(EVIDENCE_DIR, fname)
        with open(fpath, "wb") as f:
            f.write(img_data)
        return f"/evidence/{fname}"
    except Exception as e:
        print(f"[Evidence] Failed to save screenshot: {e}")
        return None


def delete_evidence_files(evidence_paths):
    """Remove evidence image files for the given /evidence/<file> paths.
    Safe to call with None entries or paths that don't exist on disk."""
    for path in evidence_paths:
        if not path:
            continue
        # basename also guards against path traversal in stored values
        fpath = os.path.join(EVIDENCE_DIR, os.path.basename(path))
        try:
            if os.path.isfile(fpath):
                os.remove(fpath)
        except OSError as e:
            print(f"[evidence] Failed to delete {fpath}: {e}")
