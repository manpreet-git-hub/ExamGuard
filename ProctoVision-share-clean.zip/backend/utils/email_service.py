# ── backend/utils/email_service.py — Gmail SMTP delivery for test passwords ───
#
# Reads its config from environment variables / backend/.env:
#
#   SMTP_HOST=smtp.gmail.com          # Outlook: smtp-mail.outlook.com
#   SMTP_PORT=587
#   SMTP_USER=yourcollege@gmail.com   # the Gmail that sends the emails
#   SMTP_PASSWORD=xxxxxxxxxxxxxxxx    # Gmail -> App Password (16 chars), NOT your login password
#   MAIL_FROM=yourcollege@gmail.com
#   MAIL_FROM_NAME=Exam Portal
#
# Gmail setup: enable 2-Step Verification on the sender account, then create an
# "App Password" (Google Account -> Security -> App passwords) and use it here.

import os
import smtplib
import ssl
from email.message import EmailMessage
from typing import Iterable, List, Optional, Tuple

try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
except Exception:  # dotenv is optional — plain env vars still work
    pass


def _cfg(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def smtp_configured() -> bool:
    return bool(_cfg("SMTP_HOST") and _cfg("SMTP_USER") and _cfg("SMTP_PASSWORD"))


def _ssl_context() -> ssl.SSLContext:
    """TLS context for STARTTLS.

    macOS/Windows Python builds often ship without the OpenSSL CA bundle, so
    ssl.create_default_context() then fails with CERTIFICATE_VERIFY_FAILED.
    Prefer certifi's bundle when it is installed (it comes with requests).
    """
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def smtp_problem() -> Optional[str]:
    if not _cfg("SMTP_HOST"):
        return "SMTP_HOST is not set"
    if not _cfg("SMTP_USER"):
        return "SMTP_USER is not set"
    if not _cfg("SMTP_PASSWORD"):
        return "SMTP_PASSWORD is not set"
    return None


def _build_message(*, to_email, student_name, test_title, password,
                   access_code, duration_mins, end_time, teacher_name, **_) -> EmailMessage:
    end_str = end_time.strftime("%d %b %Y, %H:%M") if end_time else "no fixed deadline"
    msg = EmailMessage()
    msg["Subject"] = f"Your exam password for '{test_title}'"
    msg["From"] = f"{_cfg('MAIL_FROM_NAME', 'Exam Portal')} <{_cfg('MAIL_FROM', _cfg('SMTP_USER'))}>"
    msg["To"] = to_email
    msg.set_content(
        f"""Hello {student_name},

Your exam password for "{test_title}" is:

    {password}

Exam access code: {access_code}
Duration: {duration_mins} minutes
Deadline: {end_str}

How to enter the exam:
  1. Sign in to the exam portal with YOUR account
  2. Open the exam link and enter the access code above
  3. Enter the password shown above
  4. Allow camera + microphone, then start

This password is unique to you — do not share it with anyone.
It expires when the exam deadline passes.

--
{teacher_name or 'Your teacher'}
"""
    )
    msg.add_alternative(
        f"""\
<html><body style="font-family:Arial,Helvetica,sans-serif;color:#111">
  <p>Hello <b>{student_name}</b>,</p>
  <p>Your exam password for <b>{test_title}</b> is:</p>
  <p style="font-size:26px;letter-spacing:6px;font-weight:bold;
            background:#f3f4f6;padding:14px 18px;border-radius:8px;
            display:inline-block;border:1px dashed #9ca3af">{password}</p>
  <table cellpadding="4" style="font-size:14px;color:#374151">
    <tr><td>Access code</td><td><b style="letter-spacing:3px">{access_code}</b></td></tr>
    <tr><td>Duration</td><td>{duration_mins} minutes</td></tr>
    <tr><td>Deadline</td><td>{end_str}</td></tr>
  </table>
  <ol style="font-size:14px;color:#374151">
    <li>Sign in to the exam portal with <b>your</b> account</li>
    <li>Open the exam link and enter the access code</li>
    <li>Enter the password shown above</li>
    <li>Allow camera + microphone, then start</li>
  </ol>
  <p style="font-size:13px;color:#b91c1c"><b>This password is unique to you — do not share it.</b>
  It expires when the exam deadline passes.</p>
  <p style="font-size:13px;color:#6b7280">— {teacher_name or 'Your teacher'}</p>
</body></html>
""",
        subtype="html",
    )
    return msg


def send_password_emails(jobs: Iterable[dict]) -> List[Tuple[dict, Optional[str]]]:
    """Send every job on ONE SMTP connection.

    Each job dict needs: to_email, student_name, test_title, password,
    access_code, duration_mins, end_time, teacher_name.
    Returns [(job, error)] where error is None on success.
    """
    jobs = list(jobs)
    if not jobs:
        return []
    if not smtp_configured():
        err = f"SMTP not configured ({smtp_problem()})"
        return [(j, err) for j in jobs]

    host = _cfg("SMTP_HOST")
    port = int(_cfg("SMTP_PORT", "587"))
    user = _cfg("SMTP_USER")
    password = _cfg("SMTP_PASSWORD")

    results: List[Tuple[dict, Optional[str]]] = []
    try:
        with smtplib.SMTP(host, port, timeout=30) as server:
            server.ehlo()
            try:
                server.starttls(context=_ssl_context())
                server.ehlo()
            except smtplib.SMTPNotSupportedError:
                pass  # SMTPS / implicit TLS hosts don't need STARTTLS
            server.login(user, password)
            for job in jobs:
                try:
                    msg = _build_message(**job)
                    server.send_message(msg)
                    results.append((job, None))
                except Exception as exc:  # one bad address must not stop the rest
                    results.append((job, str(exc)[:400]))
    except Exception as exc:
        # Connection / auth failure affects every job
        err = f"SMTP error: {exc}"[:400]
        done = {id(j) for j, _ in results}
        results += [(j, err) for j in jobs if id(j) not in done]
    return results
