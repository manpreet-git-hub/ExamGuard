# ── backend/models/models.py — SQLAlchemy ORM Models ──────────────────────────

from sqlalchemy import (
    Column, Integer, String, Float, Boolean, DateTime, Text, JSON,
    ForeignKey, Enum as SAEnum
)
from sqlalchemy.orm import relationship, backref
from sqlalchemy.sql import func
import enum
from database.db import Base


class UserRole(str, enum.Enum):
    teacher = "teacher"
    student = "student"
    admin   = "admin"


class QuestionType(str, enum.Enum):
    mcq             = "mcq"
    multiple_correct = "multiple_correct"
    short_answer    = "short_answer"
    coding          = "coding"


class User(Base):
    __tablename__ = "users"

    id           = Column(Integer, primary_key=True, index=True)
    email        = Column(String(255), unique=True, index=True, nullable=False)
    full_name    = Column(String(255), nullable=False)
    # Course / branch / programme the student belongs to (from the import CSV)
    course       = Column(String(120))
    hashed_password = Column(String(255), nullable=False)
    role         = Column(SAEnum(UserRole), default=UserRole.student, nullable=False)
    is_active    = Column(Boolean, default=True)
    created_at   = Column(DateTime(timezone=True), server_default=func.now())
    # Institution-issued enrollment/roll number. NULL for manually created
    # accounts; unique across the table when present.
    student_id   = Column(String(100), unique=True, index=True)
    # Staff/faculty ID — same idea as student_id but for teacher accounts, so a
    # teacher never carries a "student_id".
    teacher_id   = Column(String(100), unique=True, index=True)
    # True while the account is still on a system/default password (e.g. created
    # by the admin CSV import). The app blocks every page until the user sets
    # their own password.
    must_change_password = Column(Boolean, default=False)

    created_tests       = relationship("Test", back_populates="creator", cascade="all, delete-orphan")
    submissions         = relationship("Submission", back_populates="student", cascade="all, delete-orphan")


class Test(Base):
    __tablename__ = "tests"

    id            = Column(Integer, primary_key=True, index=True)
    title         = Column(String(255), nullable=False)
    description   = Column(Text)
    access_code   = Column(String(20), unique=True, index=True, nullable=False)
    duration_mins = Column(Integer, nullable=False)
    total_marks   = Column(Integer, nullable=False)
    passing_marks = Column(Integer, nullable=False)
    start_time    = Column(DateTime(timezone=True))
    end_time      = Column(DateTime(timezone=True))
    is_active     = Column(Boolean, default=True)
    allow_retake  = Column(Boolean, default=False)
    # Randomization settings
    shuffle_questions    = Column(Boolean, default=False)
    questions_per_student = Column(Integer, default=0)  # 0 = show all questions
    shuffle_options      = Column(Boolean, default=False)
    creator_id    = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
    updated_at    = Column(DateTime(timezone=True), onupdate=func.now())

    creator     = relationship("User", back_populates="created_tests")
    questions   = relationship("Question", back_populates="test", order_by="Question.order_index", cascade="all, delete-orphan")
    submissions = relationship("Submission", back_populates="test", cascade="all, delete-orphan")


class TestParticipant(Base):
    """A student the teacher selected (via CSV upload / roll-number entry) as the
    only people allowed to attempt the test. If a test has NO participants it is
    open to every logged-in student (legacy behaviour)."""
    __tablename__ = "test_participants"

    id         = Column(Integer, primary_key=True, index=True)
    test_id    = Column(Integer, ForeignKey("tests.id"), nullable=False)
    user_id    = Column(Integer, ForeignKey("users.id"), nullable=False)
    roll_no    = Column(String(100))       # snapshot of User.student_id at upload time
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # cascade on the *parent* side: deleting a test or a user removes the
    # roster rows instead of trying to NULL a NOT NULL FK (which 500s).
    test = relationship("Test", backref=backref("participants", cascade="all, delete-orphan"))
    user = relationship("User", backref=backref("roster_entries", cascade="all, delete-orphan"))


class TestPassword(Base):
    """The unique, per-student password emailed to the student's registered
    mailbox. Only the bcrypt hash is stored — the plaintext exists solely in the
    email that was sent."""
    __tablename__ = "test_passwords"

    id            = Column(Integer, primary_key=True, index=True)
    test_id       = Column(Integer, ForeignKey("tests.id"), nullable=False)
    user_id       = Column(Integer, ForeignKey("users.id"), nullable=False)
    password_hash = Column(String(255), nullable=False)
    attempts      = Column(Integer, default=0)   # wrong tries so far
    is_used       = Column(Boolean, default=False)
    used_at       = Column(DateTime(timezone=True))
    expires_at    = Column(DateTime(timezone=True))  # = test.end_time
    email_status  = Column(String(20), default="pending")  # pending|sent|failed|skipped
    email_error   = Column(String(500))
    sent_at       = Column(DateTime(timezone=True))
    created_at    = Column(DateTime(timezone=True), server_default=func.now())

    test = relationship("Test", backref=backref("test_passwords", cascade="all, delete-orphan"))
    user = relationship("User", backref=backref("exam_passwords", cascade="all, delete-orphan"))


class Question(Base):
    __tablename__ = "questions"

    id            = Column(Integer, primary_key=True, index=True)
    test_id       = Column(Integer, ForeignKey("tests.id"), nullable=False)
    question_text = Column(Text, nullable=False)
    question_type = Column(SAEnum(QuestionType), nullable=False)
    options       = Column(JSON)           # list of option strings for MCQ
    correct_answer = Column(JSON)          # string or list of strings
    marks         = Column(Integer, default=1)
    order_index   = Column(Integer, default=0)
    explanation   = Column(Text)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())

    test    = relationship("Test", back_populates="questions")
    answers = relationship("Answer", back_populates="question", cascade="all, delete-orphan")


class Submission(Base):
    __tablename__ = "submissions"

    id               = Column(Integer, primary_key=True, index=True)
    test_id          = Column(Integer, ForeignKey("tests.id"), nullable=False)
    student_id       = Column(Integer, ForeignKey("users.id"), nullable=False)
    started_at       = Column(DateTime(timezone=True), server_default=func.now())
    submitted_at     = Column(DateTime(timezone=True))
    time_taken_secs  = Column(Integer)
    score            = Column(Float, default=0)
    max_score        = Column(Integer, default=0)
    percentage       = Column(Float, default=0)
    passed           = Column(Boolean, default=False)
    integrity_score  = Column(Float, default=100)
    risk_level       = Column(String(20), default="Low")
    is_submitted     = Column(Boolean, default=False)
    auto_submitted   = Column(Boolean, default=False)
    # Random question selection: stores the list of question IDs assigned to this student
    selected_question_ids = Column(JSON)  # e.g. [5, 12, 23, ...]
    # Stores shuffled option mapping per question for MCQ: {question_id: [shuffled_options]}
    shuffled_options_map  = Column(JSON)

    test     = relationship("Test", back_populates="submissions")
    student  = relationship("User", back_populates="submissions")
    answers  = relationship("Answer", back_populates="submission", cascade="all, delete-orphan")
    violations = relationship("ViolationLog", back_populates="submission", cascade="all, delete-orphan")


class Answer(Base):
    __tablename__ = "answers"

    id              = Column(Integer, primary_key=True, index=True)
    submission_id   = Column(Integer, ForeignKey("submissions.id"), nullable=False)
    question_id     = Column(Integer, ForeignKey("questions.id"), nullable=False)
    answer_text     = Column(Text)
    selected_options = Column(JSON)        # list for multiple choice
    is_correct      = Column(Boolean)
    marks_awarded   = Column(Float, default=0)
    answered_at     = Column(DateTime(timezone=True), server_default=func.now())

    submission = relationship("Submission", back_populates="answers")
    question   = relationship("Question", back_populates="answers")


class ViolationLog(Base):
    __tablename__ = "violation_logs"

    id               = Column(Integer, primary_key=True, index=True)
    submission_id    = Column(Integer, ForeignKey("submissions.id"), nullable=False)
    student_id       = Column(Integer, ForeignKey("users.id"), nullable=False)
    test_id          = Column(Integer, ForeignKey("tests.id"), nullable=False)
    violation_type   = Column(String(50), nullable=False)
    confidence_score = Column(Float, default=1.0)
    description      = Column(Text)
    evidence_path    = Column(String(500))   # path to screenshot/video clip
    timestamp        = Column(DateTime(timezone=True), server_default=func.now())
    penalty_applied  = Column(Integer, default=0)

    submission = relationship("Submission", back_populates="violations")
