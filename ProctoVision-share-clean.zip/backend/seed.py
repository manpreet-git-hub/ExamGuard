#!/usr/bin/env python3
# ── backend/seed.py — Seed database with demo users, tests, and questions ──────

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

from database.db import engine, SessionLocal, Base
from models.models import User, Test, Question, UserRole, QuestionType
from routers.auth import get_password_hash
from utils.generators import gen_access_code
from datetime import datetime, timedelta

Base.metadata.create_all(bind=engine)
db = SessionLocal()

print("Seeding database...")

# ── Users ──────────────────────────────────────────────────────────────────────
def get_or_create_user(email, full_name, role, password="demo1234"):
    user = db.query(User).filter(User.email == email).first()
    if not user:
        user = User(
            email=email, full_name=full_name, role=role,
            hashed_password=get_password_hash(password),
        )
        db.add(user)
        db.flush()
    return user

teacher  = get_or_create_user("teacher@demo.com", "Dr. Sarah Johnson",   UserRole.teacher)
teacher2 = get_or_create_user("teacher2@demo.com", "Prof. James Wilson",  UserRole.teacher)
student  = get_or_create_user("student@demo.com", "Alex Kumar",          UserRole.student)
student2 = get_or_create_user("student2@demo.com", "Priya Patel",         UserRole.student)
student3 = get_or_create_user("student3@demo.com", "Maria Garcia",        UserRole.student)
admin    = get_or_create_user("admin@demo.com", "Admin User",          UserRole.admin)
db.commit()

# ── Test 1: Computer Science Fundamentals ─────────────────────────────────────
existing_test = db.query(Test).filter(Test.creator_id == teacher.id).first()
if not existing_test:
    test = Test(
        title="Computer Science Fundamentals",
        description="A comprehensive test covering data structures, algorithms, and OS concepts.",
        access_code=gen_access_code(),
        duration_mins=60,
        total_marks=50,
        passing_marks=25,
        start_time=datetime.utcnow(),
        end_time=datetime.utcnow() + timedelta(days=7),
        shuffle_questions=False,
        shuffle_options=True,
        creator_id=teacher.id,
    )
    db.add(test)
    db.commit()
    db.refresh(test)

    questions = [
        Question(
            test_id=test.id, order_index=0, marks=5,
            question_type=QuestionType.mcq,
            question_text="What is the time complexity of binary search?",
            options=["O(n)", "O(log n)", "O(n^2)", "O(1)"],
            correct_answer="O(log n)",
            explanation="Binary search halves the search space each step.",
        ),
        Question(
            test_id=test.id, order_index=1, marks=5,
            question_type=QuestionType.mcq,
            question_text="Which data structure uses LIFO ordering?",
            options=["Queue", "Stack", "Heap", "Linked List"],
            correct_answer="Stack",
        ),
        Question(
            test_id=test.id, order_index=2, marks=5,
            question_type=QuestionType.mcq,
            question_text="What does CPU stand for?",
            options=["Central Processing Unit", "Computer Processing Unit", "Central Program Utility", "Core Processing Unit"],
            correct_answer="Central Processing Unit",
        ),
        Question(
            test_id=test.id, order_index=3, marks=5,
            question_type=QuestionType.multiple_correct,
            question_text="Which of the following are sorting algorithms? (Select all that apply)",
            options=["Quicksort", "Binary Search", "Mergesort", "Bubble Sort"],
            correct_answer=["Quicksort", "Mergesort", "Bubble Sort"],
        ),
        Question(
            test_id=test.id, order_index=4, marks=10,
            question_type=QuestionType.short_answer,
            question_text="Explain the difference between a process and a thread in an operating system.",
            correct_answer="A process is an independent program in execution with its own memory space. A thread is a unit of execution within a process, sharing the same memory space as other threads in the same process.",
        ),
        Question(
            test_id=test.id, order_index=5, marks=5,
            question_type=QuestionType.mcq,
            question_text="Which of the following is NOT a NoSQL database?",
            options=["MongoDB", "Cassandra", "PostgreSQL", "Redis"],
            correct_answer="PostgreSQL",
        ),
        Question(
            test_id=test.id, order_index=6, marks=5,
            question_type=QuestionType.mcq,
            question_text="What is the worst-case time complexity of QuickSort?",
            options=["O(n log n)", "O(n^2)", "O(n)", "O(log n)"],
            correct_answer="O(n^2)",
        ),
        Question(
            test_id=test.id, order_index=7, marks=10,
            question_type=QuestionType.coding,
            question_text="Write a Python function that reverses a string without using built-in reverse functions.\n\nExample:\n  reverse_string('hello') -> 'olleh'",
            correct_answer="def reverse_string(s):\n    result = ''\n    for char in s:\n        result = char + result\n    return result",
        ),
    ]
    for q in questions:
        db.add(q)
    db.commit()

    print(f"\n  Test 1: {test.title}")
    print(f"  Access Code: {test.access_code}")
    print(f"  Link: http://localhost:3000/test/{test.access_code}")
else:
    print(f"  Test 1 already exists: {existing_test.access_code}")

# ── Test 2: Web Development Basics ───────────────────────────────────────────
existing_test2 = db.query(Test).filter(Test.title == "Web Development Basics", Test.creator_id == teacher.id).first()
if not existing_test2:
    test2 = Test(
        title="Web Development Basics",
        description="Test your knowledge of HTML, CSS, JavaScript, and web concepts.",
        access_code=gen_access_code(),
        duration_mins=45,
        total_marks=40,
        passing_marks=20,
        start_time=datetime.utcnow(),
        end_time=datetime.utcnow() + timedelta(days=14),
        shuffle_questions=True,
        questions_per_student=6,
        shuffle_options=True,
        creator_id=teacher.id,
    )
    db.add(test2)
    db.commit()
    db.refresh(test2)

    questions2 = [
        Question(
            test_id=test2.id, order_index=0, marks=5,
            question_type=QuestionType.mcq,
            question_text="What does HTML stand for?",
            options=["Hyper Text Markup Language", "High Tech Modern Language", "Hyper Text Machine Learning", "Home Tool Markup Language"],
            correct_answer="Hyper Text Markup Language",
        ),
        Question(
            test_id=test2.id, order_index=1, marks=5,
            question_type=QuestionType.mcq,
            question_text="Which CSS property changes the text color?",
            options=["font-color", "text-color", "color", "foreground"],
            correct_answer="color",
        ),
        Question(
            test_id=test2.id, order_index=2, marks=5,
            question_type=QuestionType.mcq,
            question_text="Which tag is used for the largest heading in HTML?",
            options=["<heading>", "<h6>", "<h1>", "<head>"],
            correct_answer="<h1>",
        ),
        Question(
            test_id=test2.id, order_index=3, marks=5,
            question_type=QuestionType.multiple_correct,
            question_text="Which of the following are valid JavaScript data types? (Select all)",
            options=["string", "boolean", "float", "number", "character"],
            correct_answer=["string", "boolean", "number"],
        ),
        Question(
            test_id=test2.id, order_index=4, marks=5,
            question_type=QuestionType.mcq,
            question_text="What is the box model order from inside out?",
            options=["margin, border, padding, content", "content, padding, border, margin", "border, margin, padding, content", "content, border, margin, padding"],
            correct_answer="content, padding, border, margin",
        ),
        Question(
            test_id=test2.id, order_index=5, marks=5,
            question_type=QuestionType.mcq,
            question_text="Which HTTP method is used to retrieve data?",
            options=["POST", "PUT", "GET", "DELETE"],
            correct_answer="GET",
        ),
        Question(
            test_id=test2.id, order_index=6, marks=5,
            question_type=QuestionType.short_answer,
            question_text="What is the purpose of the 'alt' attribute on an <img> tag?",
            correct_answer="The alt attribute provides alternative text for an image if it cannot be displayed, and is used by screen readers for accessibility.",
        ),
        Question(
            test_id=test2.id, order_index=7, marks=5,
            question_type=QuestionType.mcq,
            question_text="Which symbol is used for single-line comments in JavaScript?",
            options=["/* */", "//", "#", "--"],
            correct_answer="//",
        ),
    ]
    for q in questions2:
        db.add(q)
    db.commit()

    print(f"\n  Test 2: {test2.title}")
    print(f"  Access Code: {test2.access_code}")
    print(f"  Link: http://localhost:3000/test/{test2.access_code}")
else:
    print(f"  Test 2 already exists: {existing_test2.access_code}")

db.close()
print("\nSeed complete!")
print("  Teacher 1: teacher@demo.com  / demo1234")
print("  Teacher 2: teacher2@demo.com / demo1234")
print("  Student 1: student@demo.com  / demo1234")
print("  Student 2: student2@demo.com / demo1234")
print("  Student 3: student3@demo.com / demo1234")
print("  Admin:     admin@demo.com    / demo1234")
