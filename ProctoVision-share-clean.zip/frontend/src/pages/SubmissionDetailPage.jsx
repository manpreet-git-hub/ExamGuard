import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, AlertTriangle, CheckCircle, XCircle, Shield, Camera, Loader2, FileText, Save } from 'lucide-react';
import toast from 'react-hot-toast';
import Layout from '../components/shared/Layout';
import api, { getEvidenceUrl } from '../utils/api';
import { format } from 'date-fns';
import { parseApiDate } from '../utils/datetime';

const V_LABELS = {
  phone_detected: 'Phone Detected', tab_switched: 'Tab Switched', looking_away: 'Looking Away',
  multiple_faces: 'Multiple Faces', no_face: 'No Face Detected', talking: 'Talking Detected',
  eye_gaze_away: 'Eye Gaze Away', fullscreen_exit: 'Exited Fullscreen', copy_paste: 'Copy/Paste Attempt',
  network_disconnect: 'Network Disconnect', laptop_detected: 'Laptop Detected',
};

const V_STYLE = {
  phone_detected:    { bg: 'var(--danger-bg)', border: 'var(--danger-border)', color: '#ef4444' },
  multiple_faces:    { bg: 'var(--danger-bg)', border: 'var(--danger-border)', color: '#ef4444' },
  no_face:           { bg: 'var(--danger-bg)', border: 'var(--danger-border)', color: '#ef4444' },
  tab_switched:      { bg: 'var(--warning-bg)', border: 'var(--warning-border)', color: '#f59e0b' },
  fullscreen_exit:   { bg: 'var(--warning-bg)', border: 'var(--warning-border)', color: '#f59e0b' },
  copy_paste:        { bg: 'var(--warning-bg)', border: 'var(--warning-border)', color: '#f59e0b' },
  looking_away:      { bg: 'var(--warning-bg)', border: 'var(--warning-border)', color: '#f59e0b' },
  eye_gaze_away:     { bg: 'var(--warning-bg)', border: 'var(--warning-border)', color: '#f59e0b' },
  talking:           { bg: 'var(--warning-bg)', border: 'var(--warning-border)', color: '#f59e0b' },
  network_disconnect:{ bg: 'var(--bg-tertiary)', border: 'var(--border-secondary)', color: 'var(--text-tertiary)' },
  laptop_detected:   { bg: 'var(--brand-bg)', border: 'var(--brand-border)', color: 'var(--brand-primary)' },
};

export default function SubmissionDetailPage() {
  const { testId, submissionId } = useParams();
  const navigate = useNavigate();
  const [data, setData]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab]       = useState('violations');
  const [grading, setGrading] = useState({});
  const [gradingSaving, setGradingSaving] = useState({});

  useEffect(() => {
    api.get(`/api/results/submission/${submissionId}/detail`)
      .then(r => setData(r.data))
      .catch(() => { toast.error('Failed to load submission'); navigate(`/tests/${testId}/results`); })
      .finally(() => setLoading(false));
  }, [submissionId]);

  const saveGrade = async (questionId, maxMarks) => {
    const marks = parseFloat(grading[questionId]);
    if (isNaN(marks) || marks < 0 || marks > maxMarks) { toast.error(`Marks must be 0–${maxMarks}`); return; }
    setGradingSaving(prev => ({ ...prev, [questionId]: true }));
    try {
      await api.post(`/api/submissions/${submissionId}/grade/${questionId}`, { marks_awarded: marks });
      toast.success('Marks saved!');
      const r = await api.get(`/api/results/submission/${submissionId}/detail`);
      setData(r.data);
      setGrading(prev => { const n = {...prev}; delete n[questionId]; return n; });
    } catch (e) { toast.error(e.response?.data?.detail || 'Failed'); }
    finally { setGradingSaving(prev => ({ ...prev, [questionId]: false })); }
  };

  if (loading) return <Layout><div className="flex items-center justify-center h-48"><div className="w-8 h-8 rounded-full border-2 border-cyan-500/20 border-t-cyan-500 animate-spin" /></div></Layout>;

  const { submission: sub, violations = [], answers = [] } = data || {};
  const evidenceItems = violations.filter(v => v.evidence_path);

  return (
    <Layout title="Submission Detail">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-2 mb-6 text-sm" style={{ color: 'var(--text-muted)' }}>
          <button onClick={() => navigate(`/tests/${testId}/results`)} className="flex items-center gap-1 hover:underline">
            <ArrowLeft size={14} /> Results
          </button>
          <span>/</span>
          <span style={{ color: 'var(--text-primary)' }}>{sub?.student_name}</span>
        </div>

        <div className="card p-5 mb-6">
          <div className="flex items-start justify-between flex-wrap gap-4 mb-5">
            <div>
              <h2 className="text-lg font-display font-semibold" style={{ color: 'var(--text-primary)' }}>{sub?.student_name}</h2>
              <p className="text-sm" style={{ color: 'var(--text-muted)' }}>{sub?.student_email}</p>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              {sub?.passed
                ? <span className="badge-green text-sm px-3 py-1"><CheckCircle size={13} /> Passed</span>
                : <span className="badge-red text-sm px-3 py-1"><XCircle size={13} /> Failed</span>}
              <span className={`badge text-sm px-3 py-1 ${sub?.risk_level === 'Low' ? 'badge-green' : sub?.risk_level === 'Medium' ? 'badge-yellow' : 'badge-red'}`}>
                <Shield size={13} /> {sub?.risk_level} Risk
              </span>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Score',      value: `${sub?.score}/${sub?.max_score}` },
              { label: 'Percentage', value: `${(sub?.percentage || 0).toFixed(1)}%` },
              { label: 'Integrity',  value: Math.round(sub?.integrity_score ?? 100) },
              { label: 'Time Taken', value: sub?.time_taken_secs ? `${Math.floor(sub.time_taken_secs/60)}m ${sub.time_taken_secs%60}s` : '—' },
            ].map((s, i) => (
              <div key={i} className="rounded-lg p-3" style={{ background: 'var(--bg-tertiary)' }}>
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{s.label}</p>
                <p className="text-base font-bold mt-0.5" style={{ color: 'var(--text-primary)' }}>{s.value}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-1 mb-5 p-1 w-fit rounded-xl" style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border-primary)' }}>
          {[
            { key: 'violations', label: `Violations (${violations.length})`,   icon: AlertTriangle },
            { key: 'answers',    label: `Answers (${answers.length})`,          icon: FileText      },
            { key: 'evidence',   label: `Evidence (${evidenceItems.length})`,   icon: Camera        },
          ].map(({ key, label, icon: Icon }) => (
            <button key={key} onClick={() => setTab(key)}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200"
              style={{
                background: tab === key ? 'var(--bg-tertiary)' : 'transparent',
                color: tab === key ? 'var(--text-primary)' : 'var(--text-muted)',
              }}>
              <Icon size={14} /> {label}
            </button>
          ))}
        </div>

        {tab === 'violations' && (
          <div className="card p-5">
            {violations.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle size={32} className="text-emerald-400 mx-auto mb-3" />
                <p className="font-medium" style={{ color: 'var(--text-primary)' }}>No violations — clean exam</p>
              </div>
            ) : (
              <div className="relative pl-4 space-y-3">
                <div className="absolute left-2 top-2 bottom-2 w-px" style={{ background: 'var(--border-primary)' }} />
                {violations.map((v, i) => {
                  const style = V_STYLE[v.violation_type] || { bg: 'var(--bg-tertiary)', border: 'var(--border-secondary)', color: 'var(--text-tertiary)' };
                  return (
                    <motion.div key={v.id || i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="relative flex gap-3 p-3 rounded-lg" style={{ background: style.bg, border: `1px solid ${style.border}` }}>
                      <div className="absolute left-[-20px] w-3 h-3 rounded-full mt-1" style={{ background: 'var(--bg-secondary)', border: `2px solid ${style.color}` }} />
                      <AlertTriangle size={14} className="flex-shrink-0 mt-0.5" style={{ color: style.color }} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="text-xs font-semibold" style={{ color: style.color }}>{V_LABELS[v.violation_type] || v.violation_type}</span>
                          <span className="text-xs font-mono" style={{ color: 'var(--text-muted)' }}>{v.timestamp ? format(parseApiDate(v.timestamp), 'HH:mm:ss') : ''}</span>
                        </div>
                        {v.description && <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{v.description}</p>}
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Conf: {((v.confidence_score || 1) * 100).toFixed(0)}%</span>
                          {v.penalty_applied > 0 && <span className="text-xs text-red-400">−{v.penalty_applied} pts</span>}
                        </div>
                      </div>
                      {v.evidence_path && (
                        <a href={getEvidenceUrl(v.evidence_path)} target="_blank" rel="noopener noreferrer"
                          className="flex-shrink-0 transition-colors" style={{ color: 'var(--text-muted)' }}>
                          <Camera size={14} />
                        </a>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {tab === 'answers' && (
          <div className="space-y-3">
            {answers.length === 0 ? <div className="card p-8 text-center text-sm" style={{ color: 'var(--text-muted)' }}>No answer data</div>
            : answers.map((a, i) => (
              <div key={i} className="card p-4" style={{ borderLeft: `4px solid ${a.is_correct === true ? '#10b981' : a.is_correct === false ? '#ef4444' : 'var(--border-secondary)'}` }}>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <span className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>Q{i + 1} — {a.question_type?.replace('_', ' ')}</span>
                  <div>
                    {a.is_correct === true  && <span className="badge-green text-xs">+{a.marks_awarded}/{a.max_marks}</span>}
                    {a.is_correct === false && <span className="badge-red text-xs">0/{a.max_marks}</span>}
                    {a.is_correct === null && (
                      <div className="flex items-center gap-1.5">
                        <span className="badge-gray text-xs">Manual</span>
                        <input type="number" min="0" max={a.max_marks} step="0.5"
                          placeholder={`${a.marks_awarded ?? 0}/${a.max_marks}`}
                          value={grading[a.question_id] !== undefined ? grading[a.question_id] : (a.marks_awarded ?? '')}
                          onChange={e => setGrading(prev => ({ ...prev, [a.question_id]: e.target.value }))}
                          className="w-20 text-xs rounded px-2 py-0.5 focus:outline-none"
                          style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-secondary)', color: 'var(--text-primary)' }} />
                        <span className="text-xs" style={{ color: 'var(--text-muted)' }}>/ {a.max_marks}</span>
                        <button onClick={() => saveGrade(a.question_id, a.max_marks)} disabled={gradingSaving[a.question_id]}
                          style={{ color: 'var(--brand-primary)' }} className="disabled:opacity-50 transition-colors">
                          {gradingSaving[a.question_id] ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
                <p className="text-sm mb-2 whitespace-pre-wrap" style={{ color: 'var(--text-primary)' }}>{a.question_text}</p>
                {a.selected_options?.length > 0 && (
                  <div className="text-xs rounded p-2 mb-1.5" style={{ background: 'var(--bg-tertiary)' }}>
                    <span style={{ color: 'var(--text-muted)' }}>Student answered: </span>
                    <span style={{ color: 'var(--text-primary)' }}>{a.selected_options.join(', ')}</span>
                  </div>
                )}
                {a.answer_text && (
                  <div className="text-xs rounded p-2 mb-1.5 whitespace-pre-wrap" style={{ background: 'var(--bg-tertiary)' }}>
                    <span style={{ color: 'var(--text-muted)' }}>Student answered: </span>
                    <span style={{ color: 'var(--text-primary)' }}>{a.answer_text}</span>
                  </div>
                )}
                {!a.selected_options?.length && !a.answer_text && <p className="text-xs italic" style={{ color: 'var(--text-muted)' }}>Not answered</p>}
                {a.correct_answer && a.is_correct === false && !['short_answer','coding'].includes(a.question_type) && (
                  <p className="text-xs text-emerald-400 mt-1">✓ Correct: {Array.isArray(a.correct_answer) ? a.correct_answer.join(', ') : a.correct_answer}</p>
                )}
              </div>
            ))}
          </div>
        )}

        {tab === 'evidence' && (
          <div>
            {evidenceItems.length === 0 ? <div className="card p-10 text-center text-sm" style={{ color: 'var(--text-muted)' }}>No evidence screenshots captured</div>
            : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {evidenceItems.map((v, i) => (
                  <motion.div key={i} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.05 }} className="card overflow-hidden">
                    <a href={getEvidenceUrl(v.evidence_path)} target="_blank" rel="noopener noreferrer">
                      <img src={getEvidenceUrl(v.evidence_path)} alt={v.violation_type}
                        className="w-full aspect-video object-cover hover:opacity-80 transition-opacity"
                        style={{ background: 'var(--bg-tertiary)' }} />
                    </a>
                    <div className="p-2.5">
                      <p className="text-xs font-medium text-red-400 capitalize">{V_LABELS[v.violation_type] || v.violation_type}</p>
                      <p className="text-xs font-mono" style={{ color: 'var(--text-muted)' }}>{v.timestamp ? format(parseApiDate(v.timestamp), 'HH:mm:ss') : ''}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}
      </motion.div>
    </Layout>
  );
}
