// src/pages/OverviewPage.jsx — totals + the teacher's own tests and submissions
import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  FileText, Inbox, AlertTriangle, Loader2, RefreshCw, Eye, BarChart2,
  ToggleLeft, ToggleRight, Search
} from 'lucide-react';
import toast from 'react-hot-toast';
import Layout from '../components/shared/Layout';
import api from '../utils/api';
import { parseApiDate } from '../utils/datetime';
import { useAuth } from '../contexts/AuthContext';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: (i = 0) => ({ opacity: 1, y: 0, transition: { delay: i * 0.07, duration: 0.35, ease: 'easeOut' } }),
};

// Backend stores naive UTC datetimes; datetime-local speaks local wall-clock.
const toDatetimeLocalUtc = (value) => {
  if (!value) return '';
  const date = parseApiDate(value);
  return date ? date.toISOString().slice(0, 16) : '';
};

const datetimeLocalToUtcIso = (value) => {
  if (!value) return null;
  const text = value.length === 16 ? `${value}:00` : value;
  const date = new Date(`${text}Z`);
  return Number.isNaN(date.getTime()) ? null : date.toISOString();
};

function StatCard({ icon: Icon, label, value, color, index = 0 }) {
  return (
    <motion.div variants={fadeUp} custom={index} className="card"
      style={{ padding: '1rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
      <div style={{ background: color, borderRadius: '0.75rem', width: '2.75rem', height: '2.75rem', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon size={20} style={{ color: '#fff' }} />
      </div>
      <div>
        <p className="font-display" style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)' }}>{value ?? '—'}</p>
        <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.125rem' }}>{label}</p>
      </div>
    </motion.div>
  );
}

function Panel({ title, icon: Icon, count, children, index = 0 }) {
  return (
    <motion.section variants={fadeUp} custom={index} className="card" style={{ overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '1rem' }}>
        <Icon size={18} style={{ color: 'var(--brand-primary)' }} />
        <span className="font-display" style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{title}</span>
        <span style={{
          fontSize: '0.75rem', background: 'var(--brand-bg)', color: 'var(--brand-primary)',
          border: '1px solid var(--brand-border)', padding: '0.125rem 0.5rem',
          borderRadius: '9999px', fontFamily: 'monospace'
        }}>{count}</span>
      </div>
      <div style={{ borderTop: '1px solid var(--border-primary)' }}>{children}</div>
    </motion.section>
  );
}

export default function OverviewPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  // Admins get a counts-only history of ALL teachers' activity; teachers keep
  // the detail tables for their own tests.
  const isAdmin = user?.role === 'admin';
  const [period, setPeriod]       = useState('all');   // 'all' | 'year' | 'month'
  const [stats, setStats]         = useState(null);
  const [tests, setTests]         = useState([]);
  const [subs, setSubs]           = useState([]);
  const [subSearch, setSubSearch] = useState('');
  const [loading, setLoading]     = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async (first = false) => {
    if (first) setLoading(true); else setRefreshing(true);
    try {
      if (isAdmin) {
        const s = await api.get('/api/admin/stats');
        setStats(s.data);
      } else {
        const [s, t, sub] = await Promise.all([
          api.get('/api/admin/stats'),
          api.get('/api/admin/tests'),
          api.get('/api/admin/submissions'),
        ]);
        setStats(s.data);
        setTests(t.data);
        setSubs(sub.data);
      }
    } catch (e) {
      toast.error('Failed to load overview: ' + (e.response?.data?.detail || e.message));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [isAdmin]);

  useEffect(() => { load(true); }, [load]);

  const updateTest = async (id, patch, message = 'Test updated') => {
    try {
      await api.put(`/api/admin/tests/${id}`, patch);
      toast.success(message);
      await load();
    } catch (e) {
      toast.error('Update failed: ' + (e.response?.data?.detail || e.message));
    }
  };

  const inputStyle = {
    background: 'var(--bg-tertiary)',
    border: '1px solid var(--border-primary)',
    borderRadius: '0.25rem',
    fontSize: '0.75rem',
    color: 'var(--text-primary)',
    outline: 'none',
    padding: '0.25rem 0.375rem',
  };

  const thStyle = { textAlign: 'left', padding: '0.5rem 1rem', fontSize: '0.75rem', color: 'var(--text-muted)', borderBottom: '1px solid var(--border-primary)', fontWeight: 500 };
  const tdStyle = { padding: '0.75rem 1rem', borderBottom: '1px solid var(--border-primary)' };
  const rowHover = {
    borderBottom: '1px solid var(--border-primary)',
    transition: 'background 0.15s',
  };
  const fmt = (v) => (v ? (parseApiDate(v)?.toLocaleString() || '—') : '—');

  const filteredSubs = subs.filter(s => {
    const q = subSearch.trim().toLowerCase();
    if (!q) return true;
    return (s.student_name || '').toLowerCase().includes(q)
      || (s.student_email || '').toLowerCase().includes(q)
      || (s.test_title || '').toLowerCase().includes(q)
      || String(s.id) === q
      || String(s.test_id) === q;
  });

  if (loading) return (
    <Layout title="Overview">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '16rem' }}>
        <Loader2 size={32} className="animate-spin" style={{ color: 'var(--brand-primary)' }} />
      </div>
    </Layout>
  );

  return (
    <Layout title="Overview">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{ background: 'var(--brand-primary)', borderRadius: '0.75rem', width: '2.5rem', height: '2.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <BarChart2 size={18} style={{ color: '#fff' }} />
          </div>
          <div>
            <h1 className="font-display" style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--text-primary)' }}>Overview</h1>
            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              {isAdmin
                ? "All teachers' tests and submissions — total, this year and this month"
                : 'Your tests, submissions and violations at a glance'}
            </p>
          </div>
        </div>
        <button onClick={() => load()} className="btn-secondary"
          style={{ fontSize: '0.75rem', padding: '0.5rem 0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
          <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} /> Refresh
        </button>
      </motion.div>

      {isAdmin ? (
        <>
          {/* Period filter — Till Now / This Year / This Month */}
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '1rem' }}>
            {[
              { key: 'all',   label: 'Till Now' },
              { key: 'year',  label: 'This Year' },
              { key: 'month', label: 'This Month' },
            ].map(opt => {
              const active = period === opt.key;
              return (
                <button
                  key={opt.key}
                  onClick={() => setPeriod(opt.key)}
                  style={{
                    fontSize: '0.75rem', fontWeight: 600, padding: '0.4rem 0.9rem',
                    borderRadius: '9999px', cursor: 'pointer', transition: 'all 0.15s',
                    border: `1px solid ${active ? 'transparent' : 'var(--border-primary)'}`,
                    background: active ? 'var(--brand-primary)' : 'var(--bg-tertiary)',
                    color: active ? '#fff' : 'var(--text-secondary)',
                  }}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>

          <motion.div initial="hidden" animate="visible" style={{ display: 'grid', gap: '1rem', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', marginBottom: '1.5rem' }}>
            <StatCard
              icon={FileText}
              label={`Tests — ${{ all: 'Till Now', year: 'This Year', month: 'This Month' }[period]}`}
              value={
                period === 'all' ? stats?.total_tests
                  : period === 'year' ? stats?.tests_this_year
                    : stats?.tests_this_month
              }
              color="var(--brand-primary)" index={0}
            />
            <StatCard
              icon={Inbox}
              label={`Submissions — ${{ all: 'Till Now', year: 'This Year', month: 'This Month' }[period]}`}
              value={
                period === 'all' ? stats?.total_submissions
                  : period === 'year' ? stats?.submissions_this_year
                    : stats?.submissions_this_month
              }
              color="#10b981" index={1}
            />
          </motion.div>
        </>
      ) : (
        <motion.div initial="hidden" animate="visible" style={{ display: 'grid', gap: '1rem', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', marginBottom: '1.5rem' }}>
          <StatCard icon={FileText}       label="Total Tests"       value={stats?.total_tests}       color="var(--brand-primary)" index={0} />
          <StatCard icon={Inbox}          label="Total Submissions" value={stats?.total_submissions} color="#10b981" index={1} />
          <StatCard icon={AlertTriangle}  label="Total Violations"  value={stats?.total_violations}  color="#ef4444" index={2} />
        </motion.div>
      )}

      {!isAdmin && (
      <motion.div initial="hidden" animate="visible" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        {/* ── TESTS ── */}
        <Panel title="Tests" icon={FileText} count={tests.length} index={3}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', fontSize: '0.875rem' }}>
              <thead>
                <tr>
                  <th style={thStyle}>ID</th>
                  <th style={thStyle}>Title</th>
                  <th style={thStyle}>Access Code</th>
                  <th style={thStyle}>Questions</th>
                  <th style={thStyle}>Submissions</th>
                  <th style={thStyle}>Marks</th>
                  <th style={thStyle}>Schedule (start → end)</th>
                  <th style={thStyle}>Status</th>
                  <th style={thStyle}>Retake</th>
                  <th style={thStyle}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {tests.map(t => (
                  <tr key={t.id} style={rowHover}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                    <td style={{ ...tdStyle, color: 'var(--text-muted)', fontFamily: 'monospace', fontSize: '0.75rem' }}>{t.id}</td>
                    <td style={{ ...tdStyle, color: 'var(--text-primary)', fontWeight: 500 }}>{t.title}</td>
                    <td style={{ ...tdStyle, fontFamily: 'monospace', fontSize: '0.75rem', color: 'var(--brand-primary)', background: 'var(--brand-bg)', borderRadius: '0.25rem' }}>{t.access_code}</td>
                    <td style={{ ...tdStyle, color: 'var(--text-secondary)', fontFamily: 'monospace', fontSize: '0.75rem' }}>{t.question_count}</td>
                    <td style={{ ...tdStyle, color: 'var(--text-secondary)', fontFamily: 'monospace', fontSize: '0.75rem' }}>{t.submission_count}</td>
                    <td style={{ ...tdStyle, color: 'var(--text-secondary)', fontFamily: 'monospace', fontSize: '0.75rem' }}>{t.passing_marks}/{t.total_marks}</td>
                    <td style={tdStyle}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                        <input type="datetime-local"
                          defaultValue={toDatetimeLocalUtc(t.start_time)}
                          onBlur={e => {
                            if (e.target.value === toDatetimeLocalUtc(t.start_time)) return;
                            updateTest(t.id, { start_time: datetimeLocalToUtcIso(e.target.value) }, 'Start time updated');
                          }}
                          style={{ ...inputStyle, width: '11rem', color: 'var(--text-primary)' }}
                          title="Start date & time (saves when you leave the field)"
                        />
                        <input type="datetime-local"
                          defaultValue={toDatetimeLocalUtc(t.end_time)}
                          onBlur={e => {
                            if (e.target.value === toDatetimeLocalUtc(t.end_time)) return;
                            updateTest(t.id, { end_time: datetimeLocalToUtcIso(e.target.value) }, 'End time updated');
                          }}
                          style={{ ...inputStyle, width: '11rem', color: 'var(--text-primary)' }}
                          title="End date & time (saves when you leave the field)"
                        />
                      </div>
                    </td>
                    <td style={tdStyle}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                        <button title={t.is_active ? 'Active — click to deactivate' : 'Inactive — click to activate'}
                          onClick={() => updateTest(t.id, { is_active: !t.is_active }, t.is_active ? 'Test deactivated' : 'Test activated')}
                          style={{ fontSize: '0.75rem', fontWeight: 500, color: t.is_active ? 'var(--success-bg)' : 'var(--danger-bg)', transition: 'opacity 0.15s' }}
                          className="hover:opacity-80">
                          {t.is_active ? <ToggleRight size={18} /> : <ToggleLeft size={18} />}
                        </button>
                        <span style={{ fontSize: '0.7rem', fontWeight: 600, color: t.is_active ? 'var(--success-bg)' : 'var(--danger-bg)' }}>
                          {t.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </td>
                    <td style={tdStyle}>
                      <button title={t.allow_retake ? 'Retake allowed — click to disable' : 'Retake disabled — click to allow'}
                        onClick={() => updateTest(t.id, { allow_retake: !t.allow_retake }, t.allow_retake ? 'Retake disabled' : 'Retake allowed')}
                        style={{ fontSize: '0.75rem', fontWeight: 500, color: t.allow_retake ? 'var(--warning-bg)' : 'var(--text-muted)', transition: 'opacity 0.15s' }}
                        className="hover:opacity-80">
                        {t.allow_retake ? <ToggleRight size={18} /> : <ToggleLeft size={18} />}
                      </button>
                    </td>
                    <td style={tdStyle}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <button title="Questions" onClick={() => navigate(`/tests/${t.id}/manage`)}
                          style={{ color: 'var(--brand-primary)', transition: 'opacity 0.15s' }} className="hover:opacity-80">
                          <Eye size={14} />
                        </button>
                        <button title="Results" onClick={() => navigate(`/tests/${t.id}/results`)}
                          style={{ color: 'var(--text-secondary)', transition: 'opacity 0.15s' }} className="hover:opacity-80">
                          <BarChart2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {tests.length === 0 && (
              <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem', padding: '2rem 0' }}>No tests yet</p>
            )}
          </div>
        </Panel>

        {/* ── SUBMISSIONS ── */}
        <Panel title="Submissions" icon={Inbox} count={filteredSubs.length} index={4}>
          <div style={{ position: 'relative', padding: '0.75rem 1rem 0' }}>
            <Search size={14} style={{ position: 'absolute', left: '1.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', pointerEvents: 'none' }} />
            <input
              value={subSearch}
              onChange={e => setSubSearch(e.target.value)}
              placeholder="Search by student, email, test or ID…"
              style={{
                width: '100%',
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border-primary)',
                fontSize: '0.875rem',
                color: 'var(--text-primary)',
                borderRadius: '0.5rem',
                paddingLeft: '2rem',
                paddingRight: '0.75rem',
                paddingTop: '0.5rem',
                paddingBottom: '0.5rem',
                outline: 'none',
                boxSizing: 'border-box',
              }}
              className="focus:border-[var(--brand-primary)]"
              onFocus={e => e.target.style.borderColor = 'var(--brand-primary)'}
              onBlur={e => e.target.style.borderColor = 'var(--border-primary)'}
            />
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', fontSize: '0.875rem' }}>
              <thead>
                <tr>
                  <th style={thStyle}>ID</th>
                  <th style={thStyle}>Student</th>
                  <th style={thStyle}>Test</th>
                  <th style={thStyle}>Score</th>
                  <th style={thStyle}>Status</th>
                  <th style={thStyle}>Integrity</th>
                  <th style={thStyle}>Violations</th>
                  <th style={thStyle}>Submitted</th>
                  <th style={thStyle}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredSubs.map(s => (
                  <tr key={s.id} style={rowHover}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                    <td style={{ ...tdStyle, color: 'var(--text-muted)', fontFamily: 'monospace', fontSize: '0.75rem' }}>{s.id}</td>
                    <td style={{ ...tdStyle, color: 'var(--text-primary)' }}>
                      <div>{s.student_name}</div>
                      <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{s.student_email}</div>
                    </td>
                    <td style={{ ...tdStyle, color: 'var(--text-secondary)' }}>{s.test_title}</td>
                    <td style={{ ...tdStyle, color: 'var(--text-secondary)', fontFamily: 'monospace', fontSize: '0.75rem' }}>{s.score}/{s.max_score}</td>
                    <td style={tdStyle}>
                      <span style={{
                        fontSize: '0.7rem', fontWeight: 600, padding: '0.15rem 0.5rem', borderRadius: '9999px',
                        color: s.is_submitted ? 'var(--success-bg)' : 'var(--warning-bg)',
                        background: s.is_submitted
                          ? 'color-mix(in srgb, var(--success-bg) 15%, transparent)'
                          : 'color-mix(in srgb, var(--warning-bg) 15%, transparent)',
                        border: `1px solid ${s.is_submitted ? 'color-mix(in srgb, var(--success-bg) 35%, transparent)' : 'color-mix(in srgb, var(--warning-bg) 35%, transparent)'}`,
                      }}>{s.is_submitted ? 'Submitted' : 'In progress'}</span>
                    </td>
                    <td style={{ ...tdStyle, fontFamily: 'monospace', fontSize: '0.75rem', color: (s.integrity_score ?? 100) >= 80 ? 'var(--success-bg)' : (s.integrity_score ?? 100) >= 50 ? 'var(--warning-bg)' : 'var(--danger-bg)' }}>
                      {Math.round(s.integrity_score ?? 100)}
                    </td>
                    <td style={{ ...tdStyle, color: s.violations_count > 0 ? 'var(--danger-bg)' : 'var(--text-muted)', fontFamily: 'monospace', fontSize: '0.75rem' }}>
                      {s.violations_count}
                    </td>
                    <td style={{ ...tdStyle, color: 'var(--text-muted)', fontSize: '0.75rem' }}>{fmt(s.submitted_at)}</td>
                    <td style={tdStyle}>
                      <button title="View submission" onClick={() => navigate(`/tests/${s.test_id}/results/${s.id}`)}
                        style={{ color: 'var(--brand-primary)', transition: 'opacity 0.15s' }} className="hover:opacity-80">
                        <Eye size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredSubs.length === 0 && (
              <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem', padding: '2rem 0' }}>
                {subs.length === 0 ? 'No submissions yet' : 'No submissions match your search'}
              </p>
            )}
          </div>
        </Panel>
      </motion.div>
      )}
    </Layout>
  );
}
