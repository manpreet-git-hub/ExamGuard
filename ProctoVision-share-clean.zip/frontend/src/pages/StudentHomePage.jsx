import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { motion } from 'framer-motion';
import {
  LogOut, FileText, CheckCircle, XCircle,
  ChevronRight, Hash, Send, Loader2, BookOpen,
  User, TrendingUp, Shield, Sun, Moon, KeyRound
} from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { format } from 'date-fns';
import { parseApiDate } from '../utils/datetime';
import { useTheme } from '../contexts/ThemeContext';

const container = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.06 } } };
const item = { hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] } } };

function StatCard({ icon: Icon, label, value, color = 'brand' }) {
  const colors = {
    brand: { bg: 'var(--brand-bg)', text: 'var(--brand-primary)', border: 'var(--brand-border)' },
    green: { bg: 'var(--success-bg)', text: '#10b981', border: 'var(--success-border)' },
    amber: { bg: 'var(--warning-bg)', text: '#f59e0b', border: 'var(--warning-border)' },
    red:   { bg: 'var(--danger-bg)', text: '#ef4444', border: 'var(--danger-border)' },
  };
  const c = colors[color];
  return (
    <motion.div variants={item} className="card p-4 flex items-center gap-4">
      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
           style={{ background: c.bg, border: `1px solid ${c.border}` }}>
        <Icon size={20} style={{ color: c.text }} />
      </div>
      <div>
        <p className="text-xl font-display font-bold" style={{ color: 'var(--text-primary)' }}>{value}</p>
        <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{label}</p>
      </div>
    </motion.div>
  );
}

export default function StudentHomePage() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme, isDark } = useTheme();
  const navigate = useNavigate();
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading]         = useState(true);
  const [accessCode, setAccessCode]   = useState('');
  const [joining, setJoining]         = useState(false);

  useEffect(() => {
    api.get('/api/student/submissions')
      .then(r => setSubmissions(r.data))
      .catch(() => setSubmissions([]))
      .finally(() => setLoading(false));
  }, []);

  const handleJoinTest = async (e) => {
    e.preventDefault();
    if (!accessCode.trim()) return;
    setJoining(true);
    try {
      await api.get(`/api/tests/code/${accessCode.toUpperCase()}`);
      navigate(`/test/${accessCode.toUpperCase()}`);
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Test not found. Check the access code and try again.', { duration: 6000 });
    } finally { setJoining(false); }
  };

  const handleLogout = () => { logout(); navigate('/login'); };
  const passed   = submissions.filter(s => s.passed).length;
  const avgScore = submissions.length ? Math.round(submissions.reduce((s, x) => s + x.percentage, 0) / submissions.length) : 0;
  const avgIntegrity = submissions.length ? Math.round(submissions.reduce((s, x) => s + x.integrity_score, 0) / submissions.length) : 100;

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg-primary)' }}>
      <header className="px-4 lg:px-8 py-4 flex items-center gap-4 sticky top-0 z-30 backdrop-blur-md"
              style={{ background: 'color-mix(in srgb, var(--bg-secondary) 85%, transparent)', borderBottom: '1px solid var(--border-primary)' }}>
        <div className="flex items-center gap-3 flex-1">
          <img src="/logo.png" alt="ProctoVision" className="w-9 h-9 rounded-full flex-shrink-0" />
          <div>
            <p className="text-sm font-display font-bold" style={{ color: 'var(--text-primary)' }}>ProctoVision</p>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Student Portal</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg"
               style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-primary)' }}>
            <div className="w-6 h-6 rounded-full flex items-center justify-center"
                 style={{ background: 'linear-gradient(135deg, #06b6d4, #0891b2)' }}>
              <User size={12} className="text-white" />
            </div>
            <span className="text-sm" style={{ color: 'var(--text-primary)' }}>{user?.full_name}</span>
            <span className="badge-blue text-xs">Student</span>
          </div>
          <button onClick={toggleTheme} className="p-2 rounded-lg transition-all duration-200"
                  style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)', border: '1px solid var(--border-secondary)' }}>
            {isDark ? <Sun size={15} /> : <Moon size={15} />}
          </button>
          <button onClick={() => navigate('/change-password')} className="btn-secondary text-xs py-1.5"
                  title="Change your password">
            <KeyRound size={13} /> <span className="hidden sm:inline">Change Password</span>
          </button>
          <button onClick={handleLogout} className="btn-secondary text-xs py-1.5">
            <LogOut size={13} /> Logout
          </button>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <h1 className="text-display-md font-display" style={{ color: 'var(--text-primary)' }}>
            Welcome back, {user?.full_name?.split(' ')[0]}!
          </h1>
          <p className="mt-1" style={{ color: 'var(--text-muted)' }}>Enter an access code to start a test, or review your past results.</p>
        </motion.div>

        <motion.div variants={container} initial="hidden" animate="show" className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatCard icon={FileText}    label="Tests Taken"  value={submissions.length} color="brand" />
          <StatCard icon={CheckCircle} label="Passed"       value={passed}             color="green" />
          <StatCard icon={TrendingUp}  label="Avg Score"    value={`${avgScore}%`}     color="amber" />
          <StatCard icon={Shield}      label="Avg Integrity" value={avgIntegrity}
            color={avgIntegrity >= 80 ? 'green' : avgIntegrity >= 50 ? 'amber' : 'red'} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="card p-6">
          <h2 className="text-base font-display font-semibold mb-1 flex items-center gap-2"
              style={{ color: 'var(--text-primary)' }}>
            <Hash size={16} style={{ color: 'var(--brand-primary)' }} /> Enter Test Access Code
          </h2>
          <p className="text-sm mb-4" style={{ color: 'var(--text-muted)' }}>
            Get the access code from your teacher or exam invitation link.
          </p>
          <form onSubmit={handleJoinTest} className="flex gap-3">
            <input className="input flex-1 uppercase tracking-widest font-mono text-lg placeholder:normal-case placeholder:tracking-normal placeholder:font-sans"
              style={{ color: 'var(--brand-primary)' }}
              placeholder="e.g. ABC12345"
              value={accessCode} onChange={e => setAccessCode(e.target.value.toUpperCase())} maxLength={12} />
            <button type="submit" disabled={joining || !accessCode.trim()} className="btn-primary px-6 py-2.5">
              {joining ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
              {joining ? 'Checking…' : 'Join Test'}
            </button>
          </form>
        </motion.div>

        <div>
          <h2 className="text-base font-display font-semibold mb-4 flex items-center gap-2"
              style={{ color: 'var(--text-primary)' }}>
            <BookOpen size={16} style={{ color: 'var(--brand-primary)' }} /> Your Exam History
          </h2>

          {loading ? (
            <div className="card p-10 flex items-center justify-center">
              <div className="w-6 h-6 rounded-full border-2 border-cyan-500/20 border-t-cyan-500 animate-spin" />
            </div>
          ) : submissions.length === 0 ? (
            <div className="card p-12 text-center">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-4"
                   style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-primary)' }}>
                <FileText size={22} style={{ color: 'var(--text-muted)' }} />
              </div>
              <p className="font-medium" style={{ color: 'var(--text-secondary)' }}>No exams taken yet</p>
              <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>Enter an access code above to take your first exam.</p>
            </div>
          ) : (
            <motion.div variants={container} initial="hidden" animate="show" className="space-y-3">
              {submissions.map(sub => (
                <motion.div key={sub.id} variants={item}
                  className="card p-4 flex items-center gap-4 cursor-pointer hover:shadow-glow-sm transition-all duration-300"
                  onClick={() => navigate(`/student/result/${sub.id}`)}>
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0`}
                       style={{ background: sub.passed ? 'var(--success-bg)' : 'var(--danger-bg)' }}>
                    {sub.passed
                      ? <CheckCircle size={20} className="text-emerald-400" />
                      : <XCircle    size={20} className="text-red-400" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate" style={{ color: 'var(--text-primary)' }}>{sub.test_title || 'Exam'}</p>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
                      {sub.submitted_at ? format(parseApiDate(sub.submitted_at), 'dd MMM yyyy, HH:mm') : 'In progress'}
                    </p>
                  </div>
                  <div className="flex items-center gap-4 flex-shrink-0">
                    <div className="text-right hidden sm:block">
                      <p className="text-sm font-bold" style={{ color: 'var(--text-primary)' }}>{sub.score}/{sub.max_score}</p>
                      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{sub.percentage?.toFixed(1)}%</p>
                    </div>
                    <div className="text-right hidden md:block">
                      <p className={`text-sm font-bold ${sub.integrity_score >= 80 ? 'text-emerald-400' : sub.integrity_score >= 50 ? 'text-amber-400' : 'text-red-400'}`}>
                        {Math.round(sub.integrity_score)}
                      </p>
                      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Integrity</p>
                    </div>
                    <span className={`badge text-xs ${sub.risk_level === 'Low' ? 'badge-green' : sub.risk_level === 'Medium' ? 'badge-yellow' : 'badge-red'}`}>
                      {sub.risk_level}
                    </span>
                    <ChevronRight size={16} style={{ color: 'var(--text-muted)' }} />
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
