import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Plus, FileText, Users, BarChart2, Pencil, Trash2,
  Copy, Hash, Loader2, Activity, CheckCircle, Link2
} from 'lucide-react';
import toast from 'react-hot-toast';
import Layout from '../components/shared/Layout';
import CreateTestModal from '../components/teacher/CreateTestModal';
import api from '../utils/api';
import { copyToClipboard } from '../utils/clipboard';

const container = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.06 } } };
const item = { hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] } } };

function StatCard({ icon: Icon, label, value, color = 'brand', index = 0 }) {
  const colors = {
    brand: { bg: 'var(--brand-bg)', text: 'var(--brand-primary)', border: 'var(--brand-border)' },
    green: { bg: 'var(--success-bg)', text: '#10b981', border: 'var(--success-border)' },
    amber: { bg: 'var(--warning-bg)', text: '#f59e0b', border: 'var(--warning-border)' },
    red:   { bg: 'var(--danger-bg)', text: '#ef4444', border: 'var(--danger-border)' },
  };
  const c = colors[color];
  return (
    <motion.div variants={item} className="card p-5 group hover:shadow-glow-sm transition-all duration-300">
      <div className="flex items-start gap-4">
        <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 transition-transform duration-300 group-hover:scale-110"
             style={{ background: c.bg, border: `1px solid ${c.border}` }}>
          <Icon size={20} style={{ color: c.text }} />
        </div>
        <div>
          <motion.p initial={{ opacity: 0, scale: 0.5 }} animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 + index * 0.1, type: 'spring', stiffness: 200 }}
            className="text-2xl font-display font-bold" style={{ color: 'var(--text-primary)' }}>
            {value}
          </motion.p>
          <p className="text-sm mt-0.5" style={{ color: 'var(--text-muted)' }}>{label}</p>
        </div>
      </div>
    </motion.div>
  );
}

function TestCard({ test, onRefresh }) {
  const navigate = useNavigate();
  const [deleting, setDeleting] = useState(false);

  const copyCode = async (e) => {
    e.stopPropagation();
    const ok = await copyToClipboard(test.access_code);
    if (ok) toast.success('Access code copied!');
    else toast.error('Could not copy — please select the code and copy manually.');
  };

  const copyLink = async (e) => {
    e.stopPropagation();
    const ok = await copyToClipboard(`${window.location.origin}/test/${test.access_code}`);
    if (ok) toast.success('Test link copied!');
    else toast.error('Could not copy the test link.');
  };

  const handleDelete = async (e) => {
    e.stopPropagation();
    if (!confirm(`Delete "${test.title}"? This cannot be undone.`)) return;
    setDeleting(true);
    try { await api.delete(`/api/tests/${test.id}`); toast.success('Test deleted'); onRefresh(); }
    catch { toast.error('Failed to delete test'); }
    finally { setDeleting(false); }
  };

  return (
    <motion.div variants={item}
      className="card p-5 group cursor-pointer hover:shadow-glow-sm transition-all duration-300"
      onClick={() => navigate(`/tests/${test.id}/manage`)}>
      <div className="flex items-start justify-between gap-3 mb-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            {test.is_active
              ? <span className="badge-green"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" /> Live</span>
              : <span className="badge-gray">Inactive</span>}
          </div>
          <h3 className="font-display font-semibold truncate" style={{ color: 'var(--text-primary)' }}>{test.title}</h3>
          {test.description && <p className="text-sm truncate mt-0.5" style={{ color: 'var(--text-muted)' }}>{test.description}</p>}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 mb-4">
        {[
          { label: 'Questions',   value: test.question_count  },
          { label: 'Submissions', value: test.submission_count },
          { label: 'Duration',    value: `${test.duration_mins} min` },
          { label: 'Total Marks', value: test.total_marks },
        ].map((s, i) => (
          <div key={i} className="rounded-lg p-2.5" style={{ background: 'var(--bg-tertiary)' }}>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{s.label}</p>
            <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{s.value}</p>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-2 p-2 rounded-lg mb-4"
           style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-primary)' }}>
        <Hash size={13} style={{ color: 'var(--text-muted)' }} className="flex-shrink-0" />
        <code className="text-xs font-mono flex-1 tracking-widest" style={{ color: 'var(--brand-primary)' }}>{test.access_code}</code>
        <button onClick={copyCode} className="transition-colors flex-shrink-0"
                style={{ color: 'var(--text-muted)' }}
                onMouseEnter={e => e.currentTarget.style.color = 'var(--brand-primary)'}
                onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
                title="Copy access code">
          <Copy size={13} />
        </button>
      </div>

      <div className="flex items-center gap-2">
        <button onClick={(e) => { e.stopPropagation(); navigate(`/tests/${test.id}/manage`); }}
          className="btn-secondary flex-1 justify-center text-xs py-2">
          <Pencil size={13} /> Edit
        </button>
        <button onClick={(e) => { e.stopPropagation(); navigate(`/tests/${test.id}/results`); }}
          className="btn-secondary flex-1 justify-center text-xs py-2">
          <BarChart2 size={13} /> Results
        </button>
        <button onClick={(e) => { e.stopPropagation(); navigate(`/tests/${test.id}/monitor`); }}
          className="btn-secondary px-2 py-2" title="Live Monitor">
          <Activity size={14} className="text-emerald-400" />
        </button>
        <button onClick={copyLink} className="btn-secondary px-2 py-2" title="Copy test link">
          <Link2 size={14} />
        </button>
        <button onClick={handleDelete} disabled={deleting}
          className="btn-secondary px-2 py-2 transition-colors"
          style={{ color: 'var(--text-tertiary)' }}
          onMouseEnter={e => e.currentTarget.style.color = '#ef4444'}
          onMouseLeave={e => e.currentTarget.style.color = 'var(--text-tertiary)'}
          title="Delete">
          {deleting ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
        </button>
      </div>
    </motion.div>
  );
}

export default function DashboardPage() {
  const [tests, setTests]           = useState([]);
  const [loading, setLoading]       = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const navigate = useNavigate();

  const fetchTests = async () => {
    try { const r = await api.get('/api/tests/'); setTests(r.data); }
    catch { toast.error('Failed to load tests'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchTests(); }, []);

  const stats = {
    total:       tests.length,
    active:      tests.filter(t => t.is_active).length,
    submissions: tests.reduce((s, t) => s + (t.submission_count || 0), 0),
    questions:   tests.reduce((s, t) => s + (t.question_count  || 0), 0),
  };

  return (
    <Layout title="Dashboard">
      <motion.div variants={container} initial="hidden" animate="show">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard icon={FileText}    label="Total Tests"       value={stats.total}       color="brand" index={0} />
          <StatCard icon={CheckCircle} label="Active Tests"      value={stats.active}      color="green" index={1} />
          <StatCard icon={Users}       label="Total Submissions" value={stats.submissions} color="amber" index={2} />
          <StatCard icon={Hash}        label="Total Questions"   value={stats.questions}   color="brand" index={3} />
        </div>

        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-display font-semibold" style={{ color: 'var(--text-primary)' }}>Your Tests</h2>
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>{tests.length} test{tests.length !== 1 ? 's' : ''} created</p>
          </div>
          <button onClick={() => setShowCreate(true)} className="btn-primary">
            <Plus size={16} /> New Test
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-48">
            <div className="w-8 h-8 rounded-full border-2 border-cyan-500/20 border-t-cyan-500 animate-spin" />
          </div>
        ) : tests.length === 0 ? (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="card p-12 text-center">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4"
                 style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-primary)' }}>
              <FileText size={24} style={{ color: 'var(--text-muted)' }} />
            </div>
            <p className="font-medium" style={{ color: 'var(--text-secondary)' }}>No tests yet</p>
            <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>Create your first test to get started</p>
            <button onClick={() => setShowCreate(true)} className="btn-primary mt-4 mx-auto">
              <Plus size={16} /> Create Test
            </button>
          </motion.div>
        ) : (
          <motion.div variants={container} initial="hidden" animate="show"
            className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {tests.map(t => <TestCard key={t.id} test={t} onRefresh={fetchTests} />)}
          </motion.div>
        )}
      </motion.div>

      {showCreate && (
        <CreateTestModal
          onClose={() => setShowCreate(false)}
          onCreated={(test) => { setShowCreate(false); fetchTests(); navigate(`/tests/${test.id}/manage`); }}
        />
      )}
    </Layout>
  );
}
