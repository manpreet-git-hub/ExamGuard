// src/pages/ChangePasswordPage.jsx
// Set a new password — shown automatically after logging in with a default /
// system-generated password, and available any time from the sidebar.
import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { motion } from 'framer-motion';
import { KeyRound, Eye, EyeOff, Loader2, Sun, Moon, LogOut, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ChangePasswordPage() {
  const { user, loading, changePassword, logout } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();

  const [form, setForm] = useState({ current: '', next: '', confirm: '' });
  const [show, setShow]       = useState(false);
  const [busy, setBusy]       = useState(false);
  const forced = !!user?.must_change_password;
  // Where to send the user back to — the exam they were joining, or their home.
  const backTo = location.state?.from || (user?.role === 'student' ? '/student' : '/');
  const showBack = !forced || !!location.state?.from;

  if (loading) return null;
  if (!user) { navigate('/login', { replace: true }); return null; }

  const set = (k) => (e) => setForm(p => ({ ...p, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    if (form.next.length < 8) { toast.error('New password must be at least 8 characters'); return; }
    if (form.next !== form.confirm) { toast.error('New passwords do not match'); return; }
    if (form.next === form.current) { toast.error('New password must be different from the current one'); return; }
    setBusy(true);
    try {
      await changePassword(form.current, form.next);
      toast.success('Password updated');
      // Send the student straight back to the exam they were joining.
      const back = location.state?.from;
      navigate(back || (user.role === 'student' ? '/student' : '/'), { replace: true });
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Could not update password', { duration: 6000 });
    } finally { setBusy(false); }
  };

  const field = {
    width: '100%', padding: '0.6rem 0.85rem', fontSize: '0.9rem',
    background: 'var(--bg-tertiary)', color: 'var(--text-primary)',
    border: '1px solid var(--border-secondary)', borderRadius: '0.5rem',
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'var(--bg-primary)' }}>
      {showBack && (
        <button onClick={() => navigate(backTo)}
          className="fixed top-4 left-4 z-50 flex items-center gap-1.5 p-2.5 pr-3 rounded-xl transition-all duration-200"
          style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)', border: '1px solid var(--border-secondary)' }}
          title="Go back">
          <ArrowLeft size={16} /> <span className="text-sm">Back</span>
        </button>
      )}
      <button onClick={toggleTheme} title="Toggle theme"
        className="fixed top-4 right-4 p-2.5 rounded-xl z-50"
        style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)', border: '1px solid var(--border-secondary)' }}>
        {isDark ? <Sun size={16} /> : <Moon size={16} />}
      </button>

      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md card p-6 space-y-5" style={{ borderColor: 'var(--brand-border)' }}>

        <div className="text-center space-y-2">
          <div className="mx-auto w-12 h-12 rounded-xl flex items-center justify-center"
               style={{ background: 'var(--brand-bg)', border: '1px solid var(--brand-border)' }}>
            <KeyRound size={22} style={{ color: 'var(--brand-primary)' }} />
          </div>
          <h1 className="text-lg font-display font-semibold" style={{ color: 'var(--text-primary)' }}>
            {forced ? 'Set Your Own Password' : 'Change Password'}
          </h1>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
            {forced
              ? <>You're signed in with a default password issued by your college. Choose your own before continuing.</>
              : <>Update the password for <b>{user.email}</b>.</>}
          </p>
          {showBack && location.state?.from?.startsWith('/test/') && (
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
              You'll be sent straight back to your exam after saving.
            </p>
          )}
        </div>

        <form onSubmit={submit} className="space-y-3">
          <div>
            <label className="block text-xs font-medium mb-1" style={{ color: 'var(--text-secondary)' }}>
              Current password {forced && <span style={{ color: 'var(--text-muted)' }}>(the default one you logged in with)</span>}
            </label>
            <div className="relative">
              <input type={show ? 'text' : 'password'} required value={form.current} onChange={set('current')}
                autoComplete="current-password" style={{ ...field, paddingRight: '2.5rem' }} />
              <button type="button" onClick={() => setShow(s => !s)}
                className="absolute right-2 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }}>
                {show ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium mb-1" style={{ color: 'var(--text-secondary)' }}>New password</label>
            <input type={show ? 'text' : 'password'} required value={form.next} onChange={set('next')}
              autoComplete="new-password" minLength={8} style={field}
              placeholder="At least 8 characters" />
          </div>

          <div>
            <label className="block text-xs font-medium mb-1" style={{ color: 'var(--text-secondary)' }}>Confirm new password</label>
            <input type={show ? 'text' : 'password'} required value={form.confirm} onChange={set('confirm')}
              autoComplete="new-password" minLength={8} style={field} />
          </div>

          <button type="submit" disabled={busy} className="btn-primary w-full"
            style={{ opacity: busy ? 0.7 : 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
            {busy && <Loader2 size={15} className="animate-spin" />}
            {busy ? 'Saving…' : 'Update password'}
          </button>
        </form>

        {!forced && (
          <button onClick={() => { logout(); navigate('/login'); }} className="w-full text-xs flex items-center justify-center gap-1.5"
            style={{ color: 'var(--text-muted)' }}>
            <LogOut size={13} /> Sign out instead
          </button>
        )}
      </motion.div>
    </div>
  );
}
