import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Plus, Pencil, Trash2, GripVertical, Loader2,
  CheckSquare, AlignLeft, Code, CircleDot,
  Copy, BarChart2, Save, X, Activity, Upload, Download, FileSpreadsheet, Link2,
  Users, Send, RefreshCw, ShieldCheck, ArrowLeft
} from 'lucide-react';
import toast from 'react-hot-toast';
import Layout from '../components/shared/Layout';
import api from '../utils/api';
import { copyToClipboard } from '../utils/clipboard';

const container = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.04 } } };
const item = { hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } };

const Q_TYPES = [
  { value: 'mcq',              label: 'MCQ',          icon: CircleDot  },
  { value: 'multiple_correct', label: 'Multi-Select', icon: CheckSquare },
  { value: 'short_answer',     label: 'Short Answer', icon: AlignLeft  },
  { value: 'coding',           label: 'Coding',       icon: Code       },
];

const EMPTY = { question_text: '', question_type: 'mcq', options: ['', '', '', ''], correct_answer: null, marks: 1, explanation: '' };

const CSV_TEMPLATE = `question_text,question_type,options,correct_answer,marks,explanation
"What is 2+2?",mcq,"2|3|4|5",4,1,"Basic addition"
"Select all prime numbers",multiple_correct,"2|3|4|5|6","2|3|5",2,"Primes are only divisible by 1 and themselves"
"What is photosynthesis?",short_answer,,The process by which plants convert light into energy,3,`;

function CsvImportModal({ testId, onImported, onClose }) {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [results, setResults] = useState(null);

  const downloadTemplate = () => {
    const blob = new Blob([CSV_TEMPLATE], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'question_template.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const handleUpload = async () => {
    if (!file) { toast.error('Please select a CSV file'); return; }
    setUploading(true);
    setResults(null);
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await api.post(`/api/questions/bulk-import/${testId}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setResults(res.data);
      if (res.data.imported > 0) {
        toast.success(`Imported ${res.data.imported} question${res.data.imported !== 1 ? 's' : ''}`);
        onImported();
      }
      if (res.data.total_errors > 0 && res.data.imported === 0) {
        toast.error(`All rows failed. Check errors below.`);
      } else if (res.data.total_errors > 0) {
        toast.error(`${res.data.total_errors} row(s) had errors`);
      }
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Import failed');
    } finally { setUploading(false); }
  };

  return (
    <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
      className="card p-5 space-y-4" style={{ borderColor: 'var(--brand-border)' }}>
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-display font-semibold flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
          <FileSpreadsheet size={16} /> Import Questions from CSV
        </h3>
        <button type="button" onClick={onClose} style={{ color: 'var(--text-muted)' }}><X size={16} /></button>
      </div>

      <div className="rounded-lg p-3 text-xs space-y-1" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-tertiary)' }}>
        <p className="font-medium" style={{ color: 'var(--text-secondary)' }}>CSV Format Requirements:</p>
        <ul className="list-disc list-inside space-y-0.5 ml-1">
          <li><b>question_text</b> (required) - The question</li>
          <li><b>question_type</b> (required) - mcq, multiple_correct, short_answer, or coding</li>
          <li><b>correct_answer</b> (required) - Single answer for MCQ, pipe-separated for multi-select</li>
          <li><b>options</b> - Pipe-separated choices, e.g. "A|B|C|D" (required for MCQ)</li>
          <li><b>marks</b> - Points per question (default: 1)</li>
          <li><b>explanation</b> - Optional explanation text</li>
        </ul>
      </div>

      <div className="flex items-center gap-3">
        <button type="button" onClick={downloadTemplate} className="btn-secondary text-xs">
          <Download size={13} /> Download Template
        </button>
        <label className="btn-secondary text-xs cursor-pointer">
          <Upload size={13} /> {file ? file.name : 'Choose CSV File'}
          <input type="file" accept=".csv" className="hidden" onChange={e => setFile(e.target.files[0])} />
        </label>
      </div>

      {results && (
        <div className="rounded-lg p-3 text-xs space-y-1" style={{ background: 'var(--bg-tertiary)' }}>
          <p style={{ color: 'var(--text-secondary)' }}>
            <span className="font-semibold">{results.imported}</span> question{results.imported !== 1 ? 's' : ''} imported
            {results.total_errors > 0 && <span className="ml-2" style={{ color: '#ef4444' }}>({results.total_errors} error{results.total_errors !== 1 ? 's' : ''})</span>}
          </p>
          {results.errors.length > 0 && (
            <ul className="mt-1 space-y-0.5" style={{ color: '#ef4444' }}>
              {results.errors.map((err, i) => <li key={i}>{err}</li>)}
            </ul>
          )}
        </div>
      )}

      <div className="flex gap-3 pt-1">
        <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
        <button type="button" onClick={handleUpload} disabled={!file || uploading} className="btn-primary">
          {uploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
          {uploading ? 'Importing…' : 'Import Questions'}
        </button>
      </div>
    </motion.div>
  );
}

const ROSTER_TEMPLATE = `roll_no
21CS1001
21CS1002
21CS1003`;

const PWD_BADGE = {
  none:    { label: 'No password', cls: 'text-gray-500 bg-gray-500/10' },
  pending: { label: 'Sending…',    cls: 'text-amber-400 bg-amber-500/10' },
  sent:    { label: 'Emailed',     cls: 'text-emerald-400 bg-emerald-500/10' },
  failed:  { label: 'Email failed', cls: 'text-red-400 bg-red-500/10' },
};

function RosterPanel({ testId, onClose }) {
  const [participants, setParticipants] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [file, setFile]           = useState(null);
  const [busy, setBusy]           = useState(false);
  const [rollText, setRollText]   = useState('');
  const [result, setResult]       = useState(null);
  const [selected, setSelected]  = useState(() => new Set());

  const load = async () => {
    try {
      const res = await api.get(`/api/tests/${testId}/participants`);
      setParticipants(res.data);
      setSelected(prev => new Set([...prev].filter(id => res.data.some(p => p.user_id === id))));
    } catch { toast.error('Failed to load student list'); }
    finally { setLoading(false); }
  };

  const toggleSel = (id) => setSelected(prev => {
    const next = new Set(prev);
    next.has(id) ? next.delete(id) : next.add(id);
    return next;
  });
  const allSelected = participants.length > 0 && selected.size === participants.length;
  const toggleAll = () => setSelected(allSelected ? new Set() : new Set(participants.map(p => p.user_id)));
  const selCount = selected.size;
  useEffect(() => { load(); }, [testId]);

  const downloadTemplate = () => {
    const blob = new Blob([ROSTER_TEMPLATE], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'roll_numbers.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const showResult = (r) => {
    setResult(r);
    if (r.added > 0) toast.success(`${r.added} student${r.added !== 1 ? 's' : ''} added`);
    if (r.errors?.length) toast.error(`${r.errors.length} roll number(s) not found`);
    if (r.duplicates > 0) toast(`${r.duplicates} already in the list`, { icon: 'ℹ️' });
    load();
  };

  const handleUpload = async () => {
    if (!file) { toast.error('Choose a CSV file first'); return; }
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await api.post(`/api/tests/${testId}/participants/upload`, fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      showResult(res.data);
      setFile(null);
    } catch (err) { toast.error(err.response?.data?.detail || 'Upload failed'); }
    finally { setBusy(false); }
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!rollText.trim()) return;
    setBusy(true);
    try {
      const res = await api.post(`/api/tests/${testId}/participants`, {
        roll_nos: rollText.split(/[\n,;]+/),
      });
      showResult(res.data);
      setRollText('');
    } catch (err) { toast.error(err.response?.data?.detail || 'Could not add students'); }
    finally { setBusy(false); }
  };

  const handleSend = async (resend) => {
    setBusy(true);
    try {
      const res = await api.post(`/api/tests/${testId}/participants/send-passwords`, {
        resend,
        user_ids: selCount ? [...selected] : null,
      });
      toast.success(res.data.detail, { duration: 6000 });
      setResult(null);
      setTimeout(load, 2500);
      setTimeout(load, 6000);
    } catch (err) { toast.error(err.response?.data?.detail || 'Could not send passwords', { duration: 7000 }); }
    finally { setBusy(false); }
  };

  const handleRemove = async () => {
    if (!selCount) { toast.error('Tick the students you want to remove'); return; }
    if (!confirm(`Remove ${selCount} ticked student(s) from this list? Their exam passwords are deleted too.`)) return;
    setBusy(true);
    try {
      const res = await api.post(`/api/tests/${testId}/participants/remove`, { user_ids: [...selected] });
      toast.success(res.data.detail, { duration: 6000 });
      setSelected(new Set()); setResult(null);
      load();
    } catch (err) { toast.error(err.response?.data?.detail || 'Failed to remove students'); }
    finally { setBusy(false); }
  };

  const handleClear = async () => {
    if (!confirm('Remove ALL students from the list? The test will reopen to every student.')) return;
    setBusy(true);
    try {
      await api.delete(`/api/tests/${testId}/participants`);
      toast.success('Student list cleared');
      setParticipants([]); setSelected(new Set()); setResult(null);
    } catch (err) { toast.error(err.response?.data?.detail || 'Failed to clear'); }
    finally { setBusy(false); }
  };

  const sentCount = participants.filter(p => p.password_status === 'sent').length;

  return (
    <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
      className="card p-5 space-y-4 mb-6" style={{ borderColor: 'var(--brand-border)' }}>
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-display font-semibold flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
          <Users size={16} /> Students Allowed to Attempt
          <span className="badge-blue">{participants.length} on list</span>
        </h3>
        <button type="button" onClick={onClose} style={{ color: 'var(--text-muted)' }}><X size={16} /></button>
      </div>

      <div className="rounded-lg p-3 text-xs space-y-1" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-tertiary)' }}>
        <p style={{ color: 'var(--text-secondary)' }} className="font-medium">How it works</p>
        <ul className="list-disc list-inside space-y-0.5 ml-1">
          <li>Upload a CSV of roll numbers (one per line) — only these students can attempt the test.</li>
          <li>Send passwords → each student gets a <b>unique password</b> in their own registered email.</li>
          <li>Student must log in, enter the access code, then their own password.</li>
          <li>Leave the list empty and the test stays open to every student.</li>
        </ul>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button type="button" onClick={downloadTemplate} className="btn-secondary text-xs">
          <Download size={13} /> CSV Template
        </button>
        <label className="btn-secondary text-xs cursor-pointer">
          <Upload size={13} /> {file ? file.name : 'Choose CSV'}
          <input type="file" accept=".csv,text/csv" className="hidden"
            onChange={e => setFile(e.target.files[0])} />
        </label>
        <button type="button" onClick={handleUpload} disabled={!file || busy} className="btn-primary text-xs">
          {busy && !file ? <Loader2 size={13} className="animate-spin" /> : <Upload size={13} />} Upload List
        </button>
      </div>

      <form onSubmit={handleAdd} className="flex gap-2">
        <input className="input flex-1 text-sm" placeholder="Or type roll numbers: 21CS1001, 21CS1002 …"
          value={rollText} onChange={e => setRollText(e.target.value)} />
        <button type="submit" disabled={busy || !rollText.trim()} className="btn-secondary text-xs whitespace-nowrap">
          <Plus size={13} /> Add
        </button>
      </form>

      {result && (result.errors?.length > 0) && (
        <div className="rounded-lg p-3 text-xs space-y-0.5" style={{ background: 'rgba(239,68,68,0.08)', color: '#ef4444' }}>
          {result.errors.map((e, i) => <p key={i}>{e}</p>)}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-4"><Loader2 size={18} className="animate-spin" style={{ color: 'var(--text-muted)' }} /></div>
      ) : participants.length === 0 ? (
        <p className="text-xs text-center py-3" style={{ color: 'var(--text-muted)' }}>
          No students selected — this test is currently open to everyone.
        </p>
      ) : (
        <div className="rounded-lg overflow-hidden border" style={{ borderColor: 'var(--border-primary)' }}>
          <label className="flex items-center gap-2 px-3 py-2 text-xs cursor-pointer border-b"
            style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)', borderColor: 'var(--border-primary)' }}>
            <input type="checkbox" checked={allSelected} onChange={toggleAll} className="w-3.5 h-3.5 cursor-pointer"
              style={{ accentColor: 'var(--brand-primary)' }} />
            {selCount ? `Ticked ${selCount} of ${participants.length} — actions apply to these only`
                      : 'None ticked — actions apply to all students'}
          </label>
          <div className="max-h-64 overflow-y-auto divide-y" style={{ borderColor: 'var(--border-primary)' }}>
            {participants.map(p => {
              const b = PWD_BADGE[p.password_status] || PWD_BADGE.none;
              const isSel = selected.has(p.user_id);
              return (
                <div key={p.id} className="flex items-center gap-3 px-3 py-2 text-xs"
                  style={{ background: isSel ? 'rgba(59,130,246,0.08)' : undefined }}>
                  <input type="checkbox" checked={isSel} onChange={() => toggleSel(p.user_id)}
                    className="w-3.5 h-3.5 flex-shrink-0 cursor-pointer" style={{ accentColor: 'var(--brand-primary)' }}
                    aria-label={`Tick ${p.full_name || p.roll_no}`} />
                  <span className="font-mono w-24 flex-shrink-0" style={{ color: 'var(--brand-primary)' }}>{p.roll_no || '—'}</span>
                  <span className="flex-1 truncate" style={{ color: 'var(--text-primary)' }}>{p.full_name}</span>
                  <span className="hidden sm:inline truncate w-40" style={{ color: 'var(--text-muted)' }}>{p.email}</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${b.cls}`}>{b.label}</span>
                  {p.password_used && <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400">attempted</span>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="flex flex-wrap gap-2 pt-1">
        <button type="button" onClick={() => handleSend(false)} disabled={busy || participants.length === 0}
          className="btn-primary text-xs">
          <Send size={13} /> {selCount ? `Email ${selCount} Ticked` : 'Email Passwords'}{!selCount && sentCount > 0 ? ` (${sentCount} sent)` : ''}
        </button>
        <button type="button" onClick={() => handleSend(true)} disabled={busy || participants.length === 0}
          className="btn-secondary text-xs">
          <RefreshCw size={13} /> {selCount ? `Regenerate & Resend ${selCount} Ticked` : 'Regenerate & Resend All'}
        </button>
        <button type="button" onClick={handleRemove} disabled={busy || selCount === 0}
          className="btn-secondary text-xs" style={{ color: '#f59e0b' }}>
          <Trash2 size={13} /> Remove Ticked{selCount > 0 ? ` (${selCount})` : ''}
        </button>
        <button type="button" onClick={handleClear} disabled={busy || participants.length === 0}
          className="btn-secondary text-xs" style={{ color: '#ef4444' }}>
          <X size={13} /> Clear List
        </button>
      </div>
      <p className="text-[11px] flex items-center gap-1.5" style={{ color: 'var(--text-muted)' }}>
        <ShieldCheck size={12} className="text-emerald-400" />
        Passwords are unique per student, stored only as a hash, and expire when the test ends.
      </p>
    </motion.div>
  );
}


function QuestionForm({ testId, initial, onSaved, onCancel }) {
  const [form, setForm] = useState(initial ? { ...initial, options: initial.options || ['', '', '', ''], correct_answer: initial.correct_answer || null } : { ...EMPTY });
  const [loading, setLoading] = useState(false);
  const isEdit = !!initial?.id;

  const setField = (k, v) => setForm(p => ({ ...p, [k]: v }));
  const setOption = (i, v) => {
    const opts = [...(form.options || [])];
    const previous = opts[i];
    opts[i] = v;
    setForm(prev => {
      let nextCorrect = prev.correct_answer;
      if (prev.question_type === 'mcq' && prev.correct_answer === previous) nextCorrect = v;
      if (prev.question_type === 'multiple_correct' && Array.isArray(prev.correct_answer))
        nextCorrect = prev.correct_answer.map(item => item === previous ? v : item);
      return { ...prev, options: opts, correct_answer: nextCorrect };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.question_text.trim()) { toast.error('Question text is required'); return; }
    setLoading(true);
    try {
      const payload = {
        question_text: form.question_text, question_type: form.question_type,
        marks: +form.marks || 1, explanation: form.explanation || '',
        correct_answer: form.correct_answer,
        options: ['mcq','multiple_correct'].includes(form.question_type) ? (form.options || []).filter(o => o.trim()) : null,
      };
      const result = isEdit ? await api.put(`/api/questions/${initial.id}`, payload) : await api.post('/api/questions/', { ...payload, test_id: testId });
      toast.success(isEdit ? 'Question updated!' : 'Question added!');
      onSaved(result.data);
    } catch (err) { toast.error(err.response?.data?.detail || 'Failed to save question'); }
    finally { setLoading(false); }
  };

  const needsOptions = ['mcq', 'multiple_correct'].includes(form.question_type);

  return (
    <motion.form initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
      onSubmit={handleSubmit} className="card p-5 space-y-4" style={{ borderColor: 'var(--brand-border)' }}>
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-display font-semibold" style={{ color: 'var(--text-primary)' }}>{isEdit ? 'Edit Question' : 'Add New Question'}</h3>
        <button type="button" onClick={onCancel} style={{ color: 'var(--text-muted)' }}><X size={16} /></button>
      </div>
      <div>
        <label className="label">Question Type</label>
        <div className="grid grid-cols-4 gap-2">
          {Q_TYPES.map(({ value, label, icon: Icon }) => (
            <button key={value} type="button" onClick={() => setField('question_type', value)}
              className="flex flex-col items-center gap-1.5 p-2.5 rounded-lg text-xs font-medium transition-all duration-200"
              style={{
                border: `1px solid ${form.question_type === value ? 'var(--brand-primary)' : 'var(--border-secondary)'}`,
                background: form.question_type === value ? 'var(--brand-bg)' : 'var(--bg-tertiary)',
                color: form.question_type === value ? 'var(--brand-primary)' : 'var(--text-tertiary)',
              }}>
              <Icon size={16} />{label}
            </button>
          ))}
        </div>
      </div>
      <div>
        <label className="label">Question Text *</label>
        <textarea className="input resize-none" rows={3} placeholder="Type your question here…"
          value={form.question_text} onChange={e => setField('question_text', e.target.value)} required />
      </div>
      {needsOptions && (
        <div>
          <label className="label">
            Answer Options
            <span className="font-normal ml-2" style={{ color: 'var(--text-muted)' }}>
              ({form.question_type === 'mcq' ? 'select one correct' : 'check all correct'})
            </span>
          </label>
          <div className="space-y-2">
            {(form.options || []).map((opt, i) => (
              <div key={i} className="flex items-center gap-2">
                {form.question_type === 'mcq' ? (
                  <input type="radio" name="correct" checked={form.correct_answer === opt && opt.trim() !== ''}
                    onChange={() => setField('correct_answer', opt)} className="flex-shrink-0" style={{ accentColor: 'var(--brand-primary)' }} />
                ) : (
                  <input type="checkbox"
                    checked={Array.isArray(form.correct_answer) && form.correct_answer.includes(opt)}
                    onChange={e => {
                      const cur = Array.isArray(form.correct_answer) ? form.correct_answer : [];
                      setField('correct_answer', e.target.checked ? [...cur, opt] : cur.filter(c => c !== opt));
                    }}
                    className="flex-shrink-0" style={{ accentColor: 'var(--brand-primary)' }} />
                )}
                <span className="text-xs w-5 flex-shrink-0" style={{ color: 'var(--text-muted)' }}>{String.fromCharCode(65 + i)}.</span>
                <input className="input flex-1 py-2" placeholder={`Option ${String.fromCharCode(65 + i)}`}
                  value={opt} onChange={e => setOption(i, e.target.value)} />
                {(form.options || []).length > 2 && (
                  <button type="button" onClick={() => {
                    const removed = (form.options || [])[i];
                    const opts = (form.options || []).filter((_, idx) => idx !== i);
                    setForm(prev => {
                      let nextCorrect = prev.correct_answer;
                      if (prev.question_type === 'mcq' && prev.correct_answer === removed) nextCorrect = null;
                      if (prev.question_type === 'multiple_correct' && Array.isArray(prev.correct_answer))
                        nextCorrect = prev.correct_answer.filter(item => item !== removed);
                      return { ...prev, options: opts, correct_answer: nextCorrect };
                    });
                  }} style={{ color: 'var(--text-muted)' }}><X size={14} /></button>
                )}
              </div>
            ))}
            <button type="button" onClick={() => setField('options', [...(form.options || []), ''])}
              className="text-xs flex items-center gap-1 mt-1" style={{ color: 'var(--brand-primary)' }}>
              <Plus size={13} /> Add option
            </button>
          </div>
        </div>
      )}
      {['short_answer', 'coding'].includes(form.question_type) && (
        <div>
          <label className="label">Model Answer (optional)</label>
          <textarea className="input resize-none" rows={2} placeholder="Expected answer…"
            value={form.correct_answer || ''} onChange={e => setField('correct_answer', e.target.value)} />
        </div>
      )}
      <div className="flex items-end gap-3">
        <div className="w-24">
          <label className="label">Marks</label>
          <input className="input" type="number" min={1} value={form.marks} onChange={e => setField('marks', e.target.value)} />
        </div>
        <div className="flex-1">
          <label className="label">Explanation (optional)</label>
          <input className="input" placeholder="Why is this the correct answer?" value={form.explanation || ''}
            onChange={e => setField('explanation', e.target.value)} />
        </div>
      </div>
      <div className="flex gap-3 pt-1">
        <button type="button" onClick={onCancel} className="btn-secondary">Cancel</button>
        <button type="submit" disabled={loading} className="btn-primary">
          {loading ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
          {loading ? 'Saving…' : (isEdit ? 'Update Question' : 'Add Question')}
        </button>
      </div>
    </motion.form>
  );
}

function QuestionCard({ question, index, onEdit, onDelete }) {
  const [deleting, setDeleting] = useState(false);
  const typeInfo = Q_TYPES.find(t => t.value === question.question_type) || Q_TYPES[0];
  const Icon = typeInfo.icon;

  const handleDelete = async () => {
    if (!confirm('Delete this question?')) return;
    setDeleting(true);
    try { await api.delete(`/api/questions/${question.id}`); toast.success('Deleted'); onDelete(question.id); }
    catch { toast.error('Failed to delete'); }
    finally { setDeleting(false); }
  };

  return (
    <motion.div variants={item}
      className="card p-4 group transition-all duration-200"
      onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--border-secondary)'}
      onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border-primary)'}>
      <div className="flex items-start gap-3">
        <div className="flex items-center gap-2 flex-shrink-0 mt-0.5">
          <GripVertical size={16} style={{ color: 'var(--text-muted)' }} />
          <span className="text-xs font-bold w-5 text-center" style={{ color: 'var(--text-muted)' }}>{index + 1}</span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="badge-blue"><Icon size={10} />{typeInfo.label}</span>
            <span className="text-xs" style={{ color: 'var(--text-muted)' }}>{question.marks} mark{question.marks !== 1 ? 's' : ''}</span>
          </div>
          <p className="text-sm line-clamp-2" style={{ color: 'var(--text-primary)' }}>{question.question_text}</p>
          {question.options?.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {question.options.map((o, i) => {
                const isCorrect = question.question_type === 'mcq' ? o === question.correct_answer : Array.isArray(question.correct_answer) && question.correct_answer.includes(o);
                return (
                  <span key={i} className="text-xs px-2 py-0.5 rounded"
                    style={{ background: isCorrect ? 'var(--success-bg)' : 'var(--bg-tertiary)', color: isCorrect ? '#10b981' : 'var(--text-tertiary)' }}>
                    {String.fromCharCode(65 + i)}. {o}
                  </span>
                );
              })}
            </div>
          )}
        </div>
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
          <button onClick={() => onEdit(question)} className="p-1.5 rounded-lg transition-colors"
            style={{ color: 'var(--text-muted)' }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--text-primary)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
            <Pencil size={14} />
          </button>
          <button onClick={handleDelete} disabled={deleting} className="p-1.5 rounded-lg transition-colors"
            style={{ color: 'var(--text-muted)' }}
            onMouseEnter={e => e.currentTarget.style.color = '#ef4444'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
            {deleting ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
          </button>
        </div>
      </div>
    </motion.div>
  );
}

export default function TestManagePage() {
  const { testId } = useParams();
  const navigate   = useNavigate();
  const [test, setTest]             = useState(null);
  const [questions, setQuestions]   = useState([]);
  const [loading, setLoading]       = useState(true);
  const [showForm, setShowForm]     = useState(false);
  const [showCsvImport, setShowCsvImport] = useState(false);
  const [showRoster, setShowRoster] = useState(false);
  const [editQuestion, setEditQuestion] = useState(null);

  useEffect(() => {
    Promise.all([api.get(`/api/tests/${testId}`), api.get(`/api/questions/test/${testId}`)])
      .then(([t, q]) => { setTest(t.data); setQuestions(q.data.sort((a, b) => a.order_index - b.order_index)); })
      .catch(() => toast.error('Failed to load test'))
      .finally(() => setLoading(false));
  }, [testId]);

  const copyLink = async () => {
    const ok = await copyToClipboard(`${window.location.origin}/test/${test.access_code}`);
    if (ok) toast.success('Test link copied!');
    else toast.error('Could not copy the test link.');
  };

  const copyCode = async () => {
    const ok = await copyToClipboard(test.access_code);
    if (ok) toast.success('Access code copied!');
    else toast.error('Could not copy — please select the code and copy manually.');
  };

  const handleSaved = (q) => {
    setQuestions(prev => { const exists = prev.find(p => p.id === q.id); return exists ? prev.map(p => p.id === q.id ? q : p) : [...prev, q]; });
    setShowForm(false); setEditQuestion(null);
  };

  const handleDeleted = (id) => setQuestions(prev => prev.filter(q => q.id !== id));
  const handleEdit = (q) => { setEditQuestion(q); setShowForm(true); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const handleCsvImported = () => {
    api.get(`/api/questions/test/${testId}`).then(res => {
      setQuestions(res.data.sort((a, b) => a.order_index - b.order_index));
    }).catch(() => {});
    setShowCsvImport(false);
  };

  if (loading) return (
    <Layout><div className="flex items-center justify-center h-48">
      <div className="w-8 h-8 rounded-full border-2 border-cyan-500/20 border-t-cyan-500 animate-spin" />
    </div></Layout>
  );

  return (
    <Layout title={test?.title || 'Manage Test'}>
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <div className="flex items-center gap-2 mb-6 text-sm" style={{ color: 'var(--text-muted)' }}>
          <button onClick={() => navigate('/')} className="flex items-center gap-1 transition-colors" style={{ color: 'var(--text-muted)' }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--text-primary)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}><ArrowLeft size={14} /> Dashboard</button>
          <span>/</span>
          <span style={{ color: 'var(--text-primary)' }}>{test?.title}</span>
        </div>

        <div className="card p-4 mb-6">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-4 flex-wrap">
              {[
                { label: 'Access Code', value: <code className="font-mono font-bold tracking-widest" style={{ color: 'var(--brand-primary)' }}>{test?.access_code}</code> },
                { label: 'Duration',    value: `${test?.duration_mins} min` },
                { label: 'Questions',   value: questions.length },
                { label: 'Total Marks', value: test?.total_marks },
                { label: 'Pass Marks',  value: test?.passing_marks },
              ].map((s, i) => (
                <React.Fragment key={i}>
                  {i > 0 && <div className="h-8 w-px hidden sm:block" style={{ background: 'var(--border-primary)' }} />}
                  <div>
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{s.label}</p>
                    <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{s.value}</p>
                  </div>
                </React.Fragment>
              ))}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setShowRoster(v => !v)} className="btn-secondary text-xs">
                <Users size={13} /> Students
              </button>
              <button onClick={copyCode} className="btn-secondary text-xs"><Copy size={13} /> Copy Code</button>
              <button onClick={copyLink} className="btn-secondary text-xs"><Link2 size={13} /> Copy Link</button>
              <button onClick={() => navigate(`/tests/${testId}/results`)} className="btn-secondary text-xs"><BarChart2 size={13} /> Results</button>
              <button onClick={() => navigate(`/tests/${testId}/monitor`)} className="btn-secondary text-xs"><Activity size={13} className="text-emerald-400" /> Monitor</button>
            </div>
          </div>
        </div>

        {showRoster && (
          <RosterPanel testId={+testId} onClose={() => setShowRoster(false)} />
        )}

        {showForm ? (
          <div className="mb-6">
            <QuestionForm testId={+testId} initial={editQuestion} onSaved={handleSaved}
              onCancel={() => { setShowForm(false); setEditQuestion(null); }} />
          </div>
        ) : showCsvImport ? (
          <div className="mb-6">
            <CsvImportModal testId={+testId} onImported={handleCsvImported}
              onClose={() => setShowCsvImport(false)} />
          </div>
        ) : (
          <div className="flex gap-3 mb-6">
            <button onClick={() => { setShowForm(true); setEditQuestion(null); }} className="btn-primary">
              <Plus size={15} /> Add Question
            </button>
            <button onClick={() => setShowCsvImport(true)} className="btn-secondary">
              <Upload size={15} /> Import CSV
            </button>
          </div>
        )}

        {questions.length === 0 ? (
          <div className="card p-10 text-center">
            <p style={{ color: 'var(--text-muted)' }}>No questions yet. Add your first question above.</p>
          </div>
        ) : (
          <motion.div variants={container} initial="hidden" animate="show" className="space-y-2">
            {questions.map((q, i) => (
              <QuestionCard key={q.id} question={q} index={i} onEdit={handleEdit} onDelete={handleDeleted} />
            ))}
            <p className="text-xs text-center pt-2" style={{ color: 'var(--text-muted)' }}>
              {questions.length} question{questions.length !== 1 ? 's' : ''} • {questions.reduce((s, q) => s + q.marks, 0)} total marks
            </p>
          </motion.div>
        )}
      </motion.div>
    </Layout>
  );
}
