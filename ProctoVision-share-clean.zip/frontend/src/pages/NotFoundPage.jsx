import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { motion } from 'framer-motion';
import { ShieldCheck, ArrowLeft, Home, Sun, Moon } from 'lucide-react';

export default function NotFoundPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toggleTheme, isDark } = useTheme();

  const goHome = () => {
    if (!user) navigate('/login');
    else if (user.role === 'student') navigate('/student');
    else navigate('/');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative" style={{ background: 'var(--bg-primary)' }}>
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 scan-line-overlay opacity-30" />
      </div>

      <button onClick={toggleTheme}
        aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
        title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
        className="fixed top-4 right-4 p-2.5 rounded-xl z-50 transition-all duration-200"
        style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)', border: '1px solid var(--border-secondary)' }}>
        {isDark ? <Sun size={16} /> : <Moon size={16} />}
      </button>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center relative z-10">
        <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} transition={{ delay: 0.1, type: 'spring' }}
          className="inline-flex items-center justify-center w-24 h-24 rounded-3xl mb-8 relative"
          style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-primary)' }}>
          <ShieldCheck size={40} style={{ color: 'var(--text-muted)' }} />
        </motion.div>
        <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}
          className="text-display-xl font-display mb-4" style={{ color: 'var(--border-secondary)' }}>
          404
        </motion.h1>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}
          className="text-display-sm font-display mb-2" style={{ color: 'var(--text-primary)' }}>
          Page not found
        </motion.p>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
          className="text-sm mb-8 max-w-xs mx-auto" style={{ color: 'var(--text-muted)' }}>
          The page you're looking for doesn't exist or has been moved.
        </motion.p>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
          className="flex items-center gap-3 justify-center">
          <button onClick={() => navigate(-1)} className="btn-secondary">
            <ArrowLeft size={15} /> Go Back
          </button>
          <button onClick={goHome} className="btn-primary">
            <Home size={15} /> Dashboard
          </button>
        </motion.div>
      </motion.div>
    </div>
  );
}
