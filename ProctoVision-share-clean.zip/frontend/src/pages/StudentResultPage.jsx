// src/pages/StudentResultPage.jsx
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, CheckCircle, XCircle, Shield, Clock,
  AlertTriangle, Loader2, Award, Sun, Moon
} from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { format } from 'date-fns';
import { parseApiDate } from '../utils/datetime';
import { useTheme } from '../contexts/ThemeContext';
import { motion } from 'framer-motion';

const VIOLATION_LABELS = {
  phone_detected:     'Phone Detected',
  tab_switched:       'Tab Switched',
  looking_away:       'Looking Away',
  multiple_faces:     'Multiple Faces',
  no_face:            'No Face Detected',
  talking:            'Talking Detected',
  eye_gaze_away:      'Eye Gaze Away',
  fullscreen_exit:    'Exited Fullscreen',
  copy_paste:         'Copy/Paste Attempted',
  network_disconnect: 'Network Disconnect',
  laptop_detected:    'Laptop Detected',
};

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 }
};

const stagger = {
  animate: { transition: { staggerChildren: 0.08 } }
};

export default function StudentResultPage() {
  const { submissionId } = useParams();
  const navigate = useNavigate();
  const { theme, toggleTheme, isDark } = useTheme();
  const [data, setData]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab]       = useState('answers');

  useEffect(() => {
    api.get(`/api/student/result/${submissionId}`)
      .then(r => setData(r.data))
      .catch(() => {
        toast.error('Could not load result');
        navigate('/student');
      })
      .finally(() => setLoading(false));
  }, [submissionId]);

  if (loading) return (
    <div style={{ background: 'var(--bg-primary)' }} className="min-h-screen flex items-center justify-center">
      <Loader2 size={28} className="animate-spin" style={{ color: 'var(--text-muted)' }} />
    </div>
  );

  if (!data) return null;

  const { submission: sub, answers = [], violations = [] } = data;
  const riskColor = sub?.risk_level === 'Low' ? 'text-emerald-400' : sub?.risk_level === 'Medium' ? 'text-amber-400' : 'text-red-400';
  const scorePercent = sub?.percentage || 0;

  return (
    <div style={{ background: 'var(--bg-primary)' }} className="min-h-screen">
      {/* Header */}
      <header
        style={{
          background: 'var(--bg-secondary)',
          borderColor: 'var(--border-primary)',
          color: 'var(--text-primary)'
        }}
        className="border-b px-4 lg:px-8 py-4 flex items-center gap-4 sticky top-0 z-30"
      >
        <button onClick={() => navigate('/student')} className="flex items-center gap-2 text-sm transition-colors" style={{ color: 'var(--text-secondary)' }}>
          <ArrowLeft size={16} /> Back to Dashboard
        </button>
        <span style={{ color: 'var(--text-muted)' }}>/</span>
        <span style={{ color: 'var(--text-primary)' }} className="text-sm font-medium truncate">{sub?.test_title || 'Result'}</span>
        <div className="ml-auto">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg transition-colors"
            style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}
            title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {isDark ? <Sun size={16} /> : <Moon size={16} />}
          </button>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 py-8 space-y-6">
        {/* Hero result card */}
        <motion.div className="card p-8 text-center" {...fadeInUp}>
          <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full mb-4 ${sub?.passed ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
            {sub?.passed
              ? <Award size={40} className="text-emerald-400" />
              : <XCircle size={40} className="text-red-400" />}
          </div>
          <h1 className="text-3xl font-bold font-display mb-1" style={{ color: 'var(--text-primary)' }}>
            {sub?.passed ? '🎉 Passed!' : '❌ Failed'}
          </h1>
          <p style={{ color: 'var(--text-muted)' }} className="text-sm mb-6">{sub?.test_title}</p>

          <div className="flex items-center justify-center gap-8 flex-wrap mb-6">
            <div>
              <p className="text-4xl font-bold" style={{ color: 'var(--text-primary)' }}>
                {sub?.score}<span className="text-xl" style={{ color: 'var(--text-muted)' }}>/{sub?.max_score}</span>
              </p>
              <p style={{ color: 'var(--text-muted)' }} className="text-sm mt-1">Score</p>
            </div>
            <div className="h-12 w-px hidden sm:block" style={{ background: 'var(--border-primary)' }} />
            <div>
              <p className="text-4xl font-bold" style={{ color: 'var(--brand-primary)' }}>{scorePercent.toFixed(1)}%</p>
              <p style={{ color: 'var(--text-muted)' }} className="text-sm mt-1">Percentage</p>
            </div>
            <div className="h-12 w-px hidden sm:block" style={{ background: 'var(--border-primary)' }} />
            <div>
              <p className={`text-4xl font-bold ${riskColor}`}>{Math.round(sub?.integrity_score)}</p>
              <p style={{ color: 'var(--text-muted)' }} className="text-sm mt-1">Integrity</p>
            </div>
          </div>

          <div className="max-w-sm mx-auto">
            <div className="w-full h-3 rounded-full overflow-hidden" style={{ background: 'var(--bg-tertiary)' }}>
              <motion.div
                className={`h-full rounded-full ${sub?.passed ? 'bg-emerald-500' : 'bg-red-500'}`}
                initial={{ width: 0 }}
                animate={{ width: `${scorePercent}%` }}
                transition={{ duration: 1, ease: 'easeOut' }}
              />
            </div>
            <div className="flex justify-between text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
              <span>0%</span>
              <span className="text-amber-400">Pass: {sub?.passing_marks}/{sub?.max_score}</span>
              <span>100%</span>
            </div>
          </div>
        </motion.div>

        {/* Quick stats */}
        <motion.div className="grid grid-cols-2 sm:grid-cols-4 gap-3" variants={stagger} initial="initial" animate="animate">
          {[
            { label: 'Time Taken',  value: sub?.time_taken_secs ? `${Math.floor(sub.time_taken_secs/60)}m ${sub.time_taken_secs%60}s` : '—', icon: Clock          },
            { label: 'Violations',  value: violations.length,   icon: AlertTriangle },
            { label: 'Risk Level',  value: sub?.risk_level || '—', icon: Shield       },
            { label: 'Submitted',   value: sub?.submitted_at ? format(parseApiDate(sub.submitted_at), 'HH:mm') : '—', icon: CheckCircle },
          ].map((s, i) => (
            <motion.div key={i} className="card p-3 text-center" variants={fadeInUp}>
              <s.icon size={16} className="mx-auto mb-1" style={{ color: 'var(--text-muted)' }} />
              <p className="text-base font-bold" style={{ color: 'var(--text-primary)' }}>{s.value}</p>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{s.label}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Tabs */}
        <div
          className="flex gap-1 rounded-xl p-1 w-fit"
          style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border-primary)' }}
        >
          {[
            { key: 'answers',    label: `Answer Review (${answers.length})` },
            { key: 'violations', label: `Violations (${violations.length})`  },
          ].map(({ key, label }) => (
            <button key={key} onClick={() => setTab(key)}
              className="px-4 py-2 rounded-lg text-sm font-medium transition-all"
              style={{
                background: tab === key ? 'var(--bg-tertiary)' : 'transparent',
                color: tab === key ? 'var(--text-primary)' : 'var(--text-muted)'
              }}>
              {label}
            </button>
          ))}
        </div>

        {/* Answer Review */}
        {tab === 'answers' && (
          <motion.div className="space-y-3" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
            {answers.length === 0 ? (
              <div className="card p-8 text-center text-sm" style={{ color: 'var(--text-muted)' }}>No answer data available</div>
            ) : answers.map((a, i) => (
              <div key={i} className={`card p-4 border-l-4 ${
                a.is_correct === true  ? 'border-l-emerald-500' :
                a.is_correct === false ? 'border-l-red-500' : 'border-l-gray-700'
              }`}>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <span className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>Q{i + 1}</span>
                  <div>
                    {a.is_correct === true  && <span className="badge-green text-xs">+{a.marks_awarded} marks</span>}
                    {a.is_correct === false && <span className="badge-red text-xs">0 marks</span>}
                    {a.is_correct === null  && <span className="badge-gray text-xs">Manual grading</span>}
                  </div>
                </div>
                <p className="text-sm mb-2 whitespace-pre-wrap" style={{ color: 'var(--text-primary)' }}>{a.question_text}</p>
                {a.selected_options?.length > 0 && (
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>Your answer: <span style={{ color: 'var(--text-primary)' }}>{a.selected_options.join(', ')}</span></p>
                )}
                {a.answer_text && (
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>Your answer: <span style={{ color: 'var(--text-primary)' }}>{a.answer_text}</span></p>
                )}
                {!a.selected_options?.length && !a.answer_text && (
                  <p className="text-xs italic" style={{ color: 'var(--text-muted)' }}>Not answered</p>
                )}
                {a.correct_answer && a.is_correct === false && !['short_answer','coding'].includes(a.question_type) && (
                  <p className="text-xs text-emerald-400 mt-1">
                    ✓ Correct: {Array.isArray(a.correct_answer) ? a.correct_answer.join(', ') : a.correct_answer}
                  </p>
                )}
              </div>
            ))}
          </motion.div>
        )}

        {/* Violations */}
        {tab === 'violations' && (
          <motion.div className="card p-5" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
            {violations.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle size={32} className="text-emerald-400 mx-auto mb-3" />
                <p style={{ color: 'var(--text-primary)' }} className="font-medium">Clean exam — no violations!</p>
                <p style={{ color: 'var(--text-muted)' }} className="text-sm mt-1">You maintained a perfect integrity score.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {violations.map((v, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-red-500/5 border border-red-500/15">
                    <AlertTriangle size={14} className="text-red-400 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm text-red-300 font-medium">
                        {VIOLATION_LABELS[v.violation_type] || v.violation_type.replace(/_/g, ' ')}
                      </p>
                      {v.description && <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{v.description}</p>}
                      <p className="text-xs mt-1 font-mono" style={{ color: 'var(--text-muted)' }}>
                        {v.timestamp ? format(parseApiDate(v.timestamp), 'HH:mm:ss') : ''}
                      </p>
                    </div>
                    {v.penalty_applied > 0 && (
                      <span className="text-xs text-red-400 font-semibold">−{v.penalty_applied} pts</span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}
