// src/pages/ExamEntryPage.jsx
import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { Camera, Mic, Clock, FileText, Users, CheckCircle, AlertCircle, Loader2, ChevronRight, LogIn, Eye, EyeOff, Sun, Moon, KeyRound, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../utils/api';

function PermRow({ label, status, icon: Icon }) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-800/50">
      <Icon size={16} className="text-gray-400 flex-shrink-0" />
      <span className="flex-1 text-sm text-gray-300">{label}</span>
      {status === 'granted' && <CheckCircle size={16} className="text-emerald-400" />}
      {status === 'denied'  && <AlertCircle size={16} className="text-red-400" />}
      {status === 'pending' && <div className="w-4 h-4 border-2 border-gray-600 rounded-full" />}
    </div>
  );
}

function LeaveExamBtn({ navigate, user, label = 'Leave exam' }) {
  return (
    <button onClick={() => navigate(user ? '/student' : '/login')}
      className="inline-flex items-center gap-1 text-xs text-gray-600 hover:text-gray-400 transition-colors">
      <ArrowLeft size={12} /> {label}
    </button>
  );
}

export default function ExamEntryPage() {
  const { accessCode } = useParams();
  const { user, login, logout } = useAuth();
  const { toggleTheme, isDark } = useTheme();
  const navigate = useNavigate();

  const [test, setTest]         = useState(null);
  const [codeError, setCodeError] = useState(null);
  const [loading, setLoading]   = useState(true);
  const [step, setStep]         = useState('login');
  const [camStatus, setCamStatus] = useState('pending');
  const [micStatus, setMicStatus] = useState('pending');
  const [stream, setStream]     = useState(null);
  const videoRef = useRef(null);

  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [showPwd, setShowPwd]     = useState(false);
  const [loggingIn, setLoggingIn] = useState(false);

  // Teacher's roster + unique emailed password
  const [access, setAccess]         = useState(null);
  const [accessError, setAccessError] = useState('');
  const [examPassword, setExamPassword] = useState('');
  const [verifying, setVerifying]   = useState(false);
  const routedRef                   = useRef(false);

  useEffect(() => {
    let cancelled = false;
    api.get(`/api/tests/code/${accessCode}`)
      .then(r => { if (!cancelled) { setTest(r.data); setLoading(false); } })
      .catch(err => {
        if (cancelled) return;
        const detail = err.response?.data?.detail
          || `No test found with access code "${accessCode}". Check the code and try again.`;
        setCodeError({ status: err.response?.status, detail });
        toast.error(detail, { duration: 6000 });
        setLoading(false);
      });
    return () => { cancelled = true; };
  }, [accessCode]);

  const routeAfterAuth = async () => {
    try {
      const res = await api.get(`/api/tests/${test.id}/access-status`);
      const a = res.data;
      setAccess(a);
      setAccessError('');
      if (!a.on_list) { setStep('blocked'); return; }
      if (a.password_required) { setStep('password'); return; }
      if (a.already_submitted) { setStep('submitted'); return; }
      setStep('instructions');
    } catch (err) {
      // Never fall through to the exam on a failed check — show why.
      const detail = err.response?.data?.detail || 'Could not check your access to this test.';
      setAccessError(detail);
      toast.error(detail, { duration: 6000 });
      setStep('error');
    }
  };

  useEffect(() => {
    if (!user) { routedRef.current = false; return; }
    if (!test || routedRef.current) return;
    if (user.role === 'student') {
      routedRef.current = true;
      if (user.must_change_password) {
        toast('Set your own password first, then you will return to this exam.', { icon: '🔑', duration: 6000 });
        navigate('/change-password', { replace: true, state: { from: `/test/${accessCode}` } });
        return;
      }
      routeAfterAuth();
      return;
    }
    setStep('login');
    toast.error('Please sign in with a student account to take this exam.', { id: 'student-only-exam' });
  }, [user, test]);

  useEffect(() => {
    if (stream && videoRef.current) videoRef.current.srcObject = stream;
  }, [stream]);

  // Cleanup stream on unmount
  useEffect(() => () => { stream?.getTracks().forEach(t => t.stop()); }, [stream]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoggingIn(true);
    try {
      const loggedInUser = await login(loginForm.email, loginForm.password);
      if (loggedInUser.role !== 'student') {
        logout();
        toast.error('Only student accounts can take exams.');
        return;
      }
      routedRef.current = false;   // the [user, test] effect now routes the steps
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Invalid email or password');
    } finally {
      setLoggingIn(false);
    }
  };

  const handleVerifyPassword = async (e) => {
    e.preventDefault();
    if (!examPassword.trim()) { toast.error('Enter the exam password from your email'); return; }
    setVerifying(true);
    try {
      await api.post(`/api/tests/${test.id}/verify-password`, { password: examPassword.trim() });
      const doneWithoutRetake = access?.already_submitted && !access?.retake_allowed;
      setStep(doneWithoutRetake ? 'submitted' : 'instructions');
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Incorrect exam password', { duration: 6000 });
    } finally {
      setVerifying(false);
    }
  };

  const requestPermissions = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      setStream(s);
      setCamStatus('granted');
      setMicStatus('granted');
      setStep('ready');
    } catch (err) {
      setCamStatus('denied');
      setMicStatus('denied');
      toast.error('Camera & microphone access is required to take the exam.');
    }
  };

  const startExam = async () => {
    if (camStatus !== 'granted') { toast.error('Camera permission required'); return; }
    try {
      // Pre-check: attempt to start a submission to catch "already submitted" early
      await api.post('/api/submissions/start', {
        test_id: test.id,
        test_password: examPassword.trim() || null,
      });
      stream?.getTracks().forEach(t => t.stop());
      navigate(`/exam/${test.id}`);
    } catch (err) {
      const msg = err.response?.data?.detail || 'Could not start exam';
      toast.error(msg, { duration: 6000 });
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center text-center p-4">
      <div>
        <Loader2 size={28} className="animate-spin text-gray-600 mx-auto" />
        <p className="text-gray-500 text-sm mt-4">Checking access code <span className="font-mono tracking-widest">{accessCode}</span>…</p>
      </div>
    </div>
  );

  if (!test) return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center text-center p-4">
      <div className="max-w-sm">
        <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-3">
          <AlertCircle size={22} className="text-red-400" />
        </div>
        <p className="text-gray-400 text-lg font-medium">
          {codeError?.status === 403 ? 'This test is not available' : 'Test not found'}
        </p>
        <p className="text-gray-500 text-sm mt-2">{codeError?.detail}</p>
        <div className="flex gap-2 justify-center mt-5">
          <button onClick={() => navigate('/login')} className="btn-secondary">Go to Login</button>
          <button onClick={() => window.location.reload()} className="btn-secondary">Try Again</button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-gradient-to-br from-brand-900/10 via-transparent to-transparent pointer-events-none" />
      <button onClick={toggleTheme} className="fixed top-4 right-4 p-2.5 rounded-xl z-50 bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-white border border-gray-700 transition-all"
        title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}>
        {isDark ? <Sun size={16} /> : <Moon size={16} />}
      </button>
      <div className="w-full max-w-md relative">
        <div className="text-center mb-6">
          <img src="/logo.png" alt="ProctoVision" className="w-12 h-12 rounded-full mb-3" />
          <h1 className="text-xl font-bold text-white">ExamGuard</h1>
        </div>

        <div className="card overflow-hidden">
          {/* Test header */}
          <div className="bg-gray-800/50 p-5 border-b border-gray-800">
            <h2 className="text-base font-semibold text-white mb-1">{test.title}</h2>
            {test.description && <p className="text-sm text-gray-500">{test.description}</p>}
            <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
              <span className="flex items-center gap-1"><Clock size={12} />{test.duration_mins} min</span>
              <span className="flex items-center gap-1"><FileText size={12} />{test.question_count} questions</span>
              <span className="flex items-center gap-1"><Users size={12} />{test.total_marks} marks</span>
            </div>
          </div>

          <div className="p-6">
            {/* Step: Login */}
            {step === 'login' && (
              <div>
                <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                  <LogIn size={16} className="text-brand-400" /> Sign in to take this exam
                </h3>
                <form onSubmit={handleLogin} className="space-y-3">
                  <input className="input" type="email" placeholder="Email address"
                    value={loginForm.email} onChange={e => setLoginForm(p => ({...p, email: e.target.value}))} required />
                  <div className="relative">
                    <input className="input pr-10" type={showPwd ? 'text' : 'password'} placeholder="Password"
                      value={loginForm.password} onChange={e => setLoginForm(p => ({...p, password: e.target.value}))} required />
                    <button type="button" onClick={() => setShowPwd(p => !p)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
                      {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  <button type="submit" disabled={loggingIn} className="btn-primary w-full justify-center">
                    {loggingIn && <Loader2 size={15} className="animate-spin" />}
                    {loggingIn ? 'Signing in…' : 'Sign In & Continue'}
                  </button>
                </form>
                <p className="text-xs text-gray-600 text-center mt-4">
                  Student accounts are issued by your college — sign in with the credentials you were given.
                </p>
              </div>
            )}

            {/* Step: access-status check failed — show why, never skip the gate */}
            {step === 'error' && (
              <div className="text-center py-2">
                <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-3">
                  <AlertCircle size={22} className="text-amber-400" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-2">Access check failed</h3>
                <p className="text-sm text-gray-500 mb-5">{accessError}</p>
                <div className="space-y-2">
                  <button onClick={() => routeAfterAuth()} className="btn-primary w-full justify-center">
                    Try Again
                  </button>
                  <button onClick={() => navigate('/student')} className="btn-secondary w-full justify-center">
                    Go to Home
                  </button>
                </div>
              </div>
            )}

            {/* Step: Not on the teacher's list */}
            {step === 'blocked' && (
              <div className="text-center py-2">
                <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-3">
                  <AlertCircle size={22} className="text-red-400" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-2">You are not on the list for this test</h3>
                <p className="text-sm text-gray-500 mb-5">
                  Your account was not selected by the teacher for this exam. Only selected students can attempt it.
                </p>
                <button onClick={() => navigate('/student')} className="btn-secondary w-full justify-center">
                  Go to Home
                </button>
              </div>
            )}

            {/* Step: Already submitted */}
            {step === 'submitted' && (
              <div className="text-center py-2">
                <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-3">
                  <CheckCircle size={22} className="text-amber-400" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-2">You have already submitted this test</h3>
                <p className="text-sm text-gray-500 mb-5">
                  Your attempt for <b className="text-gray-300">{test.title}</b> was submitted
                  {access?.already_started ? ' and can no longer be edited.' : '.'}
                  {(access?.retake_allowed || test?.allow_retake)
                    ? ' Your teacher has enabled a retake — continue below.'
                    : ' Retakes are only possible if your teacher enables them.'}
                </p>
                <div className="space-y-2">
                  {(access?.retake_allowed || test?.allow_retake) && (
                    <button onClick={() => setStep(access?.password_required ? 'password' : 'instructions')}
                      className="btn-primary w-full justify-center">
                      Continue to Retake
                    </button>
                  )}
                  <button onClick={() => navigate('/student')} className="btn-secondary w-full justify-center">
                    Go to My Dashboard
                  </button>
                  <button onClick={() => navigate('/login')} className="btn-secondary w-full justify-center">
                    Sign out
                  </button>
                </div>
              </div>
            )}

            {/* Step: Unique exam password (emailed by the teacher) */}
            {step === 'password' && (
              <div>
                <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                  <KeyRound size={16} className="text-brand-400" /> Enter Your Exam Password
                </h3>
                <p className="text-sm text-gray-500 mb-4">
                  A unique password was emailed to <span className="text-gray-300">{user?.email}</span>.
                  It works only for you and only once.
                </p>
                {access?.password_sent === 'failed' && (
                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg mb-4">
                    <p className="text-xs text-amber-300">
                      The email could not be delivered. Ask your teacher to resend your password.
                    </p>
                  </div>
                )}
                <form onSubmit={handleVerifyPassword} className="space-y-3">
                  <input className="input text-center font-mono tracking-[0.3em] uppercase"
                    type="text" placeholder="EXAM PASSWORD" autoComplete="off"
                    value={examPassword}
                    onChange={e => setExamPassword(e.target.value.toUpperCase())} required />
                  <button type="submit" disabled={verifying} className="btn-primary w-full justify-center">
                    {verifying && <Loader2 size={15} className="animate-spin" />}
                    {verifying ? 'Verifying…' : 'Verify & Continue'}
                  </button>
                </form>
                <p className="text-xs text-gray-600 text-center mt-4">
                  Check your inbox (and spam folder). Wrong tries are limited.
                </p>
                <div className="text-center mt-3">
                  <LeaveExamBtn navigate={navigate} user={user} />
                </div>
              </div>
            )}

            {/* Step: Instructions */}
            {step === 'instructions' && (
              <div>
                <h3 className="text-sm font-semibold text-white mb-4">📋 Exam Instructions</h3>
                <ul className="space-y-2.5 mb-6">
                  {[
                    'Keep your face clearly visible in the webcam at all times',
                    'Do not switch browser tabs or minimize the window',
                    'No other people should be visible on camera',
                    'No mobile phones or secondary devices allowed',
                    `You have ${test.duration_mins} minutes to complete the exam`,
                    'Your answers are auto-saved every 30 seconds',
                    `Passing mark: ${test.passing_marks} out of ${test.total_marks}`,
                    'AI proctoring is active throughout the entire exam',
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-400">
                      <CheckCircle size={14} className="text-brand-400 mt-0.5 flex-shrink-0" />{item}
                    </li>
                  ))}
                </ul>
                <button onClick={() => setStep('permissions')} className="btn-primary w-full justify-center">
                  I Understand — Continue <ChevronRight size={15} />
                </button>
                <div className="text-center mt-3">
                  <LeaveExamBtn navigate={navigate} user={user} />
                </div>
              </div>
            )}

            {/* Step: Permissions */}
            {step === 'permissions' && (
              <div>
                <h3 className="text-sm font-semibold text-white mb-3">🎥 Camera & Microphone Access</h3>
                <p className="text-sm text-gray-500 mb-4">This exam requires camera and microphone access for AI proctoring.</p>
                <div className="space-y-2 mb-5">
                  <PermRow label="Camera (required for proctoring)" status={camStatus} icon={Camera} />
                  <PermRow label="Microphone (required)"            status={micStatus} icon={Mic} />
                </div>
                {camStatus === 'denied' && (
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg mb-4">
                    <p className="text-xs text-red-300">Permission denied. Please allow camera access in your browser settings and reload this page.</p>
                  </div>
                )}
                <button onClick={requestPermissions} className="btn-primary w-full justify-center">
                  <Camera size={15} /> Grant Camera & Microphone Access
                </button>
                <div className="text-center mt-3 flex items-center justify-center gap-5">
                  <button onClick={() => setStep('instructions')}
                    className="inline-flex items-center gap-1 text-xs text-gray-600 hover:text-gray-400 transition-colors">
                    <ArrowLeft size={12} /> Back to instructions
                  </button>
                  <LeaveExamBtn navigate={navigate} user={user} />
                </div>
              </div>
            )}

            {/* Step: Ready */}
            {step === 'ready' && (
              <div>
                <h3 className="text-sm font-semibold text-white mb-3">✅ All Set! Camera Preview</h3>
                <div className="relative rounded-xl overflow-hidden bg-gray-800 mb-4 aspect-video">
                  <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover" />
                  <div className="absolute top-2 right-2">
                    <div className="flex items-center gap-1.5 bg-black/60 rounded-full px-2 py-1">
                      <div className="live-dot" />
                      <span className="text-xs text-white font-medium">Camera ready</span>
                    </div>
                  </div>
                </div>
                <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg mb-4">
                  <p className="text-xs text-amber-300">⚠️ Once started, do not exit fullscreen, switch tabs, or look away for extended periods.</p>
                </div>
                <button onClick={startExam} className="btn-primary w-full justify-center text-base py-3 font-semibold">
                  🚀 Start Exam Now
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
