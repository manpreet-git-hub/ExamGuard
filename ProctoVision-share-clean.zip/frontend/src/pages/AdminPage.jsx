// src/pages/AdminPage.jsx — ProctoVision Admin Panel
import { useState, useEffect, useCallback } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { motion } from 'framer-motion';
import {
  Users, AlertTriangle, Trash2,
  Edit2, Check, X, ChevronDown, ChevronUp, RefreshCw,
  ToggleLeft, ToggleRight, Lock,
  Loader2, Search, Database, Upload, Download, UserPlus,
  ShieldCheck, GraduationCap, UserCheck
} from 'lucide-react';
import toast from 'react-hot-toast';
import Layout from '../components/shared/Layout';
import api from '../utils/api';
import { useAuth } from '../contexts/AuthContext';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: (i = 0) => ({ opacity: 1, y: 0, transition: { delay: i * 0.07, duration: 0.35, ease: 'easeOut' } }),
};

// ── Confirm Modal ──────────────────────────────────────────────────────────────
function ConfirmModal({ message, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.92 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.2 }}
        style={{
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-primary)',
          borderRadius: '1rem',
          padding: '1.5rem',
          maxWidth: '24rem',
          width: '100%',
          boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
          <div style={{ background: 'var(--danger-bg)', border: '1px solid var(--danger-border)', borderRadius: '9999px', width: '2.5rem', height: '2.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <AlertTriangle size={18} style={{ color: 'var(--text-secondary)' }} />
          </div>
          <p style={{ fontSize: '0.875rem', color: 'var(--text-primary)' }}>{message}</p>
        </div>
        <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
          <button onClick={onCancel} className="btn-secondary" style={{ fontSize: '0.875rem', padding: '0.5rem 1rem' }}>Cancel</button>
          <button onClick={onConfirm} className="btn-danger" style={{ fontSize: '0.875rem', padding: '0.5rem 1rem' }}>Delete</button>
        </div>
      </motion.div>
    </div>
  );
}

// ── Import Accounts Modal (students or teachers) ─────────────────────────────
function ImportUsersModal({ role, onClose, onImported }) {
  const isTeacher = role === 'teacher';
  const singular = isTeacher ? 'Teacher' : 'Student';
  const idKey = isTeacher ? 'teacher_id' : 'student_id';
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);

  const TEMPLATE = isTeacher
    ? 'teacher_id,name,email,department\nTCH1001,Prof. James Wilson,,MCA\n'
    : 'roll_no,name,email,course\n21CS1001,Asha Rao,,B.Tech CSE\n21CS1002,Rahul Verma,,B.Tech CSE\n';

  const downloadTemplate = () => {
    const url = URL.createObjectURL(new Blob([TEMPLATE], { type: 'text/csv;charset=utf-8;' }));
    const a = document.createElement('a');
    a.href = url; a.download = `${role}-import-template.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const upload = async () => {
    if (!file) return;
    setBusy(true);
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('role', role);
      const res = await api.post('/api/admin/users/import', form, { timeout: 60000 });
      setResult(res.data);
      onImported?.();
      if (res.data.created_count > 0) toast.success(`Created ${res.data.created_count} ${singular.toLowerCase()} account(s)`);
      if (res.data.skipped_count > 0) toast(`${res.data.skipped_count} row(s) skipped`, { icon: '⚠️' });
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Import failed');
    } finally {
      setBusy(false);
    }
  };

  const downloadCsv = () => {
    const rows = [
      [`${singular} ID`, 'Name', 'Email', 'Course', 'Password'],
      ...result.created.map(a => [a[idKey], a.full_name, a.email, a.course || '', a.password]),
    ];
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `${role}-credentials-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const boxStyle = {
    background: 'var(--bg-secondary)',
    border: '1px solid var(--border-primary)',
    borderRadius: '1rem',
    padding: '1.5rem',
    maxWidth: '44rem',
    width: '100%',
    maxHeight: '85vh',
    overflowY: 'auto',
    boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)',
  };
  const thStyle = { textAlign: 'left', padding: '0.5rem 0.75rem', fontSize: '0.7rem', color: 'var(--text-muted)', borderBottom: '1px solid var(--border-primary)', fontWeight: 500 };
  const tdStyle = { padding: '0.5rem 0.75rem', borderBottom: '1px solid var(--border-primary)', fontSize: '0.8rem' };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <motion.div initial={{ opacity: 0, scale: 0.92 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.2 }} style={boxStyle}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{ background: 'var(--brand-bg)', border: '1px solid var(--brand-border)', borderRadius: '9999px', width: '2.5rem', height: '2.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <UserPlus size={18} style={{ color: 'var(--brand-primary)' }} />
            </div>
            <div>
              <p className="font-display" style={{ fontSize: '0.95rem', fontWeight: 700, color: 'var(--text-primary)' }}>Import {singular}s</p>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>One {isTeacher ? 'teacher ID' : 'enrollment number'} per row</p>
            </div>
          </div>
          <button onClick={onClose} style={{ color: 'var(--text-muted)' }} className="hover:opacity-70"><X size={18} /></button>
        </div>

        {!result ? (
          <>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '1rem', lineHeight: 1.6 }}>
              Upload a <b>.csv</b> (or .txt / .xlsx) with a header row:{' '}
              <code style={{ color: 'var(--brand-primary)' }}>roll_no,name,email,course</code>.
              Leave <b>email</b> / <b>course</b> empty to auto-generate the email and skip the course.
              A plain list of {isTeacher ? 'teacher IDs' : 'roll numbers'} (one per row, no header) also works —
              email and password are generated for every row.
            </p>
            <label
              style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                border: '1px dashed var(--border-primary)', borderRadius: '0.75rem', padding: '2rem 1rem',
                background: 'var(--bg-tertiary)', cursor: 'pointer', textAlign: 'center',
              }}
            >
              <Upload size={22} style={{ color: 'var(--brand-primary)' }} />
              <span style={{ fontSize: '0.8rem', color: file ? 'var(--text-primary)' : 'var(--text-muted)' }}>
                {file ? file.name : 'Click to choose a file'}
              </span>
              <input
                type="file"
                accept=".txt,.csv,.xlsx,text/plain,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                style={{ display: 'none' }}
                onChange={e => setFile(e.target.files?.[0] || null)}
              />
            </label>
            <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'space-between', marginTop: '1.25rem', flexWrap: 'wrap' }}>
              <button onClick={downloadTemplate} className="btn-secondary" style={{ fontSize: '0.875rem', padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
                <Download size={14} /> Download CSV template
              </button>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button onClick={onClose} className="btn-secondary" style={{ fontSize: '0.875rem', padding: '0.5rem 1rem' }}>Cancel</button>
              <button onClick={upload} disabled={!file || busy} className="btn-primary" style={{ fontSize: '0.875rem', padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.375rem', opacity: !file || busy ? 0.6 : 1 }}>
                {busy && <Loader2 size={14} className="animate-spin" />}
                {busy ? 'Creating accounts…' : 'Upload & Create Accounts'}
              </button>
              </div>
            </div>
          </>
        ) : (
          <>
            <div style={{ display: 'flex', gap: '1.5rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              <div>
                <p className="font-display" style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--success-bg)' }}>{result.created_count}</p>
                <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Accounts created</p>
              </div>
              <div>
                <p className="font-display" style={{ fontSize: '1.25rem', fontWeight: 700, color: result.skipped_count ? 'var(--warning-bg)' : 'var(--text-muted)' }}>{result.skipped_count}</p>
                <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Rows skipped</p>
              </div>
              <div>
                <p className="font-display" style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--text-primary)' }}>{result.total_rows}</p>
                <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>Rows in file</p>
              </div>
            </div>

            {result.created.length > 0 && (
              <div style={{ overflowX: 'auto', border: '1px solid var(--border-primary)', borderRadius: '0.5rem', maxHeight: '16rem', overflowY: 'auto' }}>
                <table style={{ width: '100%' }}>
                  <thead>
                    <tr>
                      <th style={thStyle}>{singular} ID</th>
                      <th style={thStyle}>Name</th>
                      <th style={thStyle}>Email (login)</th>
                      <th style={thStyle}>Course</th>
                      <th style={thStyle}>Password</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.created.map(a => (
                      <tr key={a.student_id} style={{ transition: 'background 0.15s' }}
                        onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary)'}
                        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                      >
                        <td style={{ ...tdStyle, color: 'var(--text-primary)', fontFamily: 'monospace', fontWeight: 600 }}>{a[idKey]}</td>
                        <td style={{ ...tdStyle, color: 'var(--text-primary)' }}>{a.full_name}</td>
                        <td style={{ ...tdStyle, color: 'var(--text-secondary)', fontFamily: 'monospace' }}>{a.email}</td>
                        <td style={{ ...tdStyle, color: 'var(--text-secondary)' }}>{a.course || '—'}</td>
                        <td style={{ ...tdStyle, color: 'var(--brand-primary)', fontFamily: 'monospace', fontWeight: 600 }}>{a.password}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {result.skipped.length > 0 && (
              <div style={{ marginTop: '1rem', border: '1px solid var(--warning-border, var(--border-primary))', borderRadius: '0.5rem', padding: '0.75rem', maxHeight: '9rem', overflowY: 'auto' }}>
                <p style={{ fontSize: '0.75rem', color: 'var(--warning-bg)', fontWeight: 600, marginBottom: '0.375rem' }}>Skipped rows</p>
                {result.skipped.map((s, i) => (
                  <p key={i} style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontFamily: 'monospace' }}>
                    {s.value} — {s.reason}
                  </p>
                ))}
              </div>
            )}

            <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end', marginTop: '1.25rem', flexWrap: 'wrap' }}>
              <button onClick={downloadCsv} disabled={!result.created.length} className="btn-secondary"
                style={{ fontSize: '0.875rem', padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.375rem', opacity: result.created.length ? 1 : 0.5 }}>
                <Download size={14} /> Download CSV
              </button>
              <button onClick={onClose} className="btn-primary" style={{ fontSize: '0.875rem', padding: '0.5rem 1rem' }}>Done</button>
            </div>
          </>
        )}
      </motion.div>
    </div>
  );
}

// ── Inline Edit Input ──────────────────────────────────────────────────────────
function InlineEdit({ value, onSave, type = 'text', className = '' }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(value);
  const save = () => { onSave(val); setEditing(false); };
  const cancel = () => { setVal(value); setEditing(false); };
  if (!editing) return (
    <span
      className={`group flex items-center gap-1 cursor-pointer ${className}`}
      onClick={() => setEditing(true)}
      style={{ color: 'var(--text-primary)' }}
    >
      {val || <span style={{ color: 'var(--text-muted)', fontStyle: 'italic' }}>—</span>}
      <Edit2 size={11} className="opacity-0 group-hover:opacity-60" style={{ color: 'var(--text-secondary)', flexShrink: 0 }} />
    </span>
  );
  return (
    <span className="flex items-center gap-1">
      <input autoFocus type={type} value={val} onChange={e => setVal(e.target.value)}
        onKeyDown={e => { if (e.key === 'Enter') save(); if (e.key === 'Escape') cancel(); }}
        style={{
          background: 'var(--bg-tertiary)',
          border: '1px solid var(--brand-primary)',
          borderRadius: '0.25rem',
          padding: '0.125rem 0.5rem',
          fontSize: '0.875rem',
          color: 'var(--text-primary)',
          outline: 'none',
          width: '9rem',
        }}
      />
      <button onClick={save} style={{ color: 'var(--success-bg)' }} className="hover:opacity-80"><Check size={13} /></button>
      <button onClick={cancel} style={{ color: 'var(--danger-bg)' }} className="hover:opacity-80"><X size={13} /></button>
    </span>
  );
}

// ── Stat Card ──────────────────────────────────────────────────────────────────
function StatCard({ icon: Icon, label, value, color }) {
  return (
    <motion.div
      variants={fadeUp}
      className="card"
      style={{ padding: '1rem', display: 'flex', alignItems: 'center', gap: '1rem' }}
    >
      <div style={{ background: color, borderRadius: '0.75rem', width: '2.75rem', height: '2.75rem', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon size={20} style={{ color: '#fff' }} />
      </div>
      <div>
        <p className="font-display" style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--text-primary)' }}>{value ?? '—'}</p>
        <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.125rem' }}>{label}</p>
      </div>
    </motion.div>
  );
}

// ── Section wrapper ────────────────────────────────────────────────────────────
function Section({ title, icon: Icon, count, children, open, onToggle }) {
  return (
    <motion.div variants={fadeUp} className="card" style={{ overflow: 'hidden' }}>
      <button onClick={onToggle}
        style={{
          width: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '1rem',
          transition: 'background 0.15s',
        }}
        className="hover:opacity-90"
        onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary)'}
        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <Icon size={18} style={{ color: 'var(--brand-primary)' }} />
          <span className="font-display" style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{title}</span>
          {count != null && (
            <span style={{ fontSize: '0.75rem', background: 'var(--brand-bg)', color: 'var(--brand-primary)', border: '1px solid var(--brand-border)', padding: '0.125rem 0.5rem', borderRadius: '9999px', fontFamily: 'monospace' }}>{count}</span>
          )}
        </div>
        {open ? <ChevronUp size={16} style={{ color: 'var(--text-muted)' }} /> : <ChevronDown size={16} style={{ color: 'var(--text-muted)' }} />}
      </button>
      {open && <div style={{ borderTop: '1px solid var(--border-primary)' }}>{children}</div>}
    </motion.div>
  );
}

// ── Search bar (spacing comes from the parent flex gap) ──────────────────────
function SearchBar({ value, onChange, placeholder }) {
  return (
    <div style={{ position: 'relative' }}>
      <Search size={14} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
      <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{
          width: '100%',
          background: 'var(--bg-tertiary)',
          border: '1px solid var(--border-primary)',
          fontSize: '0.875rem',
          color: 'var(--text-primary)',
          borderRadius: '0.5rem',
          paddingLeft: '2rem',
          paddingRight: '0.75rem',
          paddingTop: '0.5rem',
          paddingBottom: '0.5rem',
          outline: 'none',
        }}
        className="focus:border-[var(--brand-primary)]"
        onFocus={e => e.target.style.borderColor = 'var(--brand-primary)'}
        onBlur={e => e.target.style.borderColor = 'var(--border-primary)'}
      />
    </div>
  );
}

// ── Toolbar above each role table ─────────────────────────────────────────────
function Toolbar({ hint, selectedCount, onDeleteSelected, onImport, importLabel }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.75rem', padding: '0.75rem 1rem 0', flexWrap: 'wrap' }}>
      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{hint}</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
        {selectedCount > 0 && (
          <button onClick={onDeleteSelected} className="btn-danger"
            style={{ fontSize: '0.75rem', padding: '0.5rem 0.75rem', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
            <Trash2 size={13} /> Delete selected ({selectedCount})
          </button>
        )}
        {onImport && (
          <button onClick={onImport} className="btn-secondary"
            style={{ fontSize: '0.75rem', padding: '0.5rem 0.75rem', display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
            <Upload size={13} /> {importLabel}
          </button>
        )}
      </div>
    </div>
  );
}

// ── Shared table styles ───────────────────────────────────────────────────────
const thStyle = { textAlign: 'left', padding: '0.5rem 1rem', fontSize: '0.75rem', color: 'var(--text-muted)', borderBottom: '1px solid var(--border-primary)', fontWeight: 500 };
const tdStyle = { padding: '0.75rem 1rem', borderBottom: '1px solid var(--border-primary)' };

// ── Users table — rendered once per role section ──────────────────────────────
// idKey/label are null for admins (they have no institution ID column);
// showSubmissions is false for admins and teachers; showSelect is false for
// admins (they are never bulk-deleted).
function UsersTable({
  rows, idKey, idLabel, showSubmissions, showSelect = true,
  selected, currentUser, onToggleRow, onToggleAll, allSelected,
  onUpdate, onDelete, emptyText,
}) {
  const selectable = rows.filter(u => u.id !== currentUser?.id);
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', fontSize: '0.875rem' }}>
        <thead>
          <tr>
            {showSelect && (
              <th style={{ ...thStyle, width: '2rem', padding: '0.5rem 0 0.5rem 1rem' }}>
                <input
                  type="checkbox"
                  checked={allSelected}
                  onChange={onToggleAll}
                  disabled={selectable.length === 0}
                  title={allSelected ? 'Deselect all shown' : 'Select all shown'}
                  style={{ accentColor: 'var(--brand-primary)', cursor: 'pointer' }}
                />
              </th>
            )}
            <th style={thStyle}>ID</th>
            <th style={thStyle}>Name</th>
            <th style={thStyle}>Email</th>
            <th style={thStyle}>Course</th>
            {idKey && <th style={thStyle}>{idLabel}</th>}
            <th style={thStyle}>Status</th>
            {showSubmissions && <th style={thStyle}>Submissions</th>}
            <th style={thStyle}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(u => (
            <tr key={u.id} style={{ borderBottom: '1px solid var(--border-primary)', transition: 'background 0.15s' }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-tertiary)'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
            >
              {showSelect && (
                <td style={{ ...tdStyle, padding: '0.75rem 0 0.75rem 1rem' }}>
                  {u.id === currentUser?.id ? (
                    <span title="You cannot select your own account" style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>—</span>
                  ) : (
                    <input
                      type="checkbox"
                      checked={selected.has(u.id)}
                      onChange={() => onToggleRow(u.id)}
                      style={{ accentColor: 'var(--brand-primary)', cursor: 'pointer' }}
                    />
                  )}
                </td>
              )}
              <td style={{ ...tdStyle, color: 'var(--text-muted)', fontFamily: 'monospace', fontSize: '0.75rem' }}>{u.id}</td>
              <td style={{ ...tdStyle, color: 'var(--text-primary)', fontWeight: 500 }}>
                <InlineEdit value={u.full_name} onSave={v => onUpdate(u.id, { full_name: v })} />
              </td>
              <td style={{ ...tdStyle, color: 'var(--text-secondary)' }}>
                <InlineEdit value={u.email} onSave={v => onUpdate(u.id, { email: v })} />
              </td>
              <td style={{ ...tdStyle, color: 'var(--text-secondary)' }}>
                <InlineEdit value={u.course || ''} onSave={v => onUpdate(u.id, { course: v })} />
              </td>
              {idKey && (
                <td style={{ ...tdStyle, color: u[idKey] ? 'var(--brand-primary)' : 'var(--text-muted)', fontFamily: 'monospace', fontSize: '0.75rem', fontWeight: 600 }}>
                  {u[idKey] || '—'}
                </td>
              )}
              <td style={tdStyle}>
                <button onClick={() => onUpdate(u.id, { is_active: !u.is_active })}
                  style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.75rem', fontWeight: 500, color: u.is_active ? 'var(--success-bg)' : 'var(--danger-bg)', transition: 'opacity 0.15s' }}
                  className="hover:opacity-80"
                >
                  {u.is_active ? <ToggleRight size={16} /> : <ToggleLeft size={16} />}
                  {u.is_active ? 'Active' : 'Inactive'}
                </button>
              </td>
              {showSubmissions && (
                <td style={{ ...tdStyle, color: 'var(--text-muted)', fontFamily: 'monospace', fontSize: '0.75rem' }}>{u.submission_count}</td>
              )}
              <td style={tdStyle}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <button title="Reset password to 'resetpass123'"
                    onClick={() => { if (window.confirm(`Reset password for ${u.email} to "resetpass123"?`)) onUpdate(u.id, { new_password: 'resetpass123' }); }}
                    style={{ color: 'var(--warning-bg)', transition: 'opacity 0.15s' }} className="hover:opacity-80">
                    <Lock size={14} />
                  </button>
                  <button onClick={() => onDelete(u.id, u.full_name)}
                    style={{ color: 'var(--danger-bg)', transition: 'opacity 0.15s' }} className="hover:opacity-80">
                    <Trash2 size={14} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length === 0 && (
        <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem', padding: '2rem 0' }}>{emptyText}</p>
      )}
    </div>
  );
}

// ── MAIN PAGE ─────────────────────────────────────────────────────────────────
export default function AdminPage() {
  const { user } = useAuth();
  const { resolvedTheme } = useTheme();
  const [stats, setStats]             = useState(null);
  const [users, setUsers]             = useState([]);
  const [loading, setLoading]         = useState(true);
  const [refreshing, setRefreshing]   = useState(false);
  const [confirm, setConfirm]         = useState(null);
  const [importRole, setImportRole]   = useState(null);

  const [openSections, setOpenSections] = useState({ admins: true, teachers: true, students: true });
  const toggleSection = (key) => setOpenSections(prev => ({ ...prev, [key]: !prev[key] }));

  const [userSearch, setUserSearch]   = useState('');
  const [selectedUsers, setSelectedUsers] = useState(() => new Set());

  const loadAll = useCallback(async (isFirstLoad = false) => {
    if (isFirstLoad) setLoading(true);
    else setRefreshing(true);
    try {
      const [s, u] = await Promise.all([
        api.get('/api/admin/stats'),
        api.get('/api/admin/users'),
      ]);
      setStats(s.data);
      setUsers(u.data);
    } catch (e) {
      toast.error('Failed to load admin data: ' + (e.response?.data?.detail || e.message));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { loadAll(true); }, [loadAll]);

  const ask = (msg, fn) => setConfirm({ msg, onConfirm: async () => { setConfirm(null); await fn(); await loadAll(); } });

  // ── USER ACTIONS ─────────────────────────────────────────────────────────────
  const updateUser = async (id, patch) => {
    try {
      await api.put(`/api/admin/users/${id}`, patch);
      toast.success('User updated');
      await loadAll();
    } catch (e) { toast.error(e.response?.data?.detail || 'Failed'); }
  };
  const deleteUser = (id, name) => ask(`Delete account "${name}"? This also deletes all their submissions.`,
    () => api.delete(`/api/admin/users/${id}`));

  // ── FILTERED DATA (one search box filters all three sections) ──────────────
  const matchesSearch = (u) => {
    const q = userSearch.toLowerCase();
    return (
      u.full_name.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      (u.course || '').toLowerCase().includes(q) ||
      (u.student_id || '').toLowerCase().includes(q) ||
      (u.teacher_id || '').toLowerCase().includes(q)
    );
  };
  const filteredUsers = users.filter(matchesSearch);
  const adminUsers   = filteredUsers.filter(u => u.role === 'admin');
  const teacherUsers = filteredUsers.filter(u => u.role === 'teacher');
  const studentUsers = filteredUsers.filter(u => u.role === 'student');

  // ── MULTI-SELECT / BULK DELETE (scoped to one section at a time) ────────────
  const selectableIn = (rows) => rows.filter(u => u.id !== user?.id);
  const isSelectedAll = (rows) => {
    const list = selectableIn(rows);
    return list.length > 0 && list.every(u => selectedUsers.has(u.id));
  };
  const selectedCountIn = (rows) => selectableIn(rows).filter(u => selectedUsers.has(u.id)).length;

  const toggleUserSelect = (id) => setSelectedUsers(prev => {
    const next = new Set(prev);
    next.has(id) ? next.delete(id) : next.add(id);
    return next;
  });

  const toggleAllIn = (rows) => setSelectedUsers(prev => {
    const next = new Set(prev);
    const list = selectableIn(rows);
    if (isSelectedAll(rows)) list.forEach(u => next.delete(u.id));
    else list.forEach(u => next.add(u.id));
    return next;
  });

  const deleteSelectedIn = (rows) => {
    // Only ids that are both still present and currently visible, so nothing
    // gets deleted that you cannot see on screen.
    const targets = selectableIn(rows).filter(u => selectedUsers.has(u.id));
    if (!targets.length) return;
    const label = targets.length === 1
      ? `"${targets[0].full_name}"`
      : `${targets.length} accounts (e.g. "${targets[0].full_name}")`;
    ask(`Delete ${label}? Their submissions, answers and violations are deleted too.`, async () => {
      let failed = 0;
      for (const u of targets) {
        try { await api.delete(`/api/admin/users/${u.id}`); }
        catch { failed++; }
      }
      setSelectedUsers(new Set());
      if (failed) toast.error(`${failed} of ${targets.length} account(s) could not be deleted`);
      else toast.success(`Deleted ${targets.length} account(s)`);
    });
  };

  if (loading) return (
    <Layout title="Admin Panel">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '16rem' }}>
        <Loader2 size={32} className="animate-spin" style={{ color: 'var(--brand-primary)' }} />
      </div>
    </Layout>
  );

  return (
    <Layout title="Admin Panel">
      {confirm && <ConfirmModal message={confirm.msg} onConfirm={confirm.onConfirm} onCancel={() => setConfirm(null)} />}
      {importRole && (
        <ImportUsersModal
          role={importRole}
          onClose={() => setImportRole(null)}
          onImported={loadAll}
        />
      )}

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{ background: 'var(--brand-primary)', borderRadius: '0.75rem', width: '2.5rem', height: '2.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Database size={18} style={{ color: '#fff' }} />
          </div>
          <div>
            <h1 className="font-display" style={{ fontSize: '1.125rem', fontWeight: 700, color: 'var(--text-primary)' }}>Admin Panel</h1>
            <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Manage all database records</p>
          </div>
        </div>
        <button onClick={() => loadAll()} className="btn-secondary" style={{ fontSize: '0.75rem', padding: '0.5rem 0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
          <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} /> Refresh
        </button>
      </motion.div>

      {/* Stats */}
      {stats && (
        <motion.div
          initial="hidden"
          animate="visible"
          variants={{ visible: { transition: { staggerChildren: 0.07 } } }}
          style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '0.75rem', marginBottom: '1.5rem' }}
        >
          <StatCard icon={Users} label="Total Users" value={stats.total_users} color="var(--brand-primary)" />
        </motion.div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>

        {/* ── SEARCH (applies to all three sections) ── */}
        <SearchBar value={userSearch} onChange={setUserSearch} placeholder="Search by name, email, course or ID…" />

        {/* ── ADMINS ── */}
        <Section icon={ShieldCheck} title="Admin Accounts" count={adminUsers.length} open={openSections.admins} onToggle={() => toggleSection('admins')}>
          <Toolbar
            hint="Full access to this panel. Admins are never bulk-selected."
          />
          <UsersTable
            rows={adminUsers} idKey={null} idLabel={null} showSubmissions={false} showSelect={false}
            selected={selectedUsers} currentUser={user}
            onToggleRow={toggleUserSelect}
            onToggleAll={() => toggleAllIn(adminUsers)}
            allSelected={isSelectedAll(adminUsers)}
            onUpdate={updateUser} onDelete={deleteUser}
            emptyText={userSearch ? `No admins match "${userSearch}"` : 'No admins found'}
          />
        </Section>

        {/* ── TEACHERS ── */}
        <Section icon={UserCheck} title="Teacher Accounts" count={teacherUsers.length} open={openSections.teachers} onToggle={() => toggleSection('teachers')}>
          <Toolbar
            hint="Bulk-create teacher accounts from a file of teacher IDs."
            selectedCount={selectedCountIn(teacherUsers)}
            onDeleteSelected={() => deleteSelectedIn(teacherUsers)}
            onImport={() => setImportRole('teacher')}
            importLabel="Import Teachers"
          />
          <UsersTable
            rows={teacherUsers} idKey="teacher_id" idLabel="Teacher ID" showSubmissions={false}
            selected={selectedUsers} currentUser={user}
            onToggleRow={toggleUserSelect}
            onToggleAll={() => toggleAllIn(teacherUsers)}
            allSelected={isSelectedAll(teacherUsers)}
            onUpdate={updateUser} onDelete={deleteUser}
            emptyText={userSearch ? `No teachers match "${userSearch}"` : 'No teachers found'}
          />
        </Section>

        {/* ── STUDENTS ── */}
        <Section icon={GraduationCap} title="Student Accounts" count={studentUsers.length} open={openSections.students} onToggle={() => toggleSection('students')}>
          <Toolbar
            hint="Bulk-create student accounts from a file of enrollment numbers."
            selectedCount={selectedCountIn(studentUsers)}
            onDeleteSelected={() => deleteSelectedIn(studentUsers)}
            onImport={() => setImportRole('student')}
            importLabel="Import Students"
          />
          <UsersTable
            rows={studentUsers} idKey="student_id" idLabel="Student ID" showSubmissions={true}
            selected={selectedUsers} currentUser={user}
            onToggleRow={toggleUserSelect}
            onToggleAll={() => toggleAllIn(studentUsers)}
            allSelected={isSelectedAll(studentUsers)}
            onUpdate={updateUser} onDelete={deleteUser}
            emptyText={userSearch ? `No students match "${userSearch}"` : 'No students found'}
          />
        </Section>

      </div>
    </Layout>
  );
}
