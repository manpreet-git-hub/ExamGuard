import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Activity, AlertTriangle, Users, Shield, WifiOff, RefreshCw } from 'lucide-react';
import Layout from '../components/shared/Layout';
import api, { getWsUrl } from '../utils/api';
import { parseApiDate } from '../utils/datetime';

const container = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.05 } } };
const item = { hidden: { opacity: 0, scale: 0.95 }, show: { opacity: 1, scale: 1 } };

function StudentCard({ student }) {
  const score = student.integrity_score ?? 100;
  const borderColor = score >= 80 ? 'var(--border-primary)' : score >= 50 ? '#f59e0b' : '#ef4444';

  const color = score >= 80 ? '#10b981' : score >= 50 ? '#f59e0b' : '#ef4444';
  const lastSeen = student.last_violation_at ? parseApiDate(student.last_violation_at)?.toLocaleTimeString() : null;

  return (
    <motion.div variants={item}
      className="p-3 rounded-xl transition-all duration-500"
      style={{ background: 'var(--bg-secondary)', border: `2px solid ${borderColor}` }}>
      <div className="aspect-video rounded-lg mb-3 flex items-center justify-center relative overflow-hidden"
           style={{ background: 'var(--bg-tertiary)' }}>
        {/* HUD scan effect */}
        <div className="absolute inset-0 scan-line-overlay opacity-30" />
        <div className="text-center relative z-10">
          <Users size={20} style={{ color: 'var(--text-muted)' }} className="mx-auto mb-1" />
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{student.is_active ? 'Realtime telemetry' : 'Latest snapshot'}</p>
        </div>
        {student.last_violation && (
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
            className="absolute bottom-0 left-0 right-0 text-white text-xs px-2 py-1 text-center truncate"
            style={{ background: 'rgba(239, 68, 68, 0.85)' }}>
            ⚠ {student.last_violation.replace(/_/g, ' ')}
          </motion.div>
        )}
      </div>

      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="min-w-0">
          <p className="text-sm font-medium truncate" style={{ color: 'var(--text-primary)' }}>{student.student_name}</p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{student.violations_count} violation{student.violations_count !== 1 ? 's' : ''}</p>
        </div>
        <div className="text-right flex-shrink-0">
          <p className="text-sm font-bold font-mono" style={{ color }}>{Math.round(score)}</p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Integrity</p>
        </div>
      </div>

      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--bg-tertiary)' }}>
        <motion.div className="h-full rounded-full" initial={{ width: 0 }} animate={{ width: `${score}%` }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          style={{ background: color }} />
      </div>

      <div className="mt-2 flex items-center justify-between">
        <span className={`badge text-xs ${student.is_active ? 'badge-blue' : score >= 80 ? 'badge-green' : score >= 50 ? 'badge-yellow' : 'badge-red'}`}>
          {student.is_active ? 'Active' : score >= 80 ? 'Low Risk' : score >= 50 ? 'Medium Risk' : 'High Risk'}
        </span>
        <span className="text-xs font-mono" style={{ color: 'var(--text-muted)' }}>
          {student.is_submitted && student.percentage != null ? `${student.percentage.toFixed(0)}%` : lastSeen || '—'}
        </span>
      </div>
    </motion.div>
  );
}

export default function LiveMonitorPage() {
  const { testId } = useParams();
  const navigate = useNavigate();
  const [test, setTest]         = useState(null);
  const [students, setStudents] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [lastRefresh, setLastRefresh] = useState(null);
  const [socketStatus, setSocketStatus] = useState('connecting');
  const pollRef = useRef(null);
  const socketRef = useRef(null);

  const mergeStudent = (existing, incoming) => {
    if (incoming?.student_id == null) return existing;
    const index = existing.findIndex(s => Number(s.student_id) === Number(incoming.student_id));
    const base = index >= 0 ? existing[index] : {
      student_id: incoming.student_id, student_name: incoming.student_name || `Student ${incoming.student_id}`,
      integrity_score: 100, violations_count: 0, percentage: null, last_violation: null, last_violation_at: null, is_active: true, is_submitted: false,
    };
    const next = { ...base, ...incoming,
      violations_count: incoming.violation_type ? (base.violations_count || 0) + 1 : (incoming.violations_count ?? base.violations_count ?? 0),
      last_violation: incoming.violation_type ?? incoming.last_violation ?? base.last_violation,
      last_violation_at: incoming.timestamp ?? incoming.last_violation_at ?? base.last_violation_at,
      is_active: incoming.is_active ?? base.is_active, is_submitted: incoming.is_submitted ?? base.is_submitted,
    };
    if (index === -1) return [next, ...existing];
    const nextStudents = [...existing]; nextStudents[index] = next; return nextStudents;
  };

  const fetchStudents = async () => {
    try { const r = await api.get(`/api/results/test/${testId}/monitor`); setTest(r.data.test); setStudents(r.data.students || []); setLastRefresh(new Date()); } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchStudents(); pollRef.current = setInterval(fetchStudents, 15000); return () => clearInterval(pollRef.current); }, [testId]);

  useEffect(() => {
    const socket = new WebSocket(getWsUrl(`/ws/teacher/${testId}`));
    socketRef.current = socket;
    socket.addEventListener('open', () => setSocketStatus('live'));
    socket.addEventListener('close', () => setSocketStatus('offline'));
    socket.addEventListener('error', () => setSocketStatus('offline'));
    socket.addEventListener('message', event => {
      try { const payload = JSON.parse(event.data); if (payload.type === 'heartbeat') return; setStudents(current => mergeStudent(current, payload)); setLastRefresh(new Date()); } catch {}
    });
    return () => { socketRef.current = null; socket.close(); };
  }, [testId]);

  const avgIntegrity = students.length ? students.reduce((s, x) => s + x.integrity_score, 0) / students.length : 100;
  const highRisk = students.filter(s => s.integrity_score < 50).length;
  const activeStudents = students.filter(s => s.is_active).length;

  return (
    <Layout title="Live Monitor">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-2 mb-6 text-sm" style={{ color: 'var(--text-muted)' }}>
          <button onClick={() => navigate('/')} className="flex items-center gap-1 hover:underline">
            <ArrowLeft size={14} /> Dashboard
          </button>
          <span>/</span>
          <span style={{ color: 'var(--text-primary)' }}>{test?.title || 'Test'}</span>
          <span>/</span>
          <span>Live Monitor</span>
        </div>

        <div className="flex items-center gap-4 mb-6 flex-wrap">
          <div className="flex items-center gap-2">
            {socketStatus === 'live' ? <div className="live-dot" /> : <WifiOff size={14} className="text-amber-400" />}
            <span className={`text-xs font-medium ${socketStatus === 'live' ? 'text-emerald-400' : 'text-amber-400'}`}>
              {socketStatus === 'live' ? 'Live websocket connected' : 'Auto-refresh mode'}
            </span>
          </div>
          {lastRefresh && <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Updated: {lastRefresh.toLocaleTimeString()}</span>}
          <button onClick={fetchStudents} className="flex items-center gap-1.5 text-xs ml-auto transition-colors"
            style={{ color: 'var(--text-muted)' }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--text-primary)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
            <RefreshCw size={13} /> Refresh
          </button>
        </div>

        <motion.div variants={container} initial="hidden" animate="show" className="grid grid-cols-3 gap-3 mb-6">
          {[
            { icon: Users,         label: 'Active Students', value: activeStudents, color: 'var(--text-primary)' },
            { icon: Shield,        label: 'Avg Integrity',   value: Math.round(avgIntegrity), color: 'var(--brand-primary)' },
            { icon: AlertTriangle, label: 'High Risk',       value: highRisk, color: '#ef4444' },
          ].map((s, i) => (
            <motion.div key={i} variants={item} className="card p-4 flex items-center gap-3">
              <s.icon size={18} style={{ color: s.color }} />
              <div>
                <p className="text-xl font-display font-bold" style={{ color: s.color }}>{s.value}</p>
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{s.label}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {loading ? (
          <div className="flex items-center justify-center h-48"><div className="w-8 h-8 rounded-full border-2 border-cyan-500/20 border-t-cyan-500 animate-spin" /></div>
        ) : students.length === 0 ? (
          <div className="card p-12 text-center">
            <Activity size={28} style={{ color: 'var(--text-muted)' }} className="mx-auto mb-3" />
            <p className="font-medium" style={{ color: 'var(--text-secondary)' }}>No students have joined yet.</p>
            <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>Share: <code className="font-mono" style={{ color: 'var(--brand-primary)' }}>{window.location.origin}/test/{test?.access_code}</code></p>
          </div>
        ) : (
          <motion.div variants={container} initial="hidden" animate="show"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {students.sort((a, b) => { if (a.is_active !== b.is_active) return a.is_active ? -1 : 1; return a.integrity_score - b.integrity_score; })
              .map(s => <StudentCard key={s.student_id} student={s} />)}
          </motion.div>
        )}
      </motion.div>
    </Layout>
  );
}
