import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import TestManagePage from './pages/TestManagePage';
import ResultsPage from './pages/ResultsPage';
import SubmissionDetailPage from './pages/SubmissionDetailPage';
import ExamEntryPage from './pages/ExamEntryPage';
import ExamPage from './pages/ExamPage';
import LiveMonitorPage from './pages/LiveMonitorPage';
import StudentHomePage from './pages/StudentHomePage';
import StudentResultPage from './pages/StudentResultPage';
import NotFoundPage from './pages/NotFoundPage';
import AdminPage from './pages/AdminPage';
import ChangePasswordPage from './pages/ChangePasswordPage';
import OverviewPage from './pages/OverviewPage';

function Spinner() {
  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--bg-primary)' }}>
      <div className="relative">
        <div className="w-12 h-12 rounded-full border-2 border-cyan-500/20 border-t-cyan-500 animate-spin" />
        <div className="absolute inset-0 w-12 h-12 rounded-full border-2 border-cyan-400/10 border-b-cyan-400 animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }} />
      </div>
    </div>
  );
}

// Everyone still on a default password must pick their own first.
function ForcePasswordChange({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Spinner />;
  if (user && user.must_change_password && location.pathname !== '/change-password')
    return <Navigate to="/change-password" replace />;
  return children;
}

function RequireAuth({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  return children;
}

function RequireTeacher({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  if (user.role === 'student') return <Navigate to="/student" replace />;
  return <ForcePasswordChange>{children}</ForcePasswordChange>;
}

function RequireAdmin({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  if (user.role !== 'admin') return <Navigate to="/" replace />;
  return <ForcePasswordChange>{children}</ForcePasswordChange>;
}

function RequireStudent({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  if (user.role !== 'student') return <Navigate to="/" replace />;
  return <ForcePasswordChange>{children}</ForcePasswordChange>;
}

function Home() {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  if (user.role === 'student') return <Navigate to="/student" replace />;
  return <ForcePasswordChange><DashboardPage /></ForcePasswordChange>;
}

function AppRoutes() {
  const { user } = useAuth();
  const location = useLocation();
  return (
    <Routes>
      <Route path="/login"    element={user ? <Navigate to={location.state?.from || '/'} replace /> : <LoginPage />} />
      {/* Self-signup is disabled — accounts come from the admin panel. */}
      <Route path="/register" element={<Navigate to="/login" replace />} />
      <Route path="/" element={<Home />} />
      <Route path="/dashboard" element={<RequireTeacher><DashboardPage /></RequireTeacher>} />
      <Route path="/overview"              element={<RequireTeacher><OverviewPage /></RequireTeacher>} />
      <Route path="/tests/:testId/manage"                element={<RequireTeacher><TestManagePage /></RequireTeacher>} />
      <Route path="/tests/:testId/results"               element={<RequireTeacher><ResultsPage /></RequireTeacher>} />
      <Route path="/tests/:testId/results/:submissionId" element={<RequireTeacher><SubmissionDetailPage /></RequireTeacher>} />
      <Route path="/tests/:testId/monitor"               element={<RequireTeacher><LiveMonitorPage /></RequireTeacher>} />
      <Route path="/student"                             element={<RequireStudent><StudentHomePage /></RequireStudent>} />
      <Route path="/student/result/:submissionId"        element={<RequireStudent><StudentResultPage /></RequireStudent>} />
      <Route path="/test/:accessCode" element={<ExamEntryPage />} />
      <Route path="/exam/:testId"     element={<RequireStudent><ExamPage /></RequireStudent>} />
      <Route path="/admin"               element={<RequireAdmin><AdminPage /></RequireAdmin>} />
      <Route path="/change-password"     element={<RequireAuth><ChangePasswordPage /></RequireAuth>} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
        <Toaster position="top-right" toastOptions={{
          duration: 3000,
          style: {
            background: 'var(--bg-elevated)',
            color: 'var(--text-primary)',
            border: '1px solid var(--border-secondary)',
            borderRadius: '10px',
            fontSize: '14px',
            boxShadow: 'var(--shadow-elevated)',
          },
          success: { iconTheme: { primary: '#10b981', secondary: '#fff' } },
          error:   { iconTheme: { primary: '#ef4444', secondary: '#fff' } },
        }} />
      </BrowserRouter>
    </AuthProvider>
  );
}
