export const TOKEN_STORAGE_KEY = 'proctovision_token';
