import { useState } from 'react';
import { X, Loader2, Shuffle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import api from '../../utils/api';

export default function CreateTestModal({ onClose, onCreated }) {
  const [form, setForm] = useState({
    title: '', description: '', duration_mins: 60,
    total_marks: 100, passing_marks: 40,
    start_time: '', end_time: '',
    shuffle_questions: false, questions_per_student: 0, shuffle_options: false,
  });
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm(p => ({ ...p, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (+form.passing_marks > +form.total_marks) { toast.error('Passing marks cannot be greater than total marks'); return; }
    if (form.start_time && form.end_time && new Date(form.end_time) <= new Date(form.start_time)) {
      toast.error('End time must be later than start time'); return;
    }
    if (form.shuffle_questions && +form.questions_per_student <= 0) {
      toast.error('Set questions per student when random selection is enabled'); return;
    }
    setLoading(true);
    try {
      const payload = { ...form };
      if (payload.start_time) payload.start_time = new Date(payload.start_time).toISOString();
      else delete payload.start_time;
      if (payload.end_time) payload.end_time = new Date(payload.end_time).toISOString();
      else delete payload.end_time;
      payload.duration_mins  = +payload.duration_mins;
      payload.total_marks    = +payload.total_marks;
      payload.passing_marks  = +payload.passing_marks;
      payload.questions_per_student = +payload.questions_per_student;
      const r = await api.post('/api/tests/', payload);
      toast.success('Test created!');
      onCreated(r.data);
    } catch (err) { toast.error(err.response?.data?.detail || 'Failed to create test'); }
    finally { setLoading(false); }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
        <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }} transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="card w-full max-w-lg relative overflow-hidden max-h-[90vh] overflow-y-auto">
          {/* Accent line */}
          <div className="h-0.5 w-full" style={{ background: 'linear-gradient(90deg, #06b6d4, #0891b2, transparent)' }} />

          <div className="flex items-center justify-between px-6 py-4" style={{ borderBottom: '1px solid var(--border-primary)' }}>
            <h2 className="text-base font-display font-semibold" style={{ color: 'var(--text-primary)' }}>Create New Test</h2>
            <button onClick={onClose} style={{ color: 'var(--text-muted)' }}
              onMouseEnter={e => e.currentTarget.style.color = 'var(--text-primary)'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}>
              <X size={18} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="label">Test Title <span className="text-red-500">*</span></label>
              <input className="input" placeholder="e.g. Mathematics Midterm 2024" value={form.title} onChange={set('title')} required />
            </div>
            <div>
              <label className="label">Description</label>
              <textarea className="input resize-none" rows={2} placeholder="Brief description of the test..."
                value={form.description} onChange={set('description')} />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="label">Duration (min)</label>
                <input className="input" type="number" min={1} max={480} value={form.duration_mins} onChange={set('duration_mins')} required />
              </div>
              <div>
                <label className="label">Total Marks</label>
                <input className="input" type="number" min={1} value={form.total_marks} onChange={set('total_marks')} required />
              </div>
              <div>
                <label className="label">Passing Marks</label>
                <input className="input" type="number" min={0} value={form.passing_marks} onChange={set('passing_marks')} required />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">Start Time (optional)</label>
                <input className="input" type="datetime-local" value={form.start_time} onChange={set('start_time')} />
              </div>
              <div>
                <label className="label">End Time (optional)</label>
                <input className="input" type="datetime-local" value={form.end_time} onChange={set('end_time')} />
              </div>
            </div>

            {/* Randomization Section */}
            <div className="rounded-lg p-4 space-y-3" style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-primary)' }}>
              <div className="flex items-center gap-2">
                <Shuffle size={16} style={{ color: 'var(--brand-primary)' }} />
                <span className="text-sm font-display font-semibold" style={{ color: 'var(--text-primary)' }}>Randomization</span>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={form.shuffle_questions} onChange={set('shuffle_questions')}
                  className="w-4 h-4 rounded" style={{ accentColor: 'var(--brand-primary)' }} />
                <div>
                  <span className="text-sm" style={{ color: 'var(--text-primary)' }}>Random question selection</span>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Each student gets a random subset of questions</p>
                </div>
              </label>
              {form.shuffle_questions && (
                <div className="ml-7">
                  <label className="label">Questions per student</label>
                  <input className="input w-32" type="number" min={1} value={form.questions_per_student} onChange={set('questions_per_student')}
                    placeholder="e.g. 20" />
                </div>
              )}
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" checked={form.shuffle_options} onChange={set('shuffle_options')}
                  className="w-4 h-4 rounded" style={{ accentColor: 'var(--brand-primary)' }} />
                <div>
                  <span className="text-sm" style={{ color: 'var(--text-primary)' }}>Shuffle MCQ options</span>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Randomize answer option order per student</p>
                </div>
              </label>
            </div>

            <div className="flex gap-3 pt-2">
              <button type="button" onClick={onClose} className="btn-secondary flex-1 justify-center">Cancel</button>
              <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
                {loading ? <Loader2 size={15} className="animate-spin" /> : null}
                {loading ? 'Creating...' : 'Create Test'}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
