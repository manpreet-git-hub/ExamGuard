import { useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, LogOut,
  Menu, X, User, FileText, BarChart2, Activity, Database, Sun, Moon, KeyRound
} from 'lucide-react';

export default function Layout({ children, title }) {
  const { user, logout } = useAuth();
  const { theme, toggleTheme, isDark } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const params = useParams();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };
  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + '/');

  const testId = params.testId;
  const baseNav = [
    { to: '/', icon: LayoutDashboard, label: 'Dashboard', exact: true },
    { to: '/overview', icon: BarChart2, label: 'Overview' },
    ...(user?.role === 'admin' ? [{ to: '/admin', icon: Database, label: 'Admin Panel' }] : []),
    { to: '/change-password', icon: KeyRound, label: 'Change Password' },
  ];
  const testNav = testId ? [
    { to: `/tests/${testId}/manage`,  icon: FileText,   label: 'Questions' },
    { to: `/tests/${testId}/results`, icon: BarChart2,  label: 'Results'   },
    { to: `/tests/${testId}/monitor`, icon: Activity,   label: 'Monitor'   },
  ] : [];

  const NavLinkItem = ({ to, icon: Icon, label, exact }) => {
    const active = exact ? location.pathname === to : isActive(to);
    return (
      <Link key={to} to={to} onClick={() => setSidebarOpen(false)}
        className={`sidebar-link ${active ? 'active' : ''}`}>
        <Icon size={17} />
        <span>{label}</span>
        {active && (
          <motion.div layoutId="sidebar-active"
            className="absolute left-0 w-0.5 h-5 rounded-r-full"
            style={{ background: 'var(--brand-primary)' }} />
        )}
      </Link>
    );
  };

  const SidebarContent = ({ mobile = false }) => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-5 flex-shrink-0" style={{ borderBottom: '1px solid var(--border-primary)' }}>
        <div className="relative">
          <img src="/logo.png" alt="ProctoVision" className="w-10 h-10 rounded-full flex-shrink-0" />
          <div className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2"
               style={{ borderColor: 'var(--bg-secondary)' }} />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-display font-bold" style={{ color: 'var(--text-primary)' }}>ProctoVision</p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>See Every Detail</p>
        </div>
        {mobile && (
          <button onClick={() => setSidebarOpen(false)} className="ml-auto flex-shrink-0"
                  style={{ color: 'var(--text-tertiary)' }}>
            <X size={20} />
          </button>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {baseNav.map(NavLinkItem)}
        {testNav.length > 0 && (
          <div className="pt-3 mt-3" style={{ borderTop: '1px solid var(--border-primary)' }}>
            <p className="text-xs px-3 pb-1 uppercase tracking-wider"
               style={{ color: 'var(--text-muted)' }}>Current Test</p>
          </div>
        )}
        {testNav.map(NavLinkItem)}
      </nav>

      {/* User */}
      <div className="p-3 flex-shrink-0" style={{ borderTop: '1px solid var(--border-primary)' }}>
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg" style={{ background: 'var(--bg-tertiary)' }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
               style={{ background: 'linear-gradient(135deg, #06b6d4, #0891b2)' }}>
            <User size={14} className="text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate" style={{ color: 'var(--text-primary)' }}>{user?.full_name}</p>
            <p className="text-xs capitalize" style={{ color: 'var(--text-muted)' }}>{user?.role}</p>
          </div>
          <button onClick={handleLogout} className="flex-shrink-0 transition-colors"
                  style={{ color: 'var(--text-tertiary)' }}
                  onMouseEnter={e => e.currentTarget.style.color = '#ef4444'}
                  onMouseLeave={e => e.currentTarget.style.color = 'var(--text-tertiary)'}
                  title="Logout">
            <LogOut size={15} />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--bg-primary)' }}>
      {/* Desktop sidebar */}
      <aside className="hidden lg:block w-56 flex-shrink-0" style={{ background: 'var(--bg-secondary)', borderRight: '1px solid var(--border-primary)' }}>
        <SidebarContent />
      </aside>

      {/* Mobile overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 lg:hidden">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
            <motion.aside initial={{ x: -224 }} animate={{ x: 0 }} exit={{ x: -224 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="absolute left-0 top-0 bottom-0 w-56"
              style={{ background: 'var(--bg-secondary)', borderRight: '1px solid var(--border-primary)' }}>
              <SidebarContent mobile />
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="px-4 lg:px-6 py-3 flex items-center gap-3 sticky top-0 z-30 backdrop-blur-md"
                style={{ background: 'color-mix(in srgb, var(--bg-secondary) 85%, transparent)', borderBottom: '1px solid var(--border-primary)' }}>
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden transition-colors"
                  style={{ color: 'var(--text-tertiary)' }}>
            <Menu size={20} />
          </button>
          {title && <h1 className="text-base font-display font-semibold" style={{ color: 'var(--text-primary)' }}>{title}</h1>}
          <div className="flex-1" />
          <button onClick={toggleTheme}
            className="p-2 rounded-lg transition-all duration-200"
            style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)', border: '1px solid var(--border-secondary)' }}
            title={`Switch to ${isDark ? 'light' : 'dark'} mode`}>
            {isDark ? <Sun size={15} /> : <Moon size={15} />}
          </button>
        </header>
        <main className="flex-1 p-4 lg:p-6 overflow-auto page-enter">
          {children}
        </main>
      </div>
    </div>
  );
}
