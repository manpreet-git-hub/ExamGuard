# ── config.py — Constants, thresholds, and penalties ──────────────────────────

import os

# ── Evidence / Video Recording ─────────────────────────────────────────────────
# Violations now produce short video clips instead of static screenshots.
# See utils/video_recorder.py for full implementation.
EVIDENCE_DIR       = "evidence"
os.makedirs(EVIDENCE_DIR, exist_ok=True)

# ── Mediapipe / YOLO thresholds ────────────────────────────────────────────────
FACE_DETECTION_CONFIDENCE = 0.75
FACE_MESH_MAX_FACES       = 5
FACE_MESH_DETECTION_CONF  = 0.5
FACE_MESH_TRACKING_CONF  = 0.5

# ── Evidence metadata ──────────────────────────────────────────────────────────
VTYPE_META = {
    "multi_face":        ("Multiple Faces Detected", (0,   51, 255)),
    "no_face":           ("No Face Detected",         (0,   51, 255)),
    "phone":             ("Phone Detected",           (0,   51, 255)),
    "laptop":            ("Laptop Detected",          (0,  100, 255)),
    "looking_away":      ("Looking Away",             (0,  200, 255)),
    "eye_gaze_away":     ("Suspicious Eye Movement",  (0,  200, 255)),
    "talking":           ("Talking Detected",         (0,  200, 255)),
    "identity_mismatch": ("Identity Mismatch",        (0,   51, 255)),
    "tab_switch":        ("Tab Switch Detected",      (0,  140, 255)),
    "window_blur":       ("Window Focus Lost",        (0,  140, 255)),
}