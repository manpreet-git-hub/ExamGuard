# ProctoVision — AI-Powered Exam Integrity

A production-ready, full-stack online examination platform with integrated real-time AI proctoring, built on React, FastAPI, SQLite/PostgreSQL, OpenCV, MediaPipe, and YOLOv8. See Every Detail.

---

## 🏗 Architecture Overview

```
exam_platform/
├── frontend/              # React 18 + TailwindCSS + Vite
│   └── src/
│       ├── pages/         # Teacher dashboard, exam page, results, live monitor
│       ├── components/    # Reusable UI components
│       ├── contexts/      # Auth context (JWT)
│       └── utils/         # Axios API client
│
├── backend/               # FastAPI (Python 3.11)
│   ├── main.py            # App entry point + WebSocket manager
│   ├── routers/           # auth / tests / questions / submissions / proctoring / results
│   ├── models/            # SQLAlchemy ORM models
│   └── database/          # SQLite/PostgreSQL engine
│
├── ai_proctoring/         # CV pipeline (from your uploaded module)
│   ├── detection/         # face_detection, phone_detection, eye_tracking, head_pose, talking
│   ├── engine/            # frame_processor
│   ├── utils/             # logger, video_recorder
│   └── model_loader.py    # Loads MediaPipe + YOLOv8
│
├── storage/               # Docker mount target — containers persist evidence here
│
├── docker-compose.yml
└── start.sh               # One-command local dev startup
```

---

## 🚀 Quick Start (Local Development)

### Prerequisites
- Python 3.10+
- Node.js 18+
- Git

### One-command startup
```bash
chmod +x start.sh
./start.sh
```

Then open:
- **Teacher Dashboard**: http://localhost:3000
- **API Docs**: http://localhost:8000/docs

### Demo credentials (auto-seeded)
| Role    | Email                | Password  |
|---------|----------------------|-----------|
| Teacher | teacher@demo.com     | demo1234  |
| Student | student@demo.com     | demo1234  |

---

## 📦 Manual Setup

### Backend
```bash
cd backend
python3 -m venv venv
source venv/bin/activate           # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Seed demo data
python seed.py

# Run dev server — no PYTHONPATH needed, main.py sets sys.path itself
uvicorn main:app --reload --port 8000
```

### Configuration
Copy the templates and edit as needed:
```bash
cp backend/.env.example backend/.env       # SECRET_KEY, ALLOWED_ORIGINS, SMTP, DATABASE_URL
cp frontend/.env.example frontend/.env.local  # VITE_API_URL (defaults to same-origin)
```
- **development** (default): works out of the box — permissive CORS, built-in dev secret.
- **production** (`ENV=production`): the backend **refuses to start** unless
  `SECRET_KEY` and `ALLOWED_ORIGINS` are set, and CORS is pinned to exactly
  those origins (the LAN-IP wildcard is disabled).

### Frontend
```bash
cd frontend
npm install
npm run dev          # http://localhost:3000
```

---

## 🐳 Docker Deployment

```bash
docker-compose up --build
```

For a real deployment, set these in your shell or a project-root `.env`
(gitignored) **before** starting compose:
```bash
ENV=production
SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_urlsafe(48))")
ALLOWED_ORIGINS=https://your-domain.example
```

Access:
- Frontend: http://localhost:3000
- API: http://localhost:8000

---

## 🎯 Core Features

### Teacher Dashboard
| Feature | Details |
|---------|---------|
| Create Tests | Title, description, duration, marks, date/time window |
| Unique Test Links | `https://platform.com/test/ABC12345` |
| Question Editor | MCQ, Multi-select, Short Answer, Coding |
| Results Table | Score, integrity score, risk level, violations |
| Violation Timeline | Per-student chronological event log |
| Evidence Gallery | Screenshots captured during violations |
| Live Monitor | Real-time webcam grid with violation alerts |

### Student Exam Interface
| Feature | Details |
|---------|---------|
| Test Entry | Access code → Login → Instructions → Camera check |
| Proctored Exam | Webcam feed, timer, question panel, auto-save |
| Question Navigator | Visual grid showing answered/flagged/current |
| Integrity Score | Live score shown during exam |
| Auto-submission | Timer expiry triggers automatic submission |

### AI Proctoring (Real-time)
| Detection | Method | Trigger |
|-----------|--------|---------|
| Face Detection | MediaPipe Face Detection | No face / Multiple faces |
| Head Pose | MediaPipe Face Mesh landmarks | Looking away > 2.5s |
| Eye Gaze | Iris landmark tracking | Left/Right/Up/Down gaze |
| Mouth / Talking | Lip distance ratio | Mouth opening detected |
| Phone Detection | YOLOv8 (COCO class 67) | Phone visible on camera |
| Laptop Detection | YOLOv8 (COCO class 63) | Secondary device on camera |
| Tab Switch | `visibilitychange` + `blur` events | Tab hidden / window unfocused |
| Copy/Paste | `copy`, `paste`, `cut` event blocking | Attempt logged and blocked |
| Fullscreen | Fullscreen API enforcement | Exit triggers re-entry prompt |
| Network Drop | `offline` event | Disconnect logged |

### Integrity Score System
```
Start: 100 points
Phone detected:      −30
Multiple faces:      −50
No face:             −15
Tab switched:        −15
Looking away (head): −10
Eye gaze away:       −8
Talking detected:    −8
Fullscreen exit:     −10
Laptop detected:     −25

Risk levels:
  ≥80  → Low Risk    (green)
  ≥50  → Medium Risk (amber)
  <50  → High Risk   (red)
```

### Auto-Grading
- **MCQ**: Exact match → full marks
- **Multi-select**: All correct options selected → full marks
- **Short Answer / Coding**: Stored for manual teacher review

---

## 🔐 Security

- JWT authentication (24h expiry)
- Password hashing via bcrypt
- Role-based access control (teacher / student / admin)
- Unique per-test access codes
- Copy-paste blocked in exam
- Fullscreen enforcement
- WebSocket rooms scoped per test

---

## 📡 API Reference

Full interactive docs at: `http://localhost:8000/docs`

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/auth/register` | POST | Disabled (403) — accounts are created by the admin |
| `/api/auth/login` | POST | Get JWT token |
| `/api/tests/` | GET/POST | List / create tests |
| `/api/tests/{id}` | GET/PUT/DELETE | Manage test |
| `/api/tests/code/{code}` | GET | Get test by access code |
| `/api/questions/` | POST | Add question |
| `/api/questions/test/{id}` | GET | Get questions (teacher) |
| `/api/questions/student/test/{id}` | GET | Get questions (no answers) |
| `/api/submissions/start` | POST | Start exam session |
| `/api/submissions/{id}/save-answer` | POST | Auto-save answer |
| `/api/submissions/{id}/submit` | POST | Final submission + grading |
| `/api/proctoring/violation` | POST | Log a violation |
| `/api/proctoring/analyze-frame` | POST | AI frame analysis |
| `/api/results/test/{id}` | GET | Test result summary |
| `/api/results/submission/{id}/detail` | GET | Full submission detail |
| `/ws/proctor/{test_id}/{student_id}` | WS | Student → server feed |
| `/ws/teacher/{test_id}` | WS | Teacher live monitor |

---

## 🔧 Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | `sqlite:///./examguard.db` | Database connection string |
| `SECRET_KEY` | (hardcoded dev key) | JWT signing key — **change in production** |
| `VITE_API_URL` | (empty — uses Vite proxy) | Backend URL for production |

### PostgreSQL (production)
```bash
DATABASE_URL=postgresql://user:pass@localhost:5432/examguard uvicorn main:app
```

---

## 📁 AI Proctoring Integration

The `ai_proctoring/` directory contains your uploaded CV module. It integrates into the backend via:

1. **REST endpoint** (`/api/proctoring/analyze-frame`): Student webcam frames (base64 JPEG) are sent every 5 seconds. The backend decodes them, runs the full `process_frame()` pipeline, and logs any violations.

2. **Frame processor**: `engine/frame_processor.py` → runs face detection, head pose, eye tracking, talking detection, and YOLOv8 phone detection in sequence. Penalties and risk levels come from the shared tables in `backend/utils/scoring.py`.

---

## 🗂 Database Schema

```
users            → id, email, full_name, course, role, hashed_password
tests            → id, title, access_code, duration_mins, total_marks, creator_id
questions        → id, test_id, question_text, question_type, options, correct_answer, marks
submissions      → id, test_id, student_id, score, integrity_score, risk_level
answers          → id, submission_id, question_id, selected_options, marks_awarded
violation_logs   → id, submission_id, violation_type, confidence_score, evidence_path, penalty
```

---

## 🎨 Tech Stack Summary

| Layer | Technology |
|-------|-----------|
| Frontend UI | React 18, TailwindCSS, Vite |
| Routing | React Router v6 |
| Charts | Recharts |
| Backend | FastAPI, Python 3.11 |
| Auth | JWT (PyJWT), bcrypt (passlib) |
| Database | SQLAlchemy + SQLite (swap to PostgreSQL) |
| WebSocket | FastAPI native WebSockets |
| Face/Mesh | MediaPipe |
| Object Detection | YOLOv8 (Ultralytics) |
| Frame CV | OpenCV |
| Deployment | Docker + Nginx |

---

## 🔧 Architecture notes: how the AI proctoring conflicts were fixed

If you're wondering why earlier versions of this project had MediaPipe
loading failures or bcrypt crashes — here's exactly what was wrong and how
it's fixed now:

### 1. One requirements file
`backend/requirements.txt` is the **only** file you install for running
the platform. It pins `mediapipe==0.10.9` together with `protobuf<4` and
`opencv-python==4.9.0.80` — versions chosen to work together, not "whatever
pip resolves to."

### 2. Consistent dual-style imports across `ai_proctoring/`
Every file in `ai_proctoring/` uses the same pattern:
```python
try:
    from ai_proctoring.config import X          # works when imported as a package
except ImportError:
    from config import X                         # works when the module dir is on sys.path
```
Previously `model_loader.py` was the *only* file missing this fallback,
which is exactly why `from ai_proctoring.model_loader import load_models`
raised `ModuleNotFoundError: No module named 'config'` when called from the
backend, even though every other file in the package already worked fine.

### 3. `model_loader.py` never lets one failure kill everything
Attribute access like `mp.solutions.face_detection` used to happen
*outside* the try/except block — so on any MediaPipe API/version mismatch,
`load_models()` crashed instead of degrading to "MediaPipe unavailable,
using OpenCV Haar-cascade fallback" like it was designed to. That's fixed:
every model load (MediaPipe face detection, face mesh, each YOLO size) is
now independently wrapped, so a problem with one never takes down the rest.

### 4. Detector state is isolated per exam session
`ai_proctoring/runtime_state.py`'s `get_state()`/`set_state()` are called on
**every single video frame** by `engine/frame_processor.py`. State is kept in
a plain per-session dict, so different students' exam sessions never share
detector state with each other (they used to fall into one shared global
bucket). No module in the platform imports Streamlit unconditionally — the
remaining `import streamlit as st` usages are guarded, and
`backend/requirements.txt` deliberately doesn't include Streamlit at all.

### 5. Auth: PyJWT instead of python-jose, and a bcrypt 72-byte guard
`python-jose` and the unrelated PyPI package `jose` are easy to confuse and
both expose `import jose`/`from jose import jwt` — installing the wrong one
produces a `SyntaxError: Missing parentheses in call to 'print'` because
that other `jose` package is ancient Python 2 code. `backend/routers/auth.py`
now uses `PyJWT` (`import jwt`) exclusively, which has no such ambiguity.
Passwords are also explicitly truncated to bcrypt's 72-byte limit before
hashing/verifying, so a long password can never raise
`ValueError: password cannot be longer than 72 bytes` at login.

### 6. No manual `PYTHONPATH` needed, ever
`backend/main.py` inserts the project root into `sys.path` itself, first
thing, before any router is imported. Every downstream file already has the
package/flat import fallback from point 2 above, so `uvicorn main:app` just
works from inside `backend/` with zero environment variables — you no
longer need to remember `PYTHONPATH=.:../ai_proctoring` or any variant of it.

---

## 📝 License

MIT — free to use, modify, and deploy.
